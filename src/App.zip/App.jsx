import React, { useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { motion } from "framer-motion";
import {
  BarChart3,
  BookOpen,
  Calendar,
  Camera,
  ChevronLeft,
  ChevronRight,
  Download,
  Edit3,
  Eye,
  Filter,
  LayoutDashboard,
  ListChecks,
  Plus,
  Search,
  Settings,
  CreditCard,
  LogOut,
  Target,
  TrendingUp,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";

const STORAGE_KEY = "critique_video_style_trades_v1";
const ACCOUNT_KEY = "critique_video_style_account_v1";
const ACCOUNTS_KEY = "critique_video_style_accounts_v1";
const ACTIVE_ACCOUNT_KEY = "critique_video_style_active_account_v1";
const ROUTINE_KEY = "critique_pre_trade_routine_v1";
const THEME_KEY = "critique_theme_mode_v1";
const RESTORE_CACHE_PREFIX = "critique_last_successful_restore_v1";
const USER_TRADES_KEY_PREFIX = "critique_user_trades_v2";
const MAX_SCREENSHOTS = 5;
const BRAND_NAME = "Critique";
const BRAND_MARK = "◉";
const TRADING_SESSIONS = ["Asia", "London", "NY-AM", "Lunch", "NY-PM", "Pre-Market"];

function getEnvValue(key) {
  try {
    return String(import.meta.env?.[key] || "").trim();
  } catch {
    return "";
  }
}

const SUPABASE_URL = getEnvValue("VITE_SUPABASE_URL");
const SUPABASE_ANON_KEY = getEnvValue("VITE_SUPABASE_ANON_KEY") || getEnvValue("VITE_SUPABASE_KEY");
const hasValidSupabaseUrl = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(SUPABASE_URL);
const hasValidSupabaseKey = SUPABASE_ANON_KEY.length > 40;
const supabase = hasValidSupabaseUrl && hasValidSupabaseKey ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const isSupabaseReady = Boolean(supabase);

const THEME_STYLE_CSS = `
  html,
  body,
  #root {
    width: 100% !important;
    min-width: 100% !important;
    max-width: none !important;
    margin: 0 !important;
    padding: 0 !important;
    text-align: initial !important;
    overflow-x: hidden !important;
    background: #000 !important;
  }

  #root {
    display: block !important;
  }

  main {
    width: auto !important;
    max-width: none !important;
  }

  @media (min-width: 1024px) {
    main {
      width: calc(100vw - 16rem) !important;
      margin-left: 16rem !important;
    }
  }

  .light-theme {
    background: linear-gradient(135deg, #fbf7ff 0%, #ffffff 42%, #f8fbff 100%) !important;
    color: #0f172a !important;
  }

  .light-theme main {
    background: linear-gradient(135deg, #fbf7ff 0%, #ffffff 45%, #f8fbff 100%) !important;
    color: #0f172a !important;
  }

  .light-theme aside.fixed {
    background: linear-gradient(180deg, #ffffff 0%, #fbf7ff 52%, #f7edff 100%) !important;
    color: #0f172a !important;
    border-right-color: rgba(168, 85, 247, 0.22) !important;
    box-shadow: 12px 0 35px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme .bg-black,
  .light-theme .bg-zinc-950,
  .light-theme .bg-zinc-900,
  .light-theme .bg-[#050005],
  .light-theme .bg-[#070707],
  .light-theme .bg-[#020202] {
    background-color: #ffffff !important;
    color: #0f172a !important;
  }

  .light-theme .light-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.22) !important;
    box-shadow: 0 18px 42px rgba(15, 23, 42, 0.08) !important;
  }

  .light-theme .light-card-soft {
    background: linear-gradient(135deg, #f8fafc 0%, #ffffff 55%, #f5f3ff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(148, 163, 184, 0.28) !important;
  }

  .light-theme [class*="bg-black/30"],
  .light-theme [class*="bg-black/40"],
  .light-theme [class*="bg-black/50"],
  .light-theme [class*="bg-black/70"],
  .light-theme [class*="bg-black/75"],
  .light-theme [class*="bg-black/80"],
  .light-theme [class*="bg-black/95"] {
    background-color: rgba(255, 255, 255, 0.72) !important;
    color: #0f172a !important;
  }

  .light-theme [class*="from-zinc-950"],
  .light-theme [class*="via-black"],
  .light-theme [class*="to-black"] {
    --tw-gradient-from: #ffffff !important;
    --tw-gradient-via: #fbf7ff !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme [class*="from-fuchsia-950"] {
    --tw-gradient-from: #faf5ff !important;
    --tw-gradient-via: #fdf4ff !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme [class*="from-emerald-950"] {
    --tw-gradient-from: #ecfdf5 !important;
    --tw-gradient-via: #f0fdf4 !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme [class*="from-cyan-950"] {
    --tw-gradient-from: #ecfeff !important;
    --tw-gradient-via: #f0fdfa !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme [class*="from-orange-950"] {
    --tw-gradient-from: #fff7ed !important;
    --tw-gradient-via: #fffbeb !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme [class*="from-red-950"] {
    --tw-gradient-from: #fef2f2 !important;
    --tw-gradient-via: #fff7ed !important;
    --tw-gradient-to: #ffffff !important;
  }

  .light-theme .border-white\/8,
  .light-theme .border-white\/10,
  .light-theme .border-white\/15,
  .light-theme .border-white\/20 {
    border-color: rgba(148, 163, 184, 0.34) !important;
  }

  .light-theme .text-white,
  .light-theme .text-zinc-200,
  .light-theme .text-zinc-300 {
    color: #0f172a !important;
  }

  .light-theme .text-zinc-400,
  .light-theme .text-zinc-500,
  .light-theme .text-zinc-600 {
    color: #64748b !important;
  }

  .light-theme .text-black {
    color: #0f172a !important;
  }

  .light-theme .account-type-card {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(148, 163, 184, 0.34) !important;
  }

  .light-theme .account-type-card:hover {
    border-color: rgba(217, 70, 239, 0.45) !important;
    box-shadow: 0 10px 24px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .account-type-card.border-fuchsia-500 {
    background: linear-gradient(135deg, #faf5ff 0%, #ffffff 55%, #fdf4ff 100%) !important;
    border-color: rgba(217, 70, 239, 0.75) !important;
  }

  .light-theme .date-picker-trigger {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.32) !important;
    box-shadow: 0 8px 22px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme .date-picker-trigger:hover,
  .light-theme .date-picker-trigger:focus {
    border-color: rgba(217, 70, 239, 0.65) !important;
    box-shadow: 0 0 0 2px rgba(217, 70, 239, 0.12), 0 10px 25px rgba(168, 85, 247, 0.12) !important;
  }

  .light-theme .date-picker-value {
    color: #0f172a !important;
    font-weight: 900 !important;
  }

  .light-theme .date-picker-placeholder {
    color: #64748b !important;
    font-weight: 800 !important;
  }

  .light-theme .date-picker-popover {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(217, 70, 239, 0.40) !important;
    box-shadow: 0 18px 45px rgba(15, 23, 42, 0.16) !important;
    opacity: 1 !important;
    isolation: isolate !important;
    overflow: hidden !important;
  }

  .light-theme .date-picker-popover::before {
    content: "";
    position: absolute;
    inset: 0;
    z-index: -1;
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 60%, #ffffff 100%);
    opacity: 1;
  }

  .light-theme .date-picker-title {
    color: #0f172a !important;
  }

  .light-theme .date-picker-nav {
    background: #ffffff !important;
    color: #86198f !important;
    border-color: rgba(168, 85, 247, 0.30) !important;
    box-shadow: 0 8px 20px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .date-picker-weekdays {
    color: #7e22ce !important;
  }

  .light-theme .date-picker-day-current {
    background: #faf5ff !important;
    color: #0f172a !important;
    border: 1px solid rgba(168, 85, 247, 0.16) !important;
  }

  .light-theme .date-picker-day-muted {
    background: #f8fafc !important;
    color: #94a3b8 !important;
  }

  .date-picker-day-number {
    color: inherit !important;
    opacity: 1 !important;
    visibility: visible !important;
    display: inline-block !important;
    font-weight: 900 !important;
  }

  .light-theme .date-picker-day,
  .light-theme .date-picker-day span,
  .light-theme .date-picker-day-number {
    color: #0f172a !important;
    font-weight: 900 !important;
    opacity: 1 !important;
    visibility: visible !important;
  }

  .light-theme .date-picker-day-current {
    background: #faf5ff !important;
    color: #0f172a !important;
    border: 1px solid rgba(168, 85, 247, 0.22) !important;
  }

  .light-theme .date-picker-day-muted {
    background: #f8fafc !important;
    color: #475569 !important;
    opacity: 0.85 !important;
  }

  .light-theme .date-picker-day-selected {
    background: #d946ef !important;
    color: #ffffff !important;
    box-shadow: 0 8px 20px rgba(217, 70, 239, 0.22) !important;
  }

  .light-theme .date-picker-day-selected .date-picker-day-number {
    color: #ffffff !important;
  }

  .light-theme .date-picker-day-selected:hover {
    background: #c026d3 !important;
    color: #ffffff !important;
  }

  .light-theme .date-picker-day:hover:not(.date-picker-day-selected) {
    background: rgba(217, 70, 239, 0.14) !important;
    color: #86198f !important;
  }

  .light-theme .date-picker-day:hover:not(.date-picker-day-selected) .date-picker-day-number {
    color: #86198f !important;
  }

  .light-theme .custom-select-trigger {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.32) !important;
    box-shadow: 0 8px 22px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme .custom-select-trigger:hover,
  .light-theme .custom-select-trigger:focus {
    border-color: rgba(217, 70, 239, 0.65) !important;
    box-shadow: 0 0 0 2px rgba(217, 70, 239, 0.12), 0 10px 25px rgba(168, 85, 247, 0.12) !important;
  }

  .light-theme .custom-select-menu {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(217, 70, 239, 0.38) !important;
    box-shadow: 0 18px 45px rgba(15, 23, 42, 0.16) !important;
  }

  .light-theme .custom-select-option {
    min-height: 36px !important;
    color: #0f172a !important;
    background: transparent !important;
  }

  .light-theme .custom-select-option span {
    color: inherit !important;
  }

  .light-theme .custom-select-option:hover {
    background: rgba(217, 70, 239, 0.10) !important;
    color: #86198f !important;
  }

  .light-theme .custom-select-option.bg-fuchsia-500,
  .light-theme .custom-select-option.bg-emerald-500,
  .light-theme .custom-select-option.bg-red-500,
  .light-theme .custom-select-option.bg-amber-500,
  .light-theme .custom-select-option.bg-blue-500,
  .light-theme .custom-select-option.bg-cyan-500,
  .light-theme .custom-select-option.bg-orange-500 {
    color: #ffffff !important;
  }

  .light-theme .custom-select-option.bg-fuchsia-500 span,
  .light-theme .custom-select-option.bg-emerald-500 span,
  .light-theme .custom-select-option.bg-red-500 span,
  .light-theme .custom-select-option.bg-amber-500 span,
  .light-theme .custom-select-option.bg-blue-500 span,
  .light-theme .custom-select-option.bg-cyan-500 span,
  .light-theme .custom-select-option.bg-orange-500 span {
    color: #ffffff !important;
  }

  .custom-select-option-asia,
  .custom-select-option-asia span,
  .light-theme .custom-select-option-asia,
  .light-theme .custom-select-option-asia span {
    color: #1d4ed8 !important;
    font-weight: 900 !important;
  }

  .custom-select-option-london,
  .custom-select-option-london span,
  .light-theme .custom-select-option-london,
  .light-theme .custom-select-option-london span {
    color: #dc2626 !important;
    font-weight: 900 !important;
  }

  .custom-select-option-ny-am,
  .custom-select-option-ny-am span,
  .light-theme .custom-select-option-ny-am,
  .light-theme .custom-select-option-ny-am span {
    color: #047857 !important;
    font-weight: 900 !important;
  }

  .custom-select-option-lunch,
  .custom-select-option-lunch span,
  .light-theme .custom-select-option-lunch,
  .light-theme .custom-select-option-lunch span {
    color: #b45309 !important;
    font-weight: 900 !important;
  }

  .custom-select-option-ny-pm,
  .custom-select-option-ny-pm span,
  .light-theme .custom-select-option-ny-pm,
  .light-theme .custom-select-option-ny-pm span {
    color: #a21caf !important;
    font-weight: 900 !important;
  }

  .custom-select-option-pre-market,
  .custom-select-option-pre-market span,
  .light-theme .custom-select-option-pre-market,
  .light-theme .custom-select-option-pre-market span {
    color: #0891b2 !important;
    font-weight: 900 !important;
  }

  .light-theme .custom-select-option.bg-fuchsia-500,
  .light-theme .custom-select-option.bg-fuchsia-500 span,
  .light-theme .custom-select-option.bg-emerald-500,
  .light-theme .custom-select-option.bg-emerald-500 span,
  .light-theme .custom-select-option.bg-red-500,
  .light-theme .custom-select-option.bg-red-500 span,
  .light-theme .custom-select-option.bg-amber-500,
  .light-theme .custom-select-option.bg-amber-500 span,
  .light-theme .custom-select-option.bg-blue-500,
  .light-theme .custom-select-option.bg-blue-500 span,
  .light-theme .custom-select-option.bg-cyan-500,
  .light-theme .custom-select-option.bg-cyan-500 span,
  .light-theme .custom-select-option.bg-orange-500,
  .light-theme .custom-select-option.bg-orange-500 span {
    color: #ffffff !important;
  }

  .custom-select-option-none,
  .custom-select-option-early-entry,
  .custom-select-option-late-entry,
  .custom-select-option-no-confirmation,
  .custom-select-option-overtrading,
  .custom-select-option-emotional-trade,
  .custom-select-option-bad-risk-management,
  .custom-select-option-moved-stop-loss {
    color: #0f172a !important;
  }

  .custom-select-option-none:hover,
  .custom-select-option-early-entry:hover,
  .custom-select-option-late-entry:hover,
  .custom-select-option-no-confirmation:hover,
  .custom-select-option-overtrading:hover,
  .custom-select-option-emotional-trade:hover,
  .custom-select-option-bad-risk-management:hover,
  .custom-select-option-moved-stop-loss:hover {
    background: rgba(217, 70, 239, 0.10) !important;
    color: #86198f !important;
  }

  .custom-select-option-asia:hover { background: rgba(29, 78, 216, 0.12) !important; }
  .custom-select-option-london:hover { background: rgba(220, 38, 38, 0.12) !important; }
  .custom-select-option-ny-am:hover { background: rgba(4, 120, 87, 0.14) !important; }
  .custom-select-option-lunch:hover { background: rgba(180, 83, 9, 0.12) !important; }
  .custom-select-option-ny-pm:hover { background: rgba(162, 28, 175, 0.14) !important; }
  .custom-select-option-pre-market:hover { background: rgba(8, 145, 178, 0.12) !important; }

  .custom-select-selected.custom-select-option-asia,
  .custom-select-selected.custom-select-option-asia span { color: #1d4ed8 !important; }
  .custom-select-selected.custom-select-option-london,
  .custom-select-selected.custom-select-option-london span { color: #dc2626 !important; }
  .custom-select-selected.custom-select-option-ny-am,
  .custom-select-selected.custom-select-option-ny-am span { color: #047857 !important; }
  .custom-select-selected.custom-select-option-lunch,
  .custom-select-selected.custom-select-option-lunch span { color: #b45309 !important; }
  .custom-select-selected.custom-select-option-ny-pm,
  .custom-select-selected.custom-select-option-ny-pm span { color: #a21caf !important; }
  .custom-select-selected.custom-select-option-pre-market,
  .custom-select-selected.custom-select-option-pre-market span { color: #0891b2 !important; }

  .custom-select-active,
  .custom-select-active span {
    color: #ffffff !important;
  }

  .light-theme .custom-select-active,
  .light-theme .custom-select-active span {
    color: #0f172a !important;
    font-weight: 900 !important;
  }

  .light-theme .custom-select-active {
    background: rgba(217, 70, 239, 0.12) !important;
    border: 1px solid rgba(217, 70, 239, 0.22) !important;
    box-shadow: 0 8px 20px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .custom-select-option:not(.custom-select-active),
  .light-theme .custom-select-option:not(.custom-select-active) span {
    color: #0f172a !important;
  }

  .custom-select-option-ny-am.bg-emerald-500,
  .custom-select-option-ny-pm.bg-fuchsia-500,
  .custom-select-option-ny-am.bg-emerald-500 span,
  .custom-select-option-ny-pm.bg-fuchsia-500 span {
    color: #ffffff !important;
  }

  .light-theme .account-sidebar-card {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.28) !important;
    box-shadow: 0 10px 28px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .account-sidebar-card:hover {
    border-color: rgba(217, 70, 239, 0.55) !important;
    box-shadow: 0 14px 34px rgba(168, 85, 247, 0.16) !important;
  }

  .light-theme input,
  .light-theme textarea,
  .light-theme select {
    background-color: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(148, 163, 184, 0.35) !important;
  }

  .light-theme input::placeholder,
  .light-theme textarea::placeholder {
    color: #94a3b8 !important;
  }

  .light-theme .bg-white\/5,
  .light-theme .bg-white\/10,
  .light-theme .bg-white\/\[0\.03\] {
    background-color: rgba(148, 163, 184, 0.10) !important;
  }

  .light-theme .shadow-\[0_0_22px_rgba\(217\,70\,239\,0\.12\)\],
  .light-theme .shadow-\[0_0_28px_rgba\(217\,70\,239\,0\.22\)\],
  .light-theme .shadow-\[0_0_45px_rgba\(168\,85\,247\,0\.13\)\],
  .light-theme .shadow-\[0_0_35px_rgba\(16\,185\,129\,0\.08\)\] {
    box-shadow: 0 16px 40px rgba(168, 85, 247, 0.12) !important;
  }

  .light-theme .bg-fuchsia-500.text-black,
  .light-theme .bg-emerald-500.text-black,
  .light-theme .bg-red-500.text-black,
  .light-theme .bg-amber-500.text-black,
  .light-theme .bg-blue-500.text-black,
  .light-theme .bg-cyan-500.text-black,
  .light-theme .bg-orange-500.text-black,
  .light-theme .bg-fuchsia-500 {
    color: #ffffff !important;
  }

  .light-theme {
    --tooltip-bg: #ffffff;
    --tooltip-border: rgba(168, 85, 247, 0.32);
    --tooltip-text: #0f172a;
  }

  .light-theme svg text[fill="white"] {
    fill: #0f172a !important;
  }

  .light-theme button[class*="bg-fuchsia-500"],
  .light-theme button[class*="bg-fuchsia-500"] * {
    color: #ffffff !important;
  }

  .light-theme .date-picker-popover .text-zinc-400,
  .light-theme .date-picker-popover .text-zinc-500 {
    color: #64748b !important;
  }

  .light-theme .date-picker-popover .text-fuchsia-300,
  .light-theme .date-picker-popover .text-fuchsia-200 {
    color: #d946ef !important;
  }

  .light-theme .view-all-button {
    background: #d946ef !important;
    color: #ffffff !important;
    border-color: rgba(217, 70, 239, 0.70) !important;
    box-shadow: 0 10px 24px rgba(217, 70, 239, 0.20) !important;
  }

  .light-theme .view-all-button:hover {
    background: #c026d3 !important;
    color: #ffffff !important;
  }

  .light-theme .activity-stat-emerald {
    background: linear-gradient(135deg, #ecfdf5 0%, #ffffff 55%, #d1fae5 100%) !important;
    border-color: rgba(16, 185, 129, 0.55) !important;
    color: #047857 !important;
  }

  .light-theme .activity-stat-red {
    background: linear-gradient(135deg, #fef2f2 0%, #ffffff 55%, #fee2e2 100%) !important;
    border-color: rgba(239, 68, 68, 0.55) !important;
    color: #dc2626 !important;
  }

  .light-theme .activity-stat-fuchsia {
    background: linear-gradient(135deg, #faf5ff 0%, #ffffff 55%, #f5d0fe 100%) !important;
    border-color: rgba(217, 70, 239, 0.55) !important;
    color: #c026d3 !important;
  }

  .activity-day-cell {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06);
  }

  .activity-day-empty {
    background: linear-gradient(135deg, rgba(24,24,27,0.82) 0%, rgba(0,0,0,0.92) 58%, rgba(88,28,135,0.16) 100%) !important;
    border-color: rgba(168, 85, 247, 0.18) !important;
  }

  .activity-day-win {
    background: linear-gradient(135deg, #34d399 0%, #10b981 55%, #047857 100%) !important;
    border-color: rgba(16, 185, 129, 0.78) !important;
    box-shadow: 0 0 22px rgba(16,185,129,0.28), inset 0 1px 0 rgba(255,255,255,0.22) !important;
  }

  .activity-day-loss {
    background: linear-gradient(135deg, #fb7185 0%, #ef4444 55%, #b91c1c 100%) !important;
    border-color: rgba(239, 68, 68, 0.78) !important;
    box-shadow: 0 0 22px rgba(239,68,68,0.28), inset 0 1px 0 rgba(255,255,255,0.22) !important;
  }

  .activity-day-win:hover {
    box-shadow: 0 0 30px rgba(16,185,129,0.42), 0 10px 24px rgba(16,185,129,0.20) !important;
  }

  .activity-day-loss:hover {
    box-shadow: 0 0 30px rgba(239,68,68,0.42), 0 10px 24px rgba(239,68,68,0.20) !important;
  }

  .activity-day-selected.activity-day-win {
    box-shadow: 0 0 0 2px rgba(217,70,239,.55), 0 0 30px rgba(16,185,129,0.38) !important;
  }

  .activity-day-selected.activity-day-loss {
    box-shadow: 0 0 0 2px rgba(217,70,239,.55), 0 0 30px rgba(239,68,68,0.38) !important;
  }

  .light-theme .activity-day-empty {
    background: linear-gradient(135deg, #ffffff 0%, #faf5ff 58%, #f5d0fe 100%) !important;
    border-color: rgba(168, 85, 247, 0.28) !important;
    box-shadow: inset 0 0 18px rgba(217, 70, 239, 0.08) !important;
  }

  .light-theme .activity-day-win {
    background: linear-gradient(135deg, #34d399 0%, #10b981 60%, #059669 100%) !important;
    border-color: rgba(5, 150, 105, 0.65) !important;
    box-shadow: 0 10px 24px rgba(16, 185, 129, 0.22), inset 0 1px 0 rgba(255,255,255,0.22) !important;
  }

  .light-theme .activity-day-loss {
    background: linear-gradient(135deg, #fb7185 0%, #ef4444 60%, #dc2626 100%) !important;
    border-color: rgba(220, 38, 38, 0.65) !important;
    box-shadow: 0 10px 24px rgba(239, 68, 68, 0.22), inset 0 1px 0 rgba(255,255,255,0.22) !important;
  }

  .light-theme .trade-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #ffffff 100%) !important;
    border-color: rgba(217, 70, 239, 0.42) !important;
    box-shadow: 0 16px 42px rgba(168, 85, 247, 0.12) !important;
  }

  .light-theme .trade-screenshot-area {
    background: linear-gradient(135deg, #f8fafc 0%, #ffffff 52%, #faf5ff 100%) !important;
    border-bottom: 1px solid rgba(168, 85, 247, 0.16) !important;
  }

  .light-theme .trade-screenshot-image {
    opacity: 1 !important;
    filter: contrast(1.08) saturate(1.05) !important;
  }

  .light-theme .trade-no-screenshot {
    background: linear-gradient(135deg, #ffffff 0%, #fdf4ff 55%, #faf5ff 100%) !important;
    color: #7e22ce !important;
  }

  .light-theme .trade-no-screenshot-icon {
    background: rgba(217, 70, 239, 0.14) !important;
    border-color: rgba(217, 70, 239, 0.36) !important;
    color: #d946ef !important;
    box-shadow: 0 10px 26px rgba(217, 70, 239, 0.14) !important;
  }

  .light-theme .trade-no-screenshot-text {
    color: #7e22ce !important;
    font-weight: 900 !important;
  }

  .light-theme .trade-tag {
    background: linear-gradient(135deg, rgba(217, 70, 239, 0.20), rgba(168, 85, 247, 0.10)) !important;
    border-color: rgba(217, 70, 239, 0.55) !important;
    color: #86198f !important;
    box-shadow: 0 8px 20px rgba(217, 70, 239, 0.16) !important;
  }

  .light-theme .trade-analysis-note {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border: 1px solid rgba(168, 85, 247, 0.24) !important;
    box-shadow: 0 10px 28px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme .best-performance-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 52%, #f3e8ff 100%) !important;
    border-color: rgba(217, 70, 239, 0.30) !important;
    box-shadow: 0 12px 30px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .best-performance-card:hover {
    border-color: rgba(217, 70, 239, 0.75) !important;
    box-shadow: 0 0 32px rgba(217, 70, 239, 0.22) !important;
  }

  .light-theme .best-performance-card .text-white {
    color: #0f172a !important;
  }

  .weekday-card {
    min-height: 180px;
    border-radius: 0.75rem;
    padding: 1.25rem;
    background: linear-gradient(135deg, rgba(0,0,0,.88), rgba(10,6,15,.94) 55%, rgba(88,28,135,.18));
    transition: all .3s ease;
  }

  .weekday-card:hover,
  .weekday-card-active {
    transform: translateY(-4px);
    background: linear-gradient(135deg, rgba(0,0,0,.94), rgba(12,8,18,.94) 48%, rgba(88,28,135,.30));
    box-shadow: 0 0 26px rgba(217,70,239,.16);
  }

  .strategy-detail-card,
  .strategy-summary-row,
  .statistics-pattern-panel,
  .statistics-tabs {
    position: relative;
    overflow: hidden;
  }

  .statistics-tabs::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(217,70,239,.08), transparent 45%, rgba(16,185,129,.035));
    pointer-events: none;
  }

  .statistics-tab {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: .5rem;
    border-radius: .85rem;
    padding: .75rem 1.25rem;
    font-size: .875rem;
    font-weight: 900;
    color: #a1a1aa;
    transition: all .25s ease;
  }

  .statistics-tab:hover {
    color: #fff;
    background: rgba(217,70,239,.10);
    box-shadow: 0 0 18px rgba(217,70,239,.10);
  }

  .statistics-tab-active {
    color: #ffffff;
    background: linear-gradient(135deg, rgba(217,70,239,.95), rgba(168,85,247,.78));
    box-shadow: 0 0 22px rgba(217,70,239,.28), inset 0 1px 0 rgba(255,255,255,.18);
  }

  .statistics-tab-icon {
    display: inline-flex;
    height: 1.35rem;
    width: 1.35rem;
    align-items: center;
    justify-content: center;
    border-radius: .45rem;
    background: rgba(255,255,255,.08);
    color: currentColor;
    font-size: .78rem;
  }

  .statistics-tab-active .statistics-tab-icon {
    background: rgba(255,255,255,.18);
  }

  .dashboard-hero,
  .dashboard-panel,
  .dashboard-activity-card,
  .dashboard-recent-list,
  .dashboard-routine-card,
  .journal-hero,
  .journal-search-panel,
  .journal-sort-panel {
    position: relative;
    overflow: hidden;
  }

  .dashboard-panel::before,
  .dashboard-activity-card::before,
  .dashboard-recent-list::before,
  .dashboard-routine-card::before,
  .journal-hero::before,
  .journal-search-panel::before,
  .journal-sort-panel::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: linear-gradient(135deg, rgba(217,70,239,.12), transparent 42%, rgba(16,185,129,.04));
  }

  .dashboard-panel > *,
  .dashboard-activity-card > *,
  .dashboard-recent-list > *,
  .dashboard-routine-card > *,
  .journal-hero > *,
  .journal-search-panel > *,
  .journal-sort-panel > * {
    position: relative;
    z-index: 1;
  }

  .dashboard-activity-card {
    overflow: visible !important;
  }

  .dashboard-activity-card .light-tooltip {
    z-index: 9999 !important;
  }

  .dashboard-activity-card .activity-day-cell {
    overflow: visible !important;
  }

  .dashboard-performance-card,
  .dashboard-score-card {
    position: relative;
    overflow: hidden;
  }

  .dashboard-performance-card:hover,
  .dashboard-score-card:hover {
    border-color: rgba(217,70,239,.55) !important;
    box-shadow: 0 0 34px rgba(217,70,239,.16), 0 20px 55px rgba(16,185,129,.08) !important;
  }

  .dashboard-chart-summary {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .dashboard-chart-area,
  .dashboard-radar-card,
  .dashboard-score-summary {
    backdrop-filter: blur(10px);
  }

  .dashboard-performance-tab,
  .dashboard-performance-tab-active {
    transition: all .25s ease !important;
  }

  .dashboard-performance-tab:hover,
  .dashboard-performance-tab-active:hover {
    transform: translateY(-1px);
  }

  .light-theme .dashboard-performance-card,
  .light-theme .dashboard-score-card,
  .light-theme .dashboard-chart-area,
  .light-theme .dashboard-radar-card,
  .light-theme .dashboard-score-summary,
  .light-theme .dashboard-chart-summary {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(217,70,239,.28) !important;
    box-shadow: 0 18px 42px rgba(168,85,247,.10) !important;
  }

  .light-theme .dashboard-section-icon {
    background: rgba(217,70,239,.12) !important;
    color: #c026d3 !important;
    border-color: rgba(217,70,239,.35) !important;
  }

  .dashboard-primary-btn,
  .dashboard-start-btn {
    transition: all .25s ease !important;
  }

  .dashboard-primary-btn:hover,
  .dashboard-start-btn:hover {
    transform: translateY(-1px) scale(1.02);
  }

  .dashboard-inspiration {
    backdrop-filter: blur(10px);
  }

  .dashboard-dash-card::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,.08), transparent 42%, rgba(217,70,239,.08));
    opacity: 0;
    transition: opacity .25s ease;
    pointer-events: none;
  }

  .dashboard-dash-card:hover::before {
    opacity: 1;
  }

  .dashboard-recent-row:hover img {
    transform: scale(1.06);
  }

  .light-theme .dashboard-hero,
  .light-theme .dashboard-panel,
  .light-theme .dashboard-activity-card,
  .light-theme .dashboard-recent-list,
  .light-theme .dashboard-routine-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(217,70,239,.28) !important;
    box-shadow: 0 18px 42px rgba(168,85,247,.10) !important;
  }

  .light-theme .dashboard-inspiration {
    background: linear-gradient(135deg, #ffffff 0%, #faf5ff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(217,70,239,.24) !important;
  }

  .light-theme .dashboard-dash-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 54%, #f8fbff 100%) !important;
    color: #0f172a !important;
    box-shadow: 0 14px 34px rgba(168,85,247,.10) !important;
  }

  .journal-action-btn {
    transition: all .25s ease !important;
  }

  .journal-action-btn:hover {
    border-color: rgba(217,70,239,.65) !important;
    color: #f0abfc !important;
    box-shadow: 0 0 18px rgba(217,70,239,.16) !important;
    transform: translateY(-1px);
  }

  .journal-add-btn {
    transition: all .25s ease !important;
  }

  .journal-add-btn:hover {
    background: #c026d3 !important;
    box-shadow: 0 0 26px rgba(217,70,239,.34) !important;
    transform: translateY(-1px) scale(1.02);
  }

  .journal-empty {
    box-shadow: 0 18px 42px rgba(217,70,239,.10);
  }

  .journal-metric-box {
    background: linear-gradient(135deg, rgba(217,70,239,.14), rgba(88,28,135,.10) 55%, rgba(0,0,0,.22)) !important;
  }

  .journal-list-metric-chip {
    border: 1px solid rgba(217,70,239,.35);
    background: rgba(217,70,239,.12);
    color: #f0abfc;
    border-radius: 999px;
    padding: .35rem .7rem;
    font-weight: 900;
    box-shadow: 0 0 14px rgba(217,70,239,.10);
  }

  .light-theme .journal-hero,
  .light-theme .journal-search-panel,
  .light-theme .journal-sort-panel,
  .light-theme .journal-empty {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(217,70,239,.28) !important;
    box-shadow: 0 18px 42px rgba(168,85,247,.10) !important;
  }

  .light-theme .journal-metric-box {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 52%, #f3e8ff 100%) !important;
    border-color: rgba(217,70,239,.38) !important;
    box-shadow: 0 10px 24px rgba(217,70,239,.10) !important;
  }

  .light-theme .journal-metric-box .text-white {
    color: #0f172a !important;
  }

  .light-theme .journal-list-metric-chip {
    background: linear-gradient(135deg, #ffffff, #faf5ff) !important;
    color: #86198f !important;
    border-color: rgba(217,70,239,.40) !important;
    box-shadow: 0 8px 20px rgba(217,70,239,.10) !important;
  }

  .light-theme .journal-hero-icon {
    background: rgba(217,70,239,.12) !important;
    border-color: rgba(217,70,239,.35) !important;
    color: #c026d3 !important;
  }

  .light-theme .journal-action-btn {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168,85,247,.28) !important;
  }

  .light-theme .journal-action-btn:hover {
    background: #faf5ff !important;
    color: #86198f !important;
    border-color: rgba(217,70,239,.55) !important;
  }

  .light-theme .journal-add-btn,
  .light-theme .journal-add-btn * {
    color: #ffffff !important;
  }

  .light-theme .statistics-tabs {
    background: #ffffff !important;
    border-color: rgba(217,70,239,.28) !important;
    box-shadow: 0 14px 34px rgba(168,85,247,.10) !important;
  }

  .light-theme .statistics-tab {
    color: #64748b !important;
  }

  .light-theme .statistics-tab:hover {
    color: #86198f !important;
    background: rgba(217,70,239,.10) !important;
  }

  .light-theme .statistics-tab-active {
    color: #ffffff !important;
    background: linear-gradient(135deg, #d946ef, #a855f7) !important;
    box-shadow: 0 0 22px rgba(217,70,239,.22) !important;
  }

  .statistics-strategy-panel,
  .charts-pro-card {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .light-theme .weekday-card,
  .light-theme .strategy-detail-card,
  .light-theme .strategy-summary-row,
  .light-theme .statistics-pattern-panel,
  .light-theme .statistics-strategy-panel,
  .light-theme .charts-pro-card {
    background: linear-gradient(135deg, #ffffff, #fbf7ff 55%, #f3e8ff) !important;
    color: #0f172a !important;
    border: 1px solid rgba(168,85,247,.22) !important;
  }

  .statistics-pattern-pro {
    position: relative;
    overflow: hidden;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 24px 60px rgba(0,0,0,.28);
  }

  .weekday-card-pro:hover,
  .weekday-card-pro.weekday-card-active {
    box-shadow: 0 0 30px rgba(217,70,239,.18), inset 0 1px 0 rgba(255,255,255,.05) !important;
  }

  .light-theme .statistics-pattern-pro {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    border-color: rgba(217, 70, 239, 0.26) !important;
    box-shadow: 0 18px 42px rgba(168,85,247,.10) !important;
  }

  .light-theme .weekday-card-pro {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #f3e8ff 100%) !important;
    border-color: rgba(168, 85, 247, 0.24) !important;
    box-shadow: 0 12px 30px rgba(168,85,247,.08) !important;
  }

  .light-theme .weekday-card-pro:hover,
  .light-theme .weekday-card-pro.weekday-card-active {
    border-color: rgba(217,70,239,.65) !important;
    box-shadow: 0 0 28px rgba(217,70,239,.16) !important;
  }

  .light-theme .weekday-card-pro .text-white {
    color: #0f172a !important;
  }

  .statistics-strategy-panel,
  .charts-pro-card {
    position: relative;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 24px 60px rgba(0,0,0,.28);
  }

  .strategy-detail-pro:hover,
  .strategy-rank-row:hover,
  .charts-pro-card:hover {
    box-shadow: 0 0 30px rgba(217,70,239,.18), inset 0 1px 0 rgba(255,255,255,.05) !important;
  }

  .light-theme .statistics-strategy-panel,
  .light-theme .charts-pro-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f8fbff 100%) !important;
    border-color: rgba(217, 70, 239, 0.26) !important;
    box-shadow: 0 18px 42px rgba(168,85,247,.10) !important;
  }

  .light-theme .strategy-rank-row,
  .light-theme .strategy-detail-pro {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #f3e8ff 100%) !important;
    border-color: rgba(168, 85, 247, 0.24) !important;
  }

  .light-theme .statistics-chart-panel {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border: 1px solid rgba(168, 85, 247, 0.20) !important;
    box-shadow: 0 16px 42px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .statistics-timeline-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 48%, #f3e8ff 100%) !important;
    border-color: rgba(217, 70, 239, 0.32) !important;
  }

  .light-theme .statistics-timeline-card:hover {
    border-color: rgba(217, 70, 239, 0.70) !important;
    box-shadow: 0 0 34px rgba(217, 70, 239, 0.18) !important;
  }

  .light-theme .statistics-winloss-card {
    background: linear-gradient(135deg, #ffffff 0%, #ecfdf5 48%, #faf5ff 100%) !important;
    border-color: rgba(16, 185, 129, 0.30) !important;
  }

  .light-theme .statistics-winloss-card:hover {
    border-color: rgba(16, 185, 129, 0.65) !important;
    box-shadow: 0 0 34px rgba(16, 185, 129, 0.16) !important;
  }

  .light-theme .statistics-winloss-circle {
    background: #ffffff !important;
    box-shadow: 0 16px 40px rgba(16, 185, 129, 0.12) !important;
  }

  .light-theme .statistics-chart-panel .text-white {
    color: #0f172a !important;
  }

  .light-theme .calendar-hero,
  .light-theme .calendar-shell,
  .light-theme .calendar-selected-panel,
  .light-theme .calendar-hero-pro,
  .light-theme .calendar-shell-pro,
  .light-theme .calendar-selected-pro {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 56%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.28) !important;
    box-shadow: 0 18px 42px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .calendar-nav-button {
    background: #ffffff !important;
    color: #86198f !important;
    border: 1px solid rgba(168, 85, 247, 0.30) !important;
    box-shadow: 0 8px 22px rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .calendar-top-pill {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.30) !important;
    box-shadow: 0 8px 22px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme .calendar-top-pill-neutral {
    background: linear-gradient(135deg, #ffffff 0%, #faf5ff 100%) !important;
    color: #86198f !important;
    border-color: rgba(217, 70, 239, 0.35) !important;
  }

  .light-theme .calendar-top-pill-green {
    background: linear-gradient(135deg, #ecfdf5 0%, #ffffff 100%) !important;
    color: #047857 !important;
    border-color: rgba(16, 185, 129, 0.45) !important;
  }

  .light-theme .calendar-top-pill-red {
    background: linear-gradient(135deg, #fef2f2 0%, #ffffff 100%) !important;
    color: #dc2626 !important;
    border-color: rgba(239, 68, 68, 0.45) !important;
  }

  .light-theme .calendar-top-pill-label {
    color: #64748b !important;
  }

  .calendar-hero-pro,
  .calendar-shell-pro,
  .calendar-selected-pro {
    position: relative;
    overflow: hidden;
  }

  .calendar-shell-pro::before,
  .calendar-selected-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: linear-gradient(135deg, rgba(217,70,239,.10), transparent 42%, rgba(16,185,129,.04));
  }

  .calendar-shell-pro > *,
  .calendar-selected-pro > * {
    position: relative;
    z-index: 1;
  }

  .calendar-day {
    overflow: hidden;
  }

  .calendar-day-simple {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .calendar-day-simple:hover {
    transform: none !important;
  }

  .calendar-day-badge {
    border-width: 1px;
    border-radius: 999px;
    padding: .25rem .55rem;
    font-size: .7rem;
    font-weight: 900;
  }

  .calendar-pnl {
    width: fit-content !important;
    max-width: max-content !important;
    min-width: 0 !important;
    margin-left: auto !important;
    white-space: nowrap !important;
    line-height: 1 !important;
    transform: none !important;
    transform-origin: right center;
  }

  .calendar-day-number,
  .calendar-day-number-muted {
    position: relative;
    z-index: 20;
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    height: 1.75rem !important;
    min-width: 1.75rem !important;
    padding: 0 .25rem !important;
    border-radius: .65rem !important;
    font-size: 18px !important;
    line-height: 1 !important;
    text-shadow: 0 2px 12px rgba(0,0,0,.45);
  }

  .calendar-day-number {
    background: rgba(255,255,255,.06) !important;
  }

  .calendar-day-number-muted {
    background: rgba(255,255,255,.03) !important;
  }

  .calendar-day::before {
    content: none;
  }

  .calendar-day-empty {
    border-color: rgba(217, 70, 239, 0.34) !important;
    background: radial-gradient(circle at top right, rgba(217,70,239,.13), #050505 48%) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 0 16px rgba(217,70,239,.12) !important;
  }

  .calendar-day-win {
    border-color: rgba(16, 185, 129, 0.48) !important;
    background: rgba(6, 78, 59, 0.22) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-loss {
    border-color: rgba(239, 68, 68, 0.48) !important;
    background: rgba(127, 29, 29, 0.22) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-breakeven {
    border-color: rgba(245, 158, 11, 0.48) !important;
    background: rgba(120, 53, 15, 0.22) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-weekend {
    border-color: rgba(217, 70, 239, 0.32) !important;
    background: radial-gradient(circle at top right, rgba(217,70,239,.12), #070707 50%) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 0 16px rgba(217,70,239,.12) !important;
  }

  .calendar-day-empty:hover,
  .calendar-day-weekend:hover {
    border-color: rgba(217,70,239,.34) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 0 16px rgba(217,70,239,.12) !important;
  }

  .calendar-day-win:hover {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-loss:hover {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-breakeven:hover {
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-day-selected {
    border-color: rgba(217, 70, 239, 0.85) !important;
    box-shadow: 0 0 0 1px rgba(217,70,239,0.32), 0 0 28px rgba(217,70,239,0.28) !important;
  }

  .calendar-neon-panel::after {
    content: "";
    position: absolute;
    inset: -1px;
    pointer-events: none;
    border-radius: inherit;
    box-shadow: inset 0 0 22px rgba(217,70,239,.10), 0 0 28px rgba(217,70,239,.10);
  }

  .calendar-week-header {
    box-shadow: 0 0 14px rgba(217,70,239,.08) !important;
  }

  .light-theme .calendar-day-empty {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f5f3ff 100%) !important;
    border-color: rgba(168, 85, 247, 0.28) !important;
    box-shadow: 0 10px 24px rgba(168,85,247,.08) !important;
  }

  .light-theme .calendar-day-win {
    background: linear-gradient(135deg, #ecfdf5 0%, #ffffff 52%, #d1fae5 100%) !important;
    border-color: rgba(16, 185, 129, 0.58) !important;
    box-shadow: 0 12px 28px rgba(16, 185, 129, 0.13) !important;
  }

  .light-theme .calendar-day-loss {
    background: linear-gradient(135deg, #fef2f2 0%, #ffffff 52%, #fee2e2 100%) !important;
    border-color: rgba(239, 68, 68, 0.58) !important;
    box-shadow: 0 12px 28px rgba(239, 68, 68, 0.13) !important;
  }

  .light-theme .calendar-day-breakeven {
    background: linear-gradient(135deg, #fffbeb 0%, #ffffff 52%, #fef3c7 100%) !important;
    border-color: rgba(245, 158, 11, 0.58) !important;
    box-shadow: 0 12px 28px rgba(245, 158, 11, 0.13) !important;
  }

  .light-theme .calendar-day-weekend {
    background: linear-gradient(135deg, #faf5ff 0%, #ffffff 58%, #f5d0fe 100%) !important;
    border-color: rgba(217, 70, 239, 0.32) !important;
  }

  .light-theme .calendar-day-number {
    color: #0f172a !important;
    background: rgba(168, 85, 247, 0.10) !important;
  }

  .light-theme .calendar-day-number-muted {
    color: #94a3b8 !important;
    background: rgba(148, 163, 184, 0.10) !important;
  }

  .light-theme .calendar-empty-dash,
  .light-theme .calendar-no-trading,
  .light-theme .calendar-no-trades {
    color: #7e22ce !important;
  }

  .light-theme .calendar-trade-count {
    background: rgba(15, 23, 42, 0.08) !important;
    color: #334155 !important;
  }

  .light-theme .calendar-week-summary {
    background: linear-gradient(135deg, #faf5ff 0%, #ffffff 55%, #f5d0fe 100%) !important;
    border-color: rgba(217, 70, 239, 0.42) !important;
    box-shadow: 0 12px 30px rgba(217,70,239,0.10) !important;
  }

  .light-theme .calendar-week-header {
    color: #64748b !important;
    border-color: rgba(148, 163, 184, 0.22) !important;
  }

  .light-theme .calendar-week-header-special {
    background: linear-gradient(135deg, #faf5ff, #ffffff) !important;
    color: #c026d3 !important;
    border-color: rgba(217,70,239,0.35) !important;
  }

  .light-theme .light-tooltip {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.32) !important;
    box-shadow: 0 18px 45px rgba(15, 23, 42, 0.16) !important;
  }

  .light-theme .light-tooltip * {
    color: #0f172a !important;
  }

  .light-theme button[class*="bg-black"],
  .light-theme button[class*="bg-zinc-950"],
  .light-theme button[class*="bg-zinc-900"],
  .light-theme [role="button"][class*="bg-black"] {
    background: #ffffff !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.30) !important;
    box-shadow: 0 8px 22px rgba(168, 85, 247, 0.08) !important;
  }

  .light-theme button[class*="bg-black"]:hover,
  .light-theme button[class*="bg-zinc-950"]:hover,
  .light-theme button[class*="bg-zinc-900"]:hover {
    background: #faf5ff !important;
    color: #0f172a !important;
    border-color: rgba(217, 70, 239, 0.55) !important;
    box-shadow: 0 12px 30px rgba(168, 85, 247, 0.14) !important;
  }

  .light-theme button[class*="bg-fuchsia-500"],
  .light-theme .view-all-button,
  .light-theme button[class*="bg-emerald-500"],
  .light-theme button[class*="bg-red-600"] {
    color: #ffffff !important;
  }

  .light-theme .rounded-xl[class*="bg-zinc-950"],
  .light-theme .rounded-2xl[class*="bg-black"],
  .light-theme section[class*="bg-zinc-950"],
  .light-theme section[class*="to-black"],
  .light-theme .space-y-5 > div,
  .light-theme .space-y-6 > div[class*="bg-zinc-950"],
  .light-theme .space-y-6 > div[class*="bg-black"],
  .light-theme .grid > div[class*="bg-zinc-950"],
  .light-theme .grid > div[class*="bg-black"] {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #f8fbff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.22) !important;
  }

  .light-theme .fixed .bg-black,
  .light-theme .fixed .bg-zinc-950 {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #ffffff 100%) !important;
    color: #0f172a !important;
  }

  .light-theme .rounded-full[class*="bg-white/10"],
  .light-theme .rounded-full[class*="bg-white/5"],
  .light-theme .rounded-md[class*="bg-white/10"],
  .light-theme .rounded-md[class*="bg-white/5"] {
    background: rgba(168, 85, 247, 0.10) !important;
    color: #0f172a !important;
    border-color: rgba(168, 85, 247, 0.20) !important;
  }

  .trade-context-modern {
    position: relative;
  }

  .trade-context-modern::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.12), transparent 34%), radial-gradient(circle at bottom right, rgba(16,185,129,.07), transparent 30%);
  }

  .trade-context-modern > * {
    position: relative;
    z-index: 1;
  }

  .trade-context-card {
    border: 1px solid rgba(255,255,255,.09);
    background: linear-gradient(135deg, rgba(255,255,255,.035), rgba(0,0,0,.42));
    border-radius: 1rem;
    padding: 1rem;
    transition: all .25s ease;
  }

  .trade-context-card:hover {
    border-color: rgba(217,70,239,.38);
    background: linear-gradient(135deg, rgba(217,70,239,.075), rgba(0,0,0,.44));
    box-shadow: 0 0 18px rgba(217,70,239,.10);
  }

  .trade-context-modern label > span:first-child {
    color: #d4d4d8 !important;
    font-size: .78rem !important;
    font-weight: 900 !important;
    letter-spacing: .02em !important;
  }

  .trade-context-result {
    min-height: 2.5rem;
    display: flex;
    align-items: center;
    border-radius: .75rem;
    border-width: 1px;
    padding: .65rem .85rem;
    font-weight: 900;
  }

  .trade-context-modern .custom-select-trigger,
  .trade-context-input {
    height: 2.75rem !important;
    border-radius: .8rem !important;
    background: rgba(0,0,0,.42) !important;
    border-color: rgba(255,255,255,.10) !important;
    box-shadow: none !important;
  }

  .trade-context-modern .custom-select-trigger:hover,
  .trade-context-modern .custom-select-trigger:focus,
  .trade-context-input:hover,
  .trade-context-input:focus {
    border-color: rgba(217,70,239,.50) !important;
    box-shadow: 0 0 0 1px rgba(217,70,239,.12), 0 0 18px rgba(217,70,239,.10) !important;
  }

  .trade-context-modern .custom-select-selected,
  .trade-context-modern .custom-select-selected span {
    color: #f4f4f5 !important;
  }

  .trade-context-modern .custom-select-menu {
    border-radius: 1rem !important;
    padding: .35rem !important;
    background: #060606 !important;
    border-color: rgba(217,70,239,.28) !important;
    box-shadow: 0 18px 45px rgba(0,0,0,.90), 0 0 20px rgba(217,70,239,.10) !important;
  }

  .trade-context-modern .custom-select-option {
    min-height: 2.4rem !important;
    border-radius: .75rem !important;
    color: #d4d4d8 !important;
    background: transparent !important;
    box-shadow: none !important;
  }

  .trade-context-modern .custom-select-option span {
    color: inherit !important;
  }

  .trade-context-modern .custom-select-option:hover {
    background: rgba(217,70,239,.12) !important;
    color: #f5d0fe !important;
  }

  .trade-context-modern .custom-select-active {
    background: linear-gradient(135deg, rgba(217,70,239,.30), rgba(168,85,247,.16)) !important;
    color: #ffffff !important;
    border: 1px solid rgba(217,70,239,.32) !important;
  }

  .trade-context-modern .custom-select-option-buy,
  .trade-context-modern .custom-select-option-win,
  .trade-context-modern .custom-select-option-a,
  .trade-context-modern .custom-select-option-yes,
  .trade-context-modern .custom-select-option-calm,
  .trade-context-modern .custom-select-option-confident {
    color: #86efac !important;
  }

  .trade-context-modern .custom-select-option-sell,
  .trade-context-modern .custom-select-option-loss,
  .trade-context-modern .custom-select-option-d,
  .trade-context-modern .custom-select-option-no,
  .trade-context-modern .custom-select-option-revenge,
  .trade-context-modern .custom-select-option-fomo {
    color: #fca5a5 !important;
  }

  .light-theme .trade-context-modern,
  .light-theme .trade-context-card {
    background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 58%, #ffffff 100%) !important;
    color: #0f172a !important;
    border-color: rgba(168,85,247,.24) !important;
  }

  .light-theme .trade-context-modern .custom-select-trigger,
  .light-theme .trade-context-input,
  .light-theme .trade-context-card {
    background: #ffffff !important;
    color: #0f172a !important;
  }

  .light-theme .trade-context-modern .custom-select-selected,
  .light-theme .trade-context-modern .custom-select-selected span {
    color: #0f172a !important;
  }

  .session-neon {
    border: 1px solid transparent !important;
    background: rgba(0,0,0,.18) !important;
    letter-spacing: .015em !important;
    text-shadow: 0 0 10px currentColor !important;
  }

  .session-neon-asia,
  .custom-select-selected.custom-select-option-asia,
  .custom-select-selected.custom-select-option-asia span {
    color: #60a5fa !important;
  }

  .session-neon-london,
  .custom-select-selected.custom-select-option-london,
  .custom-select-selected.custom-select-option-london span {
    color: #fb7185 !important;
  }

  .session-neon-nyam,
  .custom-select-selected.custom-select-option-ny-am,
  .custom-select-selected.custom-select-option-ny-am span {
    color: #34d399 !important;
  }

  .session-neon-lunch,
  .custom-select-selected.custom-select-option-lunch,
  .custom-select-selected.custom-select-option-lunch span {
    color: #fbbf24 !important;
  }

  .session-neon-nypm,
  .custom-select-selected.custom-select-option-ny-pm,
  .custom-select-selected.custom-select-option-ny-pm span {
    color: #f472b6 !important;
  }

  .session-neon-premarket,
  .custom-select-selected.custom-select-option-pre-market,
  .custom-select-selected.custom-select-option-pre-market span {
    color: #22d3ee !important;
  }

  .session-neon-asia:hover,
  .session-active-asia { border-color: rgba(96,165,250,.55) !important; background: rgba(37,99,235,.16) !important; box-shadow: inset 0 0 18px rgba(59,130,246,.12), 0 0 16px rgba(59,130,246,.18) !important; }
  .session-neon-london:hover,
  .session-active-london { border-color: rgba(251,113,133,.55) !important; background: rgba(239,68,68,.16) !important; box-shadow: inset 0 0 18px rgba(239,68,68,.12), 0 0 16px rgba(239,68,68,.18) !important; }
  .session-neon-nyam:hover,
  .session-active-nyam { border-color: rgba(52,211,153,.55) !important; background: rgba(16,185,129,.16) !important; box-shadow: inset 0 0 18px rgba(16,185,129,.12), 0 0 16px rgba(16,185,129,.20) !important; }
  .session-neon-lunch:hover,
  .session-active-lunch { border-color: rgba(251,191,36,.55) !important; background: rgba(245,158,11,.16) !important; box-shadow: inset 0 0 18px rgba(245,158,11,.12), 0 0 16px rgba(245,158,11,.18) !important; }
  .session-neon-nypm:hover,
  .session-active-nypm { border-color: rgba(244,114,182,.60) !important; background: rgba(217,70,239,.16) !important; box-shadow: inset 0 0 18px rgba(217,70,239,.12), 0 0 16px rgba(217,70,239,.20) !important; }
  .session-neon-premarket:hover,
  .session-active-premarket { border-color: rgba(34,211,238,.55) !important; background: rgba(6,182,212,.16) !important; box-shadow: inset 0 0 18px rgba(6,182,212,.12), 0 0 16px rgba(6,182,212,.18) !important; }


  .pnl-switcher {
    display: inline-flex;
    align-items: baseline;
    gap: .5rem;
    animation: pnlSwitcherSlide 1.15s cubic-bezier(.2,.8,.2,1) both;
  }

  .pnl-switcher-label {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    border: 1px solid rgba(217,70,239,.28);
    background: rgba(217,70,239,.12);
    padding: .18rem .45rem;
    font-size: .62rem;
    font-weight: 950;
    color: #f0abfc;
    letter-spacing: .08em;
    vertical-align: middle;
    box-shadow: 0 0 14px rgba(217,70,239,.12);
  }

  @keyframes pnlSwitcherSlide {
    0% { opacity: 0; transform: translateY(12px) scale(.96); filter: brightness(.85); }
    65% { opacity: 1; transform: translateY(0) scale(1.025); filter: brightness(1.22); }
    100% { opacity: 1; transform: translateY(0) scale(1); filter: brightness(1); }
  }

  .animated-number {
    display: inline-block;
    font-variant-numeric: tabular-nums;
    letter-spacing: -0.02em;
    animation: animatedNumberPop .95s ease both;
    text-shadow: 0 0 18px rgba(217,70,239,.22), 0 0 28px rgba(255,255,255,.08);
  }

  @keyframes animatedNumberPop {
    0% { opacity: .35; transform: translateY(8px) scale(.96); filter: brightness(.8); }
    55% { opacity: 1; transform: translateY(0) scale(1.025); filter: brightness(1.25); }
    100% { opacity: 1; transform: translateY(0) scale(1); filter: brightness(1); }
  }

  .moving-text-wrap {
    position: relative;
    overflow: hidden;
    width: 100%;
    min-height: 74px;
    border-radius: 1.1rem;
    padding: 0;
    isolation: isolate;
    background: linear-gradient(135deg, rgba(0,0,0,.58), rgba(88,28,135,.18) 50%, rgba(0,0,0,.58));
    border: 1px solid rgba(217,70,239,.25);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.08), 0 0 28px rgba(217,70,239,.10);
  }

  .moving-text-wrap::before {
    content: "";
    position: absolute;
    inset: 0;
    z-index: 1;
    pointer-events: none;
    background: radial-gradient(circle at 12% 50%, rgba(217,70,239,.18), transparent 28%), radial-gradient(circle at 88% 50%, rgba(34,197,94,.10), transparent 26%);
  }

  .moving-text-wrap::after {
    content: "";
    position: absolute;
    left: 18%;
    right: 18%;
    top: 0;
    height: 1px;
    z-index: 2;
    background: linear-gradient(to right, transparent, rgba(217,70,239,.85), transparent);
  }

  .moving-text-track {
    position: relative;
    z-index: 2;
    height: 74px;
  }

  .moving-text-slide {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: .85rem;
    padding: 0 1.5rem;
    text-align: center;
    opacity: 0;
    transform: translateY(12px);
    animation: quoteSlideShow 36s ease-in-out infinite;
  }

  .moving-text-slide:nth-child(1) { animation-delay: 0s; }
  .moving-text-slide:nth-child(2) { animation-delay: 6s; }
  .moving-text-slide:nth-child(3) { animation-delay: 12s; }
  .moving-text-slide:nth-child(4) { animation-delay: 18s; }
  .moving-text-slide:nth-child(5) { animation-delay: 24s; }
  .moving-text-slide:nth-child(6) { animation-delay: 30s; }

  .moving-text-item {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: .85rem;
    max-width: 100%;
    font-size: clamp(1.05rem, 1.35vw, 1.35rem);
    font-weight: 950;
    font-style: italic;
    color: #ffffff;
    letter-spacing: .01em;
    text-shadow: 0 0 16px rgba(217,70,239,.50), 0 0 22px rgba(255,255,255,.10);
  }

  .moving-text-spark {
    display: inline-flex;
    height: 1.6rem;
    width: 1.6rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    border: 1px solid rgba(217,70,239,.44);
    background: rgba(217,70,239,.14);
    color: #f0abfc;
    font-size: .72rem;
    font-style: normal;
    box-shadow: 0 0 18px rgba(217,70,239,.24), inset 0 1px 0 rgba(255,255,255,.10);
  }

  .moving-text-divider {
    display: none;
  }

  @keyframes quoteSlideShow {
    0% { opacity: 0; transform: translateY(10px); }
    3% { opacity: 1; transform: translateY(0); }
    13% { opacity: 1; transform: translateY(0); }
    16.66% { opacity: 0; transform: translateY(-10px); }
    100% { opacity: 0; transform: translateY(-10px); }
  }

  .mistake-coach-hero {
    position: relative;
    overflow: hidden;
    border-radius: 2rem;
    border: 1px solid rgba(217,70,239,.26);
    background: linear-gradient(135deg, rgba(10,3,16,.98), rgba(0,0,0,.96) 52%, rgba(20,8,28,.98));
    padding: 1.4rem;
    box-shadow: 0 24px 70px rgba(217,70,239,.13), inset 0 1px 0 rgba(255,255,255,.05);
  }

  .mistake-coach-hero::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.18), transparent 32%), radial-gradient(circle at bottom right, rgba(16,185,129,.10), transparent 34%);
  }

  .coach-flow-step,
  .coach-summary-card,
  .mistake-help-banner,
  .mistake-guide-panel,
  .guide-mini-card,
  .mini-coach-metric {
    position: relative;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.28);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .coach-flow-step {
    display: flex;
    gap: .8rem;
    align-items: flex-start;
    border-radius: 1.25rem;
    padding: 1rem;
  }

  .coach-flow-number {
    display: flex;
    height: 2rem;
    width: 2rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: .8rem;
    border: 1px solid rgba(217,70,239,.35);
    background: rgba(217,70,239,.14);
    color: #f0abfc;
    font-size: .8rem;
    font-weight: 950;
  }

  .coach-summary-card {
    border-radius: 1.6rem;
    border-color: rgba(217,70,239,.24);
    background: linear-gradient(135deg, rgba(255,255,255,.055), rgba(0,0,0,.38));
    padding: 1.25rem;
  }

  .mini-coach-metric {
    border-radius: 1rem;
    padding: .85rem;
  }

  .mini-coach-danger {
    border-color: rgba(239,68,68,.25);
    background: rgba(239,68,68,.10);
  }

  .coach-risk-badge {
    border-radius: 999px;
    padding: .45rem .75rem;
    font-size: .7rem;
    font-weight: 950;
    white-space: nowrap;
  }

  .coach-risk-high { border: 1px solid rgba(239,68,68,.35); background: rgba(239,68,68,.14); color: #fca5a5; }
  .coach-risk-medium { border: 1px solid rgba(245,158,11,.35); background: rgba(245,158,11,.14); color: #fcd34d; }
  .coach-risk-low { border: 1px solid rgba(16,185,129,.35); background: rgba(16,185,129,.14); color: #86efac; }

  .mistake-help-banner {
    display: flex;
    gap: 1rem;
    align-items: flex-start;
    border-radius: 1.5rem;
    border-color: rgba(245,158,11,.28);
    background: rgba(245,158,11,.10);
    padding: 1rem;
  }

  .mistake-guide-panel {
    overflow: hidden;
    border-radius: 1.75rem;
    border-color: rgba(217,70,239,.20);
    background: linear-gradient(135deg, rgba(217,70,239,.08), rgba(0,0,0,.22));
    padding: 1.15rem;
  }

  .mistake-guide-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 1rem;
  }

  .guide-mini-card {
    border-radius: 1.15rem;
    padding: 1rem;
  }

  .mistake-hero-clean,
  .mistake-panel-clean {
    position: relative;
    overflow: hidden;
    border-radius: 2rem;
    border: 1px solid rgba(217,70,239,.22);
    background: linear-gradient(135deg, rgba(10,3,16,.96), rgba(0,0,0,.96) 52%, rgba(16,5,23,.96));
    padding: 1.25rem;
    box-shadow: 0 22px 60px rgba(217,70,239,.10), inset 0 1px 0 rgba(255,255,255,.04);
  }

  .mistake-hero-clean::before,
  .mistake-panel-clean::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(239,68,68,.13), transparent 32%), radial-gradient(circle at bottom right, rgba(217,70,239,.12), transparent 34%);
  }

  .mistake-hero-clean > *,
  .mistake-panel-clean > * {
    position: relative;
    z-index: 1;
  }

  .mistake-panel-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 1rem;
  }

  .mistake-eyebrow {
    font-size: .72rem;
    font-weight: 950;
    text-transform: uppercase;
    letter-spacing: .14em;
  }

  .mistake-badge-red,
  .mistake-badge-green,
  .mistake-badge-amber,
  .mistake-badge-cyan {
    border-radius: 999px;
    padding: .4rem .75rem;
    font-size: .68rem;
    font-weight: 950;
    white-space: nowrap;
  }

  .mistake-badge-red { border: 1px solid rgba(239,68,68,.35); background: rgba(239,68,68,.12); color: #fca5a5; }
  .mistake-badge-green { border: 1px solid rgba(16,185,129,.35); background: rgba(16,185,129,.12); color: #86efac; }
  .mistake-badge-amber { border: 1px solid rgba(245,158,11,.35); background: rgba(245,158,11,.12); color: #fcd34d; }
  .mistake-badge-cyan { border: 1px solid rgba(6,182,212,.35); background: rgba(6,182,212,.12); color: #67e8f9; }

  .issue-clean-card {
    width: 100%;
    border-radius: 1.25rem;
    border: 1px solid rgba(239,68,68,.20);
    background: linear-gradient(135deg, rgba(239,68,68,.08), rgba(0,0,0,.28));
    padding: 1rem;
    text-align: left;
    transition: all .25s ease;
  }

  .issue-clean-card:hover,
  .issue-clean-card-active {
    transform: translateY(-2px);
    border-color: rgba(239,68,68,.58);
    background: linear-gradient(135deg, rgba(239,68,68,.16), rgba(0,0,0,.32));
    box-shadow: 0 0 28px rgba(239,68,68,.14);
  }

  .issue-clean-number,
  .fix-step-number {
    display: flex;
    height: 2.4rem;
    width: 2.4rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: .95rem;
    font-size: .85rem;
    font-weight: 950;
    border: 1px solid rgba(239,68,68,.34);
    background: rgba(239,68,68,.12);
    color: #fca5a5;
  }

  .fix-step-card {
    display: flex;
    gap: .9rem;
    align-items: flex-start;
    border-radius: 1.15rem;
    border: 1px solid rgba(16,185,129,.22);
    background: rgba(16,185,129,.08);
    padding: 1rem;
  }

  .fix-step-number {
    border-color: rgba(16,185,129,.34);
    background: rgba(16,185,129,.12);
    color: #86efac;
  }

  .light-theme .mistake-coach-hero,
  .light-theme .coach-summary-card,
  .light-theme .coach-flow-step,
  .light-theme .mistake-help-banner,
  .light-theme .mistake-guide-panel,
  .light-theme .guide-mini-card,
  .light-theme .mini-coach-metric,
  .light-theme .mistake-hero-clean,
  .light-theme .mistake-panel-clean {
    background: rgba(255,255,255,.88) !important;
    border-color: rgba(226,232,240,.95) !important;
    color: #111827 !important;
    box-shadow: 0 18px 45px rgba(15,23,42,.075) !important;
  }

  .light-theme .mistake-hero-clean::before,
  .light-theme .mistake-panel-clean::before {
    background: radial-gradient(circle at top left, rgba(239,68,68,.08), transparent 32%), radial-gradient(circle at bottom right, rgba(217,70,239,.08), transparent 34%) !important;
  }

  .light-theme .issue-clean-card,
  .light-theme .fix-step-card {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    box-shadow: 0 10px 24px rgba(15,23,42,.045) !important;
  }

  .light-theme .issue-clean-card:hover,
  .light-theme .issue-clean-card-active {
    border-color: rgba(239,68,68,.34) !important;
    box-shadow: 0 16px 34px rgba(239,68,68,.10) !important;
  }

  /* Premium white mode inspired by clean SaaS dashboard styling */
  .light-theme,
  .light-theme main,
  .light-theme body {
    background: radial-gradient(circle at top left, rgba(217,70,239,.10), transparent 30%), linear-gradient(135deg, #f7f8fc 0%, #ffffff 44%, #f8fafc 100%) !important;
    color: #111827 !important;
  }

  .light-theme aside.fixed {
    background: rgba(255,255,255,.92) !important;
    backdrop-filter: blur(18px) !important;
    border-right: 1px solid rgba(226,232,240,.9) !important;
    box-shadow: 18px 0 45px rgba(15,23,42,.06) !important;
  }

  .light-theme aside.fixed button:not(.bg-fuchsia-500),
  .light-theme .account-sidebar-card {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.9) !important;
    color: #111827 !important;
    box-shadow: 0 10px 26px rgba(15,23,42,.055) !important;
  }

  .light-theme aside.fixed button:hover:not(.bg-fuchsia-500),
  .light-theme .account-sidebar-card:hover {
    background: #faf5ff !important;
    border-color: rgba(217,70,239,.30) !important;
    box-shadow: 0 14px 32px rgba(168,85,247,.12) !important;
  }

  .light-theme aside.fixed button.bg-fuchsia-500,
  .light-theme .journal-add-btn,
  .light-theme .dashboard-primary-btn,
  .light-theme button[class*="bg-fuchsia-500"] {
    background: linear-gradient(135deg, #d946ef, #8b5cf6) !important;
    color: #ffffff !important;
    border-color: transparent !important;
    box-shadow: 0 14px 30px rgba(217,70,239,.24) !important;
  }

  .light-theme .dashboard-hero,
  .light-theme .journal-hero,
  .light-theme .calendar-hero-pro,
  .light-theme .dashboard-performance-card,
  .light-theme .dashboard-score-card,
  .light-theme .dashboard-recent-card,
  .light-theme .dashboard-activity-card,
  .light-theme section,
  .light-theme .statistics-chart-panel,
  .light-theme .statistics-pattern-pro,
  .light-theme .statistics-strategy-panel,
  .light-theme .charts-pro-card,
  .light-theme .trade-card,
  .light-theme .journal-search-panel,
  .light-theme .journal-sort-panel,
  .light-theme .calendar-shell-pro,
  .light-theme .calendar-selected-pro,
  .light-theme .trade-context-modern,
  .light-theme .rounded-2xl[class*="bg-gradient"],
  .light-theme .rounded-xl[class*="bg-gradient"] {
    background: rgba(255,255,255,.86) !important;
    backdrop-filter: blur(18px) !important;
    border-color: rgba(226,232,240,.9) !important;
    color: #111827 !important;
    box-shadow: 0 18px 45px rgba(15,23,42,.075) !important;
  }

  .light-theme .dashboard-hero,
  .light-theme .journal-hero,
  .light-theme .calendar-hero-pro {
    background: linear-gradient(135deg, rgba(255,255,255,.96), rgba(250,245,255,.92) 55%, rgba(255,255,255,.96)) !important;
    border-color: rgba(217,70,239,.20) !important;
  }

  .light-theme .dashboard-hero::before,
  .light-theme .journal-hero::before,
  .light-theme .dashboard-panel::before,
  .light-theme .dashboard-activity-card::before,
  .light-theme .dashboard-recent-list::before,
  .light-theme .journal-search-panel::before,
  .light-theme .journal-sort-panel::before,
  .light-theme .trade-context-modern::before {
    background: radial-gradient(circle at top left, rgba(217,70,239,.10), transparent 34%), radial-gradient(circle at bottom right, rgba(16,185,129,.055), transparent 30%) !important;
  }

  .light-theme .dashboard-inspiration,
  .light-theme .moving-text-wrap {
    background: linear-gradient(135deg, #ffffff, #faf5ff 55%, #ffffff) !important;
    border-color: rgba(217,70,239,.18) !important;
    box-shadow: 0 12px 30px rgba(168,85,247,.10), inset 0 1px 0 rgba(255,255,255,.85) !important;
  }

  .light-theme .moving-text-item {
    color: #111827 !important;
    text-shadow: none !important;
  }

  .light-theme .moving-text-spark {
    background: rgba(217,70,239,.10) !important;
    color: #c026d3 !important;
    border-color: rgba(217,70,239,.26) !important;
    box-shadow: 0 10px 22px rgba(217,70,239,.10) !important;
  }

  .light-theme .dashboard-dash-card,
  .light-theme .group.relative.overflow-hidden.rounded-xl.border.bg-gradient-to-br,
  .light-theme .statistics-metric-card,
  .light-theme .best-performance-card,
  .light-theme .weekday-card-pro,
  .light-theme .strategy-rank-row,
  .light-theme .strategy-detail-pro,
  .light-theme .trade-context-card,
  .light-theme .journal-metric-box,
  .light-theme .activity-stat-fuchsia,
  .light-theme .activity-stat-emerald,
  .light-theme .activity-stat-red,
  .light-theme .activity-stat-amber {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    color: #111827 !important;
    box-shadow: 0 12px 32px rgba(15,23,42,.065) !important;
  }

  .light-theme .dashboard-dash-card:hover,
  .light-theme .statistics-metric-card:hover,
  .light-theme .best-performance-card:hover,
  .light-theme .weekday-card-pro:hover,
  .light-theme .trade-card:hover,
  .light-theme .trade-context-card:hover {
    border-color: rgba(217,70,239,.34) !important;
    box-shadow: 0 18px 44px rgba(168,85,247,.14) !important;
  }

  .light-theme .text-white,
  .light-theme h1,
  .light-theme h2,
  .light-theme h3,
  .light-theme .font-black {
    color: #111827 !important;
  }

  .light-theme .text-zinc-200,
  .light-theme .text-zinc-300,
  .light-theme .text-zinc-400,
  .light-theme .text-zinc-500 {
    color: #64748b !important;
  }

  .light-theme .text-fuchsia-300,
  .light-theme .text-fuchsia-400,
  .light-theme .text-fuchsia-500 {
    color: #c026d3 !important;
  }

  .light-theme .text-emerald-300,
  .light-theme .text-emerald-400,
  .light-theme .text-emerald-500 {
    color: #059669 !important;
  }

  .light-theme .text-red-300,
  .light-theme .text-red-400,
  .light-theme .text-red-500 {
    color: #dc2626 !important;
  }

  .light-theme .text-amber-300,
  .light-theme .text-amber-400,
  .light-theme .text-amber-500 {
    color: #d97706 !important;
  }

  .light-theme input,
  .light-theme textarea,
  .light-theme .custom-select-trigger,
  .light-theme .date-picker-trigger,
  .light-theme .trade-context-input {
    background: #ffffff !important;
    color: #111827 !important;
    border-color: rgba(226,232,240,.95) !important;
    box-shadow: 0 8px 22px rgba(15,23,42,.045) !important;
  }

  .light-theme input:focus,
  .light-theme textarea:focus,
  .light-theme .custom-select-trigger:focus,
  .light-theme .date-picker-trigger:focus {
    border-color: rgba(217,70,239,.55) !important;
    box-shadow: 0 0 0 3px rgba(217,70,239,.12), 0 12px 28px rgba(168,85,247,.12) !important;
  }

  .light-theme .custom-select-menu,
  .light-theme .date-picker-popover,
  .light-theme .light-tooltip {
    background: rgba(255,255,255,.98) !important;
    color: #111827 !important;
    border-color: rgba(217,70,239,.22) !important;
    box-shadow: 0 24px 60px rgba(15,23,42,.16) !important;
  }

  .light-theme .custom-select-option:hover,
  .light-theme .custom-select-active {
    background: #faf5ff !important;
    color: #86198f !important;
  }

  .light-theme .dashboard-chart-area,
  .light-theme .dashboard-radar-card,
  .light-theme .dashboard-score-summary,
  .light-theme .dashboard-recent-list,
  .light-theme .calendar-shell-pro,
  .light-theme .trade-screenshot-area,
  .light-theme .trade-no-screenshot {
    background: #f8fafc !important;
    border-color: rgba(226,232,240,.95) !important;
  }

  .light-theme .rounded-full[class*="bg-white/10"],
  .light-theme .rounded-md[class*="bg-white/10"],
  .light-theme [class*="bg-white/5"],
  .light-theme [class*="bg-black/25"],
  .light-theme [class*="bg-black/30"],
  .light-theme [class*="bg-black/35"],
  .light-theme [class*="bg-black/40"],
  .light-theme [class*="bg-black/45"],
  .light-theme [class*="bg-black/70"] {
    background: rgba(248,250,252,.86) !important;
    color: #111827 !important;
    border-color: rgba(226,232,240,.9) !important;
  }

  .light-theme .calendar-day-number,
  .light-theme .date-picker-day-number {
    color: #111827 !important;
    text-shadow: none !important;
  }

  .light-theme .calendar-day-selected,
  .light-theme .date-picker-day-selected {
    border-color: rgba(217,70,239,.70) !important;
    box-shadow: 0 0 0 3px rgba(217,70,239,.12), 0 14px 30px rgba(168,85,247,.16) !important;
  }

  .light-theme .pnl-switcher-label,
  .light-theme .trade-tag,
  .light-theme .journal-list-metric-chip,
  .light-theme .calendar-top-pill-neutral {
    background: #faf5ff !important;
    color: #86198f !important;
    border-color: rgba(217,70,239,.24) !important;
    box-shadow: 0 8px 20px rgba(217,70,239,.08) !important;
  }

  .light-theme .mobile-bottom-nav,
  .light-theme .fixed.bottom-0 {
    background: rgba(255,255,255,.94) !important;
    border-color: rgba(226,232,240,.92) !important;
    backdrop-filter: blur(18px) !important;
  }

  /* Calendar day details modal */
  .calendar-day-modal-pro {
    background: linear-gradient(135deg, #050505 0%, #090909 52%, #07030b 100%) !important;
    box-shadow: 0 26px 90px rgba(0,0,0,.80), 0 0 34px rgba(217,70,239,.10) !important;
  }

  .calendar-day-modal-head {
    background: linear-gradient(135deg, rgba(255,255,255,.035), rgba(0,0,0,.20)) !important;
  }

  .calendar-modal-day-badge {
    display: flex;
    height: 3.5rem;
    width: 3.5rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: 1rem;
    font-size: 1.25rem;
    font-weight: 950;
    color: #fff;
  }

  .calendar-modal-day-win { background: #16a34a; box-shadow: 0 0 22px rgba(22,163,74,.32); }
  .calendar-modal-day-loss { background: #dc2626; box-shadow: 0 0 22px rgba(220,38,38,.32); }
  .calendar-modal-day-be { background: #d97706; box-shadow: 0 0 22px rgba(217,119,6,.28); }
  .calendar-modal-day-empty { background: #7e22ce; box-shadow: 0 0 22px rgba(126,34,206,.28); }

  .calendar-modal-status {
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,.12);
    padding: .25rem .65rem;
    font-size: .75rem;
    font-weight: 950;
  }

  .calendar-modal-status-win { border-color: rgba(251,146,60,.40); background: rgba(251,146,60,.14); color: #fdba74; }
  .calendar-modal-status-loss { border-color: rgba(248,113,113,.40); background: rgba(248,113,113,.14); color: #fca5a5; }
  .calendar-modal-status-be { border-color: rgba(245,158,11,.40); background: rgba(245,158,11,.14); color: #fcd34d; }
  .calendar-modal-status-empty { border-color: rgba(217,70,239,.35); background: rgba(217,70,239,.12); color: #f0abfc; }

  .calendar-day-modal-summary {
    margin: 2rem 1.5rem 1rem;
    border-radius: 1rem;
    border: 1px solid rgba(255,255,255,.10);
    padding: 1.6rem;
  }

  .calendar-day-modal-summary-win { border-color: rgba(16,185,129,.32); background: rgba(16,185,129,.10); }
  .calendar-day-modal-summary-loss { border-color: rgba(239,68,68,.32); background: rgba(239,68,68,.10); }
  .calendar-day-modal-summary-be { border-color: rgba(245,158,11,.32); background: rgba(245,158,11,.10); }
  .calendar-day-modal-summary-empty { border-color: rgba(217,70,239,.28); background: rgba(217,70,239,.08); }

  .calendar-modal-trade-row {
    position: relative;
    overflow: hidden;
    border-radius: 1rem;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.42);
    padding: 1.1rem;
  }

  .calendar-modal-trade-row::before {
    content: "";
    position: absolute;
    inset-y: 0;
    left: 0;
    width: 4px;
  }

  .calendar-modal-trade-win { border-color: rgba(16,185,129,.35); background: linear-gradient(135deg, rgba(16,185,129,.09), rgba(0,0,0,.45)); }
  .calendar-modal-trade-loss { border-color: rgba(239,68,68,.35); background: linear-gradient(135deg, rgba(239,68,68,.09), rgba(0,0,0,.45)); }
  .calendar-modal-trade-be { border-color: rgba(245,158,11,.35); background: linear-gradient(135deg, rgba(245,158,11,.09), rgba(0,0,0,.45)); }
  .calendar-modal-trade-win::before { background: #10b981; box-shadow: 0 0 16px rgba(16,185,129,.60); }
  .calendar-modal-trade-loss::before { background: #ef4444; box-shadow: 0 0 16px rgba(239,68,68,.60); }
  .calendar-modal-trade-be::before { background: #f59e0b; box-shadow: 0 0 16px rgba(245,158,11,.60); }

  .light-theme .calendar-day-modal-pro,
  .light-theme .calendar-day-modal-head,
  .light-theme .calendar-day-modal-summary,
  .light-theme .calendar-modal-trade-row {
    background: #ffffff !important;
    color: #111827 !important;
    border-color: rgba(226,232,240,.95) !important;
    box-shadow: 0 18px 50px rgba(15,23,42,.14) !important;
  }

  .light-theme .calendar-day-modal-pro .text-white,
  .light-theme .calendar-day-modal-pro h2 {
    color: #111827 !important;
  }

  .light-theme .calendar-day-modal-summary-win { background: #ecfdf5 !important; border-color: rgba(16,185,129,.25) !important; }
  .light-theme .calendar-day-modal-summary-loss { background: #fef2f2 !important; border-color: rgba(239,68,68,.25) !important; }
  .light-theme .calendar-day-modal-summary-be { background: #fffbeb !important; border-color: rgba(245,158,11,.25) !important; }
  .light-theme .calendar-modal-trade-win { background: #f0fdf4 !important; border-color: rgba(16,185,129,.25) !important; }
  .light-theme .calendar-modal-trade-loss { background: #fff1f2 !important; border-color: rgba(239,68,68,.25) !important; }
  .light-theme .calendar-modal-trade-be { background: #fffbeb !important; border-color: rgba(245,158,11,.25) !important; }

  /* 10/10 Calendar premium polish */
  .calendar-hero-pro {
    border-radius: 2rem !important;
    border-color: rgba(217,70,239,.20) !important;
    background: linear-gradient(135deg, rgba(13,13,16,.97), rgba(7,7,9,.98) 52%, rgba(18,12,24,.94)) !important;
    box-shadow: 0 24px 70px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.05) !important;
  }

  .calendar-hero-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.13), transparent 33%), radial-gradient(circle at bottom right, rgba(16,185,129,.075), transparent 34%);
  }

  .calendar-hero-stats-pro {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: .75rem;
    min-width: min(100%, 440px);
  }

  .calendar-summary-card-pro,
  .calendar-guide-pro,
  .calendar-shell-pro,
  .calendar-week-summary-pro {
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.045);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .calendar-summary-card-pro {
    position: relative;
    overflow: hidden;
    border-radius: 1.5rem;
    padding: 1.15rem;
  }

  .calendar-summary-card-pro::before {
    content: "";
    position: absolute;
    right: -2.5rem;
    top: -2.5rem;
    height: 8rem;
    width: 8rem;
    border-radius: 999px;
    background: rgba(255,255,255,.055);
    filter: blur(14px);
  }

  .calendar-summary-good { border-color: rgba(16,185,129,.24); background: rgba(16,185,129,.075); }
  .calendar-summary-bad { border-color: rgba(239,68,68,.24); background: rgba(239,68,68,.075); }
  .calendar-summary-warn { border-color: rgba(245,158,11,.24); background: rgba(245,158,11,.075); }

  .calendar-summary-dot-pro {
    height: .65rem;
    width: .65rem;
    border-radius: 999px;
    background: currentColor;
    opacity: .85;
    box-shadow: 0 0 14px currentColor;
  }

  .calendar-summary-good .calendar-summary-dot-pro { color: #34d399; }
  .calendar-summary-bad .calendar-summary-dot-pro { color: #fb7185; }
  .calendar-summary-warn .calendar-summary-dot-pro { color: #fbbf24; }

  .calendar-guide-pro {
    position: relative;
    overflow: hidden;
    border-radius: 1.75rem;
    border-color: rgba(217,70,239,.18);
    background: linear-gradient(135deg, rgba(217,70,239,.075), rgba(255,255,255,.035) 42%, rgba(16,185,129,.045));
    padding: 1.25rem;
    box-shadow: 0 18px 46px rgba(0,0,0,.18), inset 0 1px 0 rgba(255,255,255,.04);
  }

  .calendar-guide-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.10), transparent 34%), radial-gradient(circle at bottom right, rgba(16,185,129,.06), transparent 34%);
  }

  .calendar-guide-pro > * { position: relative; z-index: 1; }

  .calendar-legend-pro {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: .65rem;
    min-width: min(100%, 440px);
  }

  .calendar-legend-pro span {
    display: flex;
    align-items: center;
    gap: .55rem;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.22);
    padding: .65rem .85rem;
    color: #d4d4d8;
    font-size: .78rem;
    font-weight: 950;
  }

  .calendar-legend-pro i {
    height: .7rem;
    width: .7rem;
    border-radius: 999px;
    box-shadow: 0 0 12px currentColor;
  }

  .calendar-shell-pro {
    border-radius: 2rem !important;
    border-color: rgba(255,255,255,.10) !important;
    background: linear-gradient(135deg, rgba(255,255,255,.045), rgba(0,0,0,.30)) !important;
    padding: 1.35rem !important;
    box-shadow: 0 22px 60px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .calendar-week-header {
    border-radius: 1rem !important;
    background: rgba(255,255,255,.045) !important;
    letter-spacing: .14em !important;
  }

  .calendar-day-simple {
    border-radius: 1.1rem !important;
    min-height: 128px !important;
    padding: .9rem !important;
    transition: transform .2s ease, border-color .2s ease, box-shadow .2s ease !important;
  }

  .calendar-day-simple:hover {
    transform: translateY(-2px) !important;
    border-color: rgba(217,70,239,.55) !important;
    box-shadow: 0 16px 34px rgba(217,70,239,.12), inset 0 1px 0 rgba(255,255,255,.05) !important;
  }

  .calendar-day-number,
  .calendar-day-number-muted {
    height: 2rem !important;
    min-width: 2rem !important;
    border-radius: .8rem !important;
    font-size: 1rem !important;
    font-weight: 950 !important;
  }

  .calendar-week-summary-pro {
    min-height: 128px !important;
    border-radius: 1.1rem !important;
    background: rgba(217,70,239,.075) !important;
  }

  .calendar-day-win { background: linear-gradient(135deg, rgba(16,185,129,.18), rgba(0,0,0,.22)) !important; }
  .calendar-day-loss { background: linear-gradient(135deg, rgba(239,68,68,.18), rgba(0,0,0,.22)) !important; }
  .calendar-day-breakeven { background: linear-gradient(135deg, rgba(245,158,11,.16), rgba(0,0,0,.22)) !important; }
  .calendar-day-empty,
  .calendar-day-weekend { background: linear-gradient(135deg, rgba(217,70,239,.09), rgba(0,0,0,.24)) !important; }

  .calendar-day-selected {
    border-color: rgba(217,70,239,.85) !important;
    box-shadow: 0 0 0 1px rgba(217,70,239,.30), 0 0 34px rgba(217,70,239,.24) !important;
  }

  .light-theme .calendar-summary-card-pro,
  .light-theme .calendar-guide-pro,
  .light-theme .calendar-shell-pro,
  .light-theme .calendar-week-summary-pro {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    color: #111827 !important;
    box-shadow: 0 16px 38px rgba(15,23,42,.065) !important;
  }

  .light-theme .calendar-hero-pro {
    background: linear-gradient(135deg, rgba(255,255,255,.96), rgba(250,245,255,.92) 55%, rgba(255,255,255,.96)) !important;
    border-color: rgba(217,70,239,.20) !important;
    box-shadow: 0 18px 45px rgba(15,23,42,.075) !important;
  }

  .light-theme .calendar-guide-pro::before,
  .light-theme .calendar-hero-pro::before {
    background: radial-gradient(circle at top left, rgba(217,70,239,.055), transparent 32%), radial-gradient(circle at bottom right, rgba(16,185,129,.045), transparent 34%) !important;
  }

  .light-theme .calendar-legend-pro span {
    background: #f8fafc !important;
    border-color: rgba(226,232,240,.95) !important;
    color: #111827 !important;
  }

  .light-theme .calendar-day-win { background: linear-gradient(135deg, #ecfdf5 0%, #ffffff 52%, #d1fae5 100%) !important; }
  .light-theme .calendar-day-loss { background: linear-gradient(135deg, #fef2f2 0%, #ffffff 52%, #fee2e2 100%) !important; }
  .light-theme .calendar-day-breakeven { background: linear-gradient(135deg, #fffbeb 0%, #ffffff 52%, #fef3c7 100%) !important; }
  .light-theme .calendar-day-empty,
  .light-theme .calendar-day-weekend { background: linear-gradient(135deg, #ffffff 0%, #fbf7ff 55%, #f5f3ff 100%) !important; }

  @media (max-width: 768px) {
    .calendar-hero-stats-pro,
    .calendar-legend-pro {
      grid-template-columns: 1fr;
      min-width: 100%;
    }
  }

  /* 10/10 Statistics premium polish */
  .statistics-page-pro {
    --stats-border: rgba(255,255,255,.10);
    --stats-card: rgba(255,255,255,.045);
  }

  .statistics-hero-pro {
    position: relative;
    overflow: hidden;
    border-radius: 2rem;
    border: 1px solid rgba(217,70,239,.18);
    background: linear-gradient(135deg, rgba(13,13,16,.96), rgba(7,7,9,.98) 52%, rgba(18,12,24,.94));
    padding: 1.45rem;
    box-shadow: 0 22px 60px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.05);
  }

  .statistics-hero-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.12), transparent 33%), radial-gradient(circle at bottom right, rgba(16,185,129,.08), transparent 34%);
  }

  .stats-flow-step-pro,
  .statistics-filter-pro,
  .statistics-status-strip-pro,
  .statistics-command-main-pro,
  .statistics-command-side-pro,
  .stats-hero-metric,
  .stats-insight-card,
  .statistics-tabs-pro {
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.045);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .stats-flow-step-pro {
    display: flex;
    gap: .8rem;
    align-items: flex-start;
    border-radius: 1.25rem;
    padding: 1rem;
  }

  .stats-flow-number-pro {
    display: flex;
    height: 2rem;
    width: 2rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: .8rem;
    border: 1px solid rgba(217,70,239,.35);
    background: rgba(217,70,239,.14);
    color: #f0abfc;
    font-size: .8rem;
    font-weight: 950;
  }

  .statistics-filter-pro {
    border-radius: 1.6rem;
    border-color: rgba(217,70,239,.24);
    background: linear-gradient(135deg, rgba(255,255,255,.055), rgba(0,0,0,.38));
    padding: 1.25rem;
  }

  .statistics-filter-btn-pro {
    min-height: 2.55rem;
    border-radius: .8rem;
    border: 1px solid rgba(217,70,239,.28);
    background: rgba(217,70,239,.10);
    color: #f0abfc;
    font-size: .82rem;
    font-weight: 950;
    transition: all .2s ease;
  }

  .statistics-filter-btn-pro:hover {
    border-color: rgba(217,70,239,.55);
    background: rgba(217,70,239,.16);
    transform: translateY(-1px);
  }

  .statistics-status-strip-pro {
    margin-top: 1.25rem;
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: .75rem;
    border-radius: 1.5rem;
    padding: .85rem;
  }

  .statistics-status-strip-pro > div {
    display: flex;
    min-height: 4rem;
    flex-direction: column;
    justify-content: center;
    gap: .35rem;
    border-radius: 1rem;
    border: 1px solid rgba(255,255,255,.08);
    background: rgba(0,0,0,.20);
    padding: .75rem .9rem;
  }

  .statistics-status-strip-pro span {
    color: #71717a;
    font-size: .68rem;
    font-weight: 950;
    letter-spacing: .12em;
    text-transform: uppercase;
  }

  .statistics-status-strip-pro b {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #fff;
    font-size: .95rem;
    font-weight: 950;
  }

  .statistics-command-center-pro {
    display: grid;
    grid-template-columns: minmax(0, 1.4fr) minmax(320px, .6fr);
    gap: 1.25rem;
  }

  .statistics-command-main-pro,
  .statistics-command-side-pro {
    position: relative;
    overflow: hidden;
    border-radius: 1.8rem;
    background: linear-gradient(135deg, rgba(255,255,255,.045), rgba(0,0,0,.28));
    padding: 1.25rem;
    box-shadow: 0 18px 46px rgba(0,0,0,.20), inset 0 1px 0 rgba(255,255,255,.04);
  }

  .statistics-command-main-pro::before,
  .statistics-command-side-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.08), transparent 34%), radial-gradient(circle at bottom right, rgba(16,185,129,.05), transparent 34%);
  }

  .statistics-command-main-pro > *,
  .statistics-command-side-pro > * {
    position: relative;
    z-index: 1;
  }

  .stats-edge-badge {
    border-radius: 999px;
    padding: .55rem .85rem;
    font-size: .75rem;
    font-weight: 950;
    white-space: nowrap;
  }

  .stats-edge-good { border: 1px solid rgba(16,185,129,.35); background: rgba(16,185,129,.12); color: #86efac; }
  .stats-edge-warn { border: 1px solid rgba(245,158,11,.35); background: rgba(245,158,11,.12); color: #fcd34d; }
  .stats-edge-bad { border: 1px solid rgba(239,68,68,.35); background: rgba(239,68,68,.12); color: #fca5a5; }

  .stats-hero-metric {
    border-radius: 1.25rem;
    padding: 1rem;
  }

  .stats-hero-good { border-color: rgba(16,185,129,.24); background: rgba(16,185,129,.075); }
  .stats-hero-bad { border-color: rgba(239,68,68,.24); background: rgba(239,68,68,.075); }
  .stats-hero-warn { border-color: rgba(245,158,11,.24); background: rgba(245,158,11,.075); }
  .stats-hero-main { border-color: rgba(217,70,239,.24); background: rgba(217,70,239,.075); }

  .stats-insight-card {
    border-radius: 1.15rem;
    padding: 1rem;
  }

  .stats-insight-good { border-color: rgba(16,185,129,.24); background: rgba(16,185,129,.075); }
  .stats-insight-bad { border-color: rgba(239,68,68,.24); background: rgba(239,68,68,.075); }
  .stats-insight-warn { border-color: rgba(245,158,11,.24); background: rgba(245,158,11,.075); }
  .stats-insight-main { border-color: rgba(217,70,239,.24); background: rgba(217,70,239,.075); }

  .stats-beginner-guide-pro {
    position: relative;
    overflow: hidden;
    border-radius: 1.8rem;
    border: 1px solid rgba(217,70,239,.18);
    background: linear-gradient(135deg, rgba(217,70,239,.075), rgba(255,255,255,.035) 42%, rgba(16,185,129,.045));
    padding: 1.25rem;
    box-shadow: 0 18px 46px rgba(0,0,0,.18), inset 0 1px 0 rgba(255,255,255,.04);
  }

  .stats-beginner-guide-pro::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at top left, rgba(217,70,239,.10), transparent 34%), radial-gradient(circle at bottom right, rgba(16,185,129,.06), transparent 34%);
  }

  .stats-beginner-guide-pro > * {
    position: relative;
    z-index: 1;
  }

  .stats-reading-order-pro {
    display: grid;
    min-width: min(100%, 440px);
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: .65rem;
  }

  .stats-reading-order-pro span {
    border-radius: 999px;
    border: 1px solid rgba(217,70,239,.24);
    background: rgba(217,70,239,.10);
    padding: .65rem .85rem;
    color: #f0abfc;
    font-size: .78rem;
    font-weight: 950;
    text-align: center;
  }

  .stat-definition-card-pro {
    border-radius: 1.25rem;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.24);
    padding: 1rem;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .stats-help-dot-pro {
    display: flex;
    height: 1.5rem;
    width: 1.5rem;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    border: 1px solid rgba(217,70,239,.28);
    background: rgba(217,70,239,.12);
    color: #f0abfc;
    font-size: .72rem;
    font-weight: 950;
  }

  .statistics-tabs-pro {
    display: inline-flex;
    flex-wrap: wrap;
    gap: .35rem;
    border-radius: 1.25rem;
    padding: .45rem;
  }

  .statistics-tab-pro {
    display: flex;
    align-items: center;
    gap: .5rem;
    border-radius: .95rem;
    padding: .75rem 1.15rem;
    color: #a1a1aa;
    font-size: .88rem;
    font-weight: 950;
    transition: all .2s ease;
  }

  .statistics-tab-pro:hover {
    background: rgba(217,70,239,.10);
    color: #fff;
  }

  .statistics-tab-pro-active {
    background: linear-gradient(135deg, rgba(217,70,239,.95), rgba(168,85,247,.78));
    color: #fff;
    box-shadow: 0 0 22px rgba(217,70,239,.22), inset 0 1px 0 rgba(255,255,255,.18);
  }

  .statistics-tab-icon-pro {
    display: inline-flex;
    height: 1.35rem;
    width: 1.35rem;
    align-items: center;
    justify-content: center;
    border-radius: .45rem;
    background: rgba(255,255,255,.08);
    font-size: .78rem;
  }

  .light-theme .stats-beginner-guide-pro,
  .light-theme .stat-definition-card-pro,
  .light-theme .statistics-hero-pro,
  .light-theme .statistics-filter-pro,
  .light-theme .statistics-status-strip-pro,
  .light-theme .statistics-status-strip-pro > div,
  .light-theme .statistics-command-main-pro,
  .light-theme .statistics-command-side-pro,
  .light-theme .stats-flow-step-pro,
  .light-theme .stats-hero-metric,
  .light-theme .stats-insight-card,
  .light-theme .statistics-tabs-pro {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    box-shadow: 0 16px 38px rgba(15,23,42,.065) !important;
  }

  .light-theme .stats-beginner-guide-pro::before,
  .light-theme .statistics-hero-pro::before,
  .light-theme .statistics-command-main-pro::before,
  .light-theme .statistics-command-side-pro::before {
    background: radial-gradient(circle at top left, rgba(217,70,239,.055), transparent 32%), radial-gradient(circle at bottom right, rgba(16,185,129,.045), transparent 34%) !important;
  }

  .light-theme .stats-reading-order-pro span,
  .light-theme .stats-help-dot-pro {
    background: #faf5ff !important;
    border-color: rgba(217,70,239,.22) !important;
    color: #86198f !important;
  }

  .light-theme .statistics-filter-btn-pro {
    background: #faf5ff !important;
    border-color: rgba(217,70,239,.22) !important;
    color: #86198f !important;
    box-shadow: 0 8px 20px rgba(217,70,239,.08) !important;
  }

  .light-theme .statistics-status-strip-pro b,
  .light-theme .stats-flow-step-pro .font-black,
  .light-theme .stats-hero-metric .text-white,
  .light-theme .stats-insight-card .text-white {
    color: #111827 !important;
  }

  .light-theme .statistics-tab-pro {
    color: #64748b !important;
  }

  .light-theme .statistics-tab-pro:hover {
    background: #faf5ff !important;
    color: #86198f !important;
  }

  .light-theme .statistics-tab-pro-active,
  .light-theme .statistics-tab-pro-active * {
    color: #ffffff !important;
  }

  @media (max-width: 1024px) {
    .statistics-command-center-pro {
      grid-template-columns: 1fr;
    }
    .statistics-status-strip-pro {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 640px) {
    .statistics-status-strip-pro {
      grid-template-columns: 1fr;
    }
    .statistics-tabs-pro {
      display: grid;
      grid-template-columns: 1fr;
      width: 100%;
    }
  }

  /* 10/10 Mistake Detector premium polish */
  .mistake-page-pro {
    --mistake-card: rgba(255,255,255,.055);
    --mistake-border: rgba(255,255,255,.10);
    --mistake-muted: #a1a1aa;
  }

  .mistake-page-header-pro {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(320px, 520px);
    gap: 1.25rem;
    align-items: end;
    border-bottom: 1px solid rgba(255,255,255,.08);
    padding-bottom: 1.5rem;
  }

  .mistake-page-icon-pro {
    display: flex;
    height: 3.25rem;
    width: 3.25rem;
    flex: 0 0 auto;
    align-items: center;
    justify-content: center;
    border-radius: 1.1rem;
    border: 1px solid rgba(217,70,239,.32);
    background: rgba(217,70,239,.10);
    color: #f0abfc;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.05);
  }

  .mistake-filter-card-pro,
  .mistake-status-strip-pro {
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.045);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
  }

  .mistake-filter-card-pro {
    border-radius: 1.5rem;
    padding: 1rem;
  }

  .mistake-clear-btn-pro {
    min-height: 2.5rem;
    border-radius: .75rem;
    border: 1px solid rgba(217,70,239,.28);
    background: rgba(217,70,239,.10);
    color: #f0abfc;
    font-size: .875rem;
    font-weight: 950;
    transition: all .2s ease;
  }

  .mistake-clear-btn-pro:hover {
    border-color: rgba(217,70,239,.55);
    background: rgba(217,70,239,.16);
    transform: translateY(-1px);
  }

  .mistake-status-strip-pro {
    margin-top: 1.25rem;
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: .75rem;
    border-radius: 1.5rem;
    padding: .85rem;
  }

  .mistake-status-strip-pro > div {
    display: flex;
    min-height: 4rem;
    flex-direction: column;
    justify-content: center;
    gap: .35rem;
    border-radius: 1rem;
    border: 1px solid rgba(255,255,255,.08);
    background: rgba(0,0,0,.20);
    padding: .75rem .9rem;
  }

  .mistake-status-strip-pro span {
    font-size: .68rem;
    font-weight: 950;
    text-transform: uppercase;
    letter-spacing: .12em;
  }

  .mistake-status-strip-pro b {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #fff;
    font-size: .95rem;
    font-weight: 950;
  }

  .mistake-page-divider-pro {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: .25rem 0;
    color: #a1a1aa;
    font-size: .72rem;
    font-weight: 950;
    letter-spacing: .14em;
    text-transform: uppercase;
  }

  .mistake-page-divider-pro::before,
  .mistake-page-divider-pro::after {
    content: "";
    height: 1px;
    flex: 1;
    background: linear-gradient(to right, transparent, rgba(255,255,255,.12), transparent);
  }

  .mistake-page-divider-pro span {
    margin: 0 .9rem;
    border-radius: 999px;
    border: 1px solid rgba(217,70,239,.22);
    background: rgba(217,70,239,.08);
    padding: .35rem .7rem;
    color: #f0abfc;
  }

  .mistake-coach-hero,
  .mistake-panel-clean,
  .mistake-guide-panel,
  .coach-summary-card,
  .reason-card-premium-force {
    backdrop-filter: blur(18px);
  }

  .mistake-coach-hero {
    border-color: rgba(217,70,239,.18) !important;
    background: linear-gradient(135deg, rgba(13,13,16,.96), rgba(7,7,9,.98) 52%, rgba(18,12,24,.94)) !important;
    box-shadow: 0 22px 60px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.05) !important;
  }

  .mistake-coach-hero::before {
    background: radial-gradient(circle at top left, rgba(217,70,239,.105), transparent 33%), radial-gradient(circle at bottom right, rgba(16,185,129,.075), transparent 34%) !important;
  }

  .mistake-panel-clean,
  .mistake-guide-panel {
    border-color: rgba(255,255,255,.10) !important;
    background: linear-gradient(135deg, rgba(255,255,255,.045), rgba(0,0,0,.28)) !important;
    box-shadow: 0 18px 46px rgba(0,0,0,.20), inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .mistake-panel-clean::before,
  .mistake-guide-panel::before {
    opacity: .55 !important;
  }

  .coach-summary-card,
  .coach-flow-step,
  .guide-mini-card,
  .mini-coach-metric,
  .issue-clean-card,
  .fix-step-card {
    border-color: rgba(255,255,255,.10) !important;
    background: rgba(255,255,255,.045) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04) !important;
  }

  .issue-clean-card-active,
  .issue-clean-card:hover {
    border-color: rgba(239,68,68,.38) !important;
    background: rgba(239,68,68,.08) !important;
    box-shadow: 0 16px 34px rgba(239,68,68,.10) !important;
  }

  .fix-step-card {
    border-color: rgba(16,185,129,.24) !important;
    background: rgba(16,185,129,.075) !important;
  }

  .mistake-detector-clean .rounded-2xl,
  .mistake-detector-clean .rounded-\[1\.4rem\],
  .mistake-detector-clean .rounded-\[2rem\] {
    box-shadow: none;
  }

  .mistake-detector-clean .text-5xl,
  .mistake-detector-clean .text-4xl,
  .mistake-detector-clean .text-3xl {
    letter-spacing: -0.04em;
  }

  .light-theme .mistake-page-pro {
    --mistake-card: #ffffff;
    --mistake-border: rgba(226,232,240,.95);
    --mistake-muted: #64748b;
  }

  .light-theme .mistake-page-header-pro {
    border-bottom-color: rgba(226,232,240,.95) !important;
  }

  .light-theme .mistake-page-icon-pro,
  .light-theme .mistake-filter-card-pro,
  .light-theme .mistake-status-strip-pro,
  .light-theme .mistake-status-strip-pro > div,
  .light-theme .mistake-clear-btn-pro {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    color: #111827 !important;
    box-shadow: 0 12px 30px rgba(15,23,42,.055) !important;
  }

  .light-theme .mistake-page-icon-pro {
    color: #c026d3 !important;
    background: #faf5ff !important;
  }

  .light-theme .mistake-clear-btn-pro {
    color: #86198f !important;
  }

  .light-theme .mistake-status-strip-pro b {
    color: #111827 !important;
  }

  .light-theme .mistake-page-divider-pro::before,
  .light-theme .mistake-page-divider-pro::after {
    background: linear-gradient(to right, transparent, rgba(148,163,184,.35), transparent) !important;
  }

  .light-theme .mistake-page-divider-pro span {
    background: #faf5ff !important;
    border-color: rgba(217,70,239,.22) !important;
    color: #86198f !important;
  }

  .light-theme .mistake-coach-hero,
  .light-theme .mistake-panel-clean,
  .light-theme .mistake-guide-panel,
  .light-theme .coach-summary-card,
  .light-theme .coach-flow-step,
  .light-theme .guide-mini-card,
  .light-theme .mini-coach-metric,
  .light-theme .issue-clean-card,
  .light-theme .fix-step-card {
    background: #ffffff !important;
    border-color: rgba(226,232,240,.95) !important;
    box-shadow: 0 16px 38px rgba(15,23,42,.065) !important;
  }

  .light-theme .mistake-coach-hero::before,
  .light-theme .mistake-panel-clean::before {
    background: radial-gradient(circle at top left, rgba(217,70,239,.055), transparent 32%), radial-gradient(circle at bottom right, rgba(16,185,129,.045), transparent 34%) !important;
  }

  .light-theme .issue-clean-card-active,
  .light-theme .issue-clean-card:hover {
    background: #fff7f7 !important;
    border-color: rgba(239,68,68,.34) !important;
    box-shadow: 0 18px 38px rgba(239,68,68,.08) !important;
  }

  .light-theme .fix-step-card {
    background: #f0fdf4 !important;
    border-color: rgba(16,185,129,.22) !important;
  }

  @media (max-width: 1024px) {
    .mistake-page-header-pro {
      grid-template-columns: 1fr;
      align-items: start;
    }
    .mistake-status-strip-pro {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 640px) {
    .mistake-page-header-pro .flex.items-center.gap-3 {
      align-items: flex-start;
    }
    .mistake-status-strip-pro {
      grid-template-columns: 1fr;
    }
    .mistake-filter-card-pro .grid {
      grid-template-columns: 1fr !important;
    }
  }
`;

const starterTrades = [
  {
    id: 1,
    createdAt: 1,
    date: "2026-05-15",
    pair: "MNQ",
    direction: "BUY",
    quantity: 2,
    setup: "Liquidity Sweep",
    session: "NY-PM",
    result: "Win",
    emotion: "Calm",
    risk: 200,
    pnl: 590,
    notes: "Clean liquidity sweep. Waited for confirmation before entry.",
    mistake: "None",
    screenshots: [],
    tags: ["result:win", "A+ Setup", "Liquidity"],
  },
];

const defaultAccount = {
  id: "acc-demo-v",
  name: "v",
  type: "Demo Account",
  currency: "USD",
  balance: 50000,
  description: "Practice trading with virtual money",
};

const emptyForm = {
  symbol: "",
  direction: "Buy",
  quantity: "2",
  pnl: "590",
  risk: "200",
  date: formatDateKey(new Date()),
  session: "Select trading session",
  strategy: "Liquidity Sweep",
  result: "Win",
  tags: "result:win",
  emotion: "Calm",
  mistake: "None",
  notes: "",
  whatWentWell: "",
  whatWentWrong: "",
  ruleFollowed: "Yes",
  entryTiming: "On Time",
  confirmation: "Yes",
  ruleBroken: "None",
  marketCondition: "Trending",
  setupQuality: "B",
  entryQuality: "3",
  exitQuality: "3",
  screenshots: [],
};

const nav = [
  [LayoutDashboard, "Dashboard"],
  [BookOpen, "Journal"],
  [Calendar, "Calendar"],
  [BarChart3, "Statistics"],
  [Target, "Mistake Detector"],
];

const quotes = [
  "Success is where preparation and opportunity meet.",
  "Discipline is the bridge between goals and accomplishment.",
  "The market rewards patience and punishes greed.",
  "Your only limit is your mindset. Trade with intention.",
  "Every expert was once a beginner. Keep learning.",
  "Today's preparation determines tomorrow's achievement.",
];

const routineItems = [
  { id: "news", label: "News checked", detail: "High impact events reviewed", icon: "⚡" },
  { id: "bias", label: "Market bias confirmed", detail: "Daily/HTF direction is clear", icon: "🎯" },
  { id: "liquidity", label: "Liquidity levels marked", detail: "PDH/PDL, Asia high/low, equal highs/lows", icon: "💧" },
  { id: "setup", label: "Valid setup only", detail: "Entry matches your trading model", icon: "✅" },
  { id: "risk", label: "Risk defined", detail: "Stop loss, target and max loss prepared", icon: "$" },
  { id: "emotion", label: "Emotion check", detail: "No FOMO, revenge, or overtrading", icon: "🧠" },
];

function normalizeScreenshots(value) {
  const candidates = [];
  if (Array.isArray(value?.screenshots)) candidates.push(...value.screenshots);
  if (value?.screenshot) candidates.push(value.screenshot);
  if (value?.screenshotUrl) candidates.push(value.screenshotUrl);
  if (value?.image) candidates.push(value.image);
  if (value?.imageUrl) candidates.push(value.imageUrl);
  if (value?.photo) candidates.push(value.photo);
  return candidates.filter(Boolean).slice(0, MAX_SCREENSHOTS);
}

function normalizeTags(value) {
  if (Array.isArray(value?.tags)) return value.tags.map((tag) => String(tag).trim()).filter(Boolean);
  if (typeof value?.tags === "string") return value.tags.split(",").map((tag) => tag.trim()).filter(Boolean);
  return [];
}

function formatMoney(value) {
  const number = Number(value || 0);
  const prefix = number >= 0 ? "$" : "-$";
  return `${prefix}${Math.abs(number).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

function parseAnimatedValue(value) {
  if (typeof value === "number") {
    return {
      canAnimate: true,
      target: value,
      formatter: (next) => Number(next).toLocaleString("en-US", { maximumFractionDigits: Number.isInteger(value) ? 0 : 1 }),
    };
  }

  const text = String(value ?? "").trim();
  const compact = text.replaceAll(",", "");
  const isMoney = compact.startsWith("$") || compact.startsWith("-$");
  const isPercent = compact.endsWith("%");
  const numberText = compact.replace("$", "").replace("%", "");
  const target = Number(numberText);

  if (Number.isFinite(target) && compact !== "") {
    if (isMoney) return { canAnimate: true, target, formatter: formatMoney };
    if (isPercent) {
      const decimals = numberText.includes(".") ? numberText.split(".")[1].length : 0;
      return { canAnimate: true, target, formatter: (next) => `${Number(next).toFixed(decimals)}%` };
    }
    const decimals = numberText.includes(".") ? numberText.split(".")[1].length : 0;
    return {
      canAnimate: true,
      target,
      formatter: (next) => Number(next).toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals }),
    };
  }

  return { canAnimate: false, target: 0, formatter: () => text };
}

function AnimatedValue({ value, className = "" }) {
  const parsed = useMemo(() => parseAnimatedValue(value), [value]);
  const [display, setDisplay] = useState(String(value ?? ""));

  useEffect(() => {
    if (!parsed.canAnimate || !Number.isFinite(parsed.target)) {
      setDisplay(String(value ?? ""));
      return undefined;
    }

    const duration = 1250;
    const startTime = performance.now();
    const endValue = parsed.target;
    let frameId;

    function animate(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = endValue * eased;
      setDisplay(parsed.formatter(current));
      if (progress < 1) frameId = requestAnimationFrame(animate);
    }

    frameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameId);
  }, [value, parsed]);

  return <span className={`animated-number ${className}`}>{display}</span>;
}

function RotatingPnlValue({ pnl, balance }) {
  const [mode, setMode] = useState("money");
  const percent = Number(balance || 0) ? (Number(pnl || 0) / Number(balance || 1)) * 100 : 0;

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setMode((current) => (current === "money" ? "percent" : "money"));
    }, 13000);
    return () => window.clearInterval(intervalId);
  }, []);

  const value = mode === "money" ? formatMoney(pnl) : `${percent >= 0 ? "+" : ""}${percent.toFixed(2)}%`;
  const label = mode === "money" ? "USD" : "ACCOUNT";

  return (
    <span className="pnl-switcher" key={mode}>
      <AnimatedValue value={value} />
      <span className="pnl-switcher-label">{label}</span>
    </span>
  );
}

function formatDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getTradeDateKey(trade) {
  if (!trade?.date) return "";
  const raw = String(trade.date).trim();
  if (/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(raw)) return raw;
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? raw : formatDateKey(date);
}

function getTradeRR(trade) {
  const risk = Number(trade?.risk || 0);
  const pnl = Number(trade?.pnl || 0);
  return risk ? pnl / risk : 0;
}

function getResultFromPnl(value) {
  const pnl = Number(value || 0);
  if (pnl > 0) return "Win";
  if (pnl < 0) return "Loss";
  return "Break Even";
}

function getResultTone(result) {
  if (result === "Win") return "emerald";
  if (result === "Loss") return "red";
  return "amber";
}

function isBreakEvenTrade(trade) {
  return Number(trade?.pnl || 0) === 0;
}

function getPnlToneClass(value) {
  const pnl = Number(value || 0);
  if (pnl > 0) return "text-emerald-400";
  if (pnl < 0) return "text-red-400";
  return "text-amber-400";
}

function getPnlPillClass(value) {
  const pnl = Number(value || 0);
  if (pnl > 0) return "border-emerald-500/30 bg-emerald-500/15 text-emerald-300";
  if (pnl < 0) return "border-red-500/30 bg-red-500/15 text-red-300";
  return "border-amber-500/30 bg-amber-500/15 text-amber-300";
}

function getPnlArrow(value) {
  const pnl = Number(value || 0);
  if (pnl > 0) return "↗";
  if (pnl < 0) return "↘";
  return "—";
}

function getTradeGrade(trade) {
  const rr = getTradeRR(trade);
  const pnl = Number(trade?.pnl || 0);
  const tags = normalizeTags(trade).map((tag) => tag.toLowerCase());
  const hasAPlus = tags.some((tag) => tag.includes("a+") || tag.includes("a setup"));
  if (pnl > 0 && (rr >= 2 || hasAPlus)) return "A";
  if (pnl > 0 && rr >= 1) return "B";
  if (pnl >= 0) return "C";
  return "D";
}

function getTradeGradeClass(grade) {
  if (grade === "A") return "border-emerald-500/40 bg-emerald-500/15 text-emerald-300";
  if (grade === "B") return "border-blue-500/40 bg-blue-500/15 text-blue-300";
  if (grade === "C") return "border-amber-500/40 bg-amber-500/15 text-amber-300";
  return "border-red-500/40 bg-red-500/15 text-red-300";
}

function getTradeDirectionClass(direction) {
  const side = String(direction || "").toUpperCase();
  if (side === "SELL") return "border-red-500/55 bg-red-600/75 text-white shadow-[0_0_10px_rgba(239,68,68,0.28)]";
  return "border-emerald-500/55 bg-emerald-600/75 text-white shadow-[0_0_10px_rgba(16,185,129,0.28)]";
}

function createTradeFromForm(form, existingId, account) {
  const pnl = Number(form.pnl || 0);
  const timestamp = existingId || Date.now();
  return {
    id: existingId || timestamp,
    createdAt: timestamp,
    accountId: account?.id || defaultAccount.id,
    accountName: account?.name || "v",
    accountType: account?.type || "Demo Account",
    accountCurrency: account?.currency || "USD",
    date: form.date,
    pair: String(form.symbol || "").toUpperCase(),
    direction: String(form.direction || "Buy").toUpperCase(),
    quantity: Number(form.quantity || 0),
    setup: form.strategy || "Manual Trade",
    session: form.session,
    result: getResultFromPnl(pnl),
    emotion: form.emotion,
    risk: Number(form.risk || 0),
    pnl,
    notes: form.notes,
    whatWentWell: form.whatWentWell || "",
    whatWentWrong: form.whatWentWrong || "",
    ruleFollowed: form.ruleFollowed || "Yes",
    entryTiming: form.entryTiming || "On Time",
    confirmation: form.confirmation || "Yes",
    ruleBroken: form.ruleBroken || "None",
    marketCondition: form.marketCondition || "Trending",
    setupQuality: form.setupQuality || getTradeGrade({ pnl, risk: Number(form.risk || 0), tags: form.tags }),
    entryQuality: Number(form.entryQuality || 0),
    exitQuality: Number(form.exitQuality || 0),
    mistake: form.mistake || "None",
    screenshots: normalizeScreenshots(form),
    tags: normalizeTags(form),
  };
}

function formFromTrade(trade) {
  return {
    symbol: trade.pair || "",
    direction: trade.direction === "SELL" ? "Sell" : "Buy",
    quantity: String(trade.quantity || ""),
    pnl: String(trade.pnl || ""),
    risk: String(trade.risk || ""),
    date: trade.date || "",
    session: trade.session || "",
    strategy: trade.setup || "",
    result: trade.result || "",
    tags: normalizeTags(trade).join(", "),
    emotion: trade.emotion || "",
    mistake: trade.mistake || "None",
    notes: trade.notes || "",
    whatWentWell: trade.whatWentWell || "",
    whatWentWrong: trade.whatWentWrong || "",
    ruleFollowed: trade.ruleFollowed || "Yes",
    entryTiming: trade.entryTiming || "On Time",
    confirmation: trade.confirmation || "Yes",
    ruleBroken: trade.ruleBroken || "None",
    marketCondition: trade.marketCondition || "Trending",
    setupQuality: trade.setupQuality || getTradeGrade(trade),
    entryQuality: String(trade.entryQuality || "3"),
    exitQuality: String(trade.exitQuality || "3"),
    screenshots: normalizeScreenshots(trade),
  };
}

function summarizeTrades(trades = []) {
  const safe = Array.isArray(trades) ? trades : [];
  const pnl = safe.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0);
  const wins = safe.filter((trade) => Number(trade.pnl) > 0).length;
  const losses = safe.filter((trade) => Number(trade.pnl) < 0).length;
  const breakEvens = safe.filter((trade) => Number(trade.pnl) === 0).length;
  const decisive = wins + losses;
  return { count: safe.length, pnl, wins, losses, breakEvens, decisive, winRate: decisive ? (wins / decisive) * 100 : 0, breakEvenRate: safe.length ? (breakEvens / safe.length) * 100 : 0 };
}

function groupTradesByDate(trades = []) {
  return trades.reduce((groups, trade) => {
    const key = getTradeDateKey(trade);
    if (!key) return groups;
    if (!groups[key]) groups[key] = [];
    groups[key].push(trade);
    return groups;
  }, {});
}

function getCalendarCells(year, monthIndex) {
  const firstDay = new Date(year, monthIndex, 1);
  const start = new Date(year, monthIndex, 1 - firstDay.getDay());
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return { key: formatDateKey(date), day: date.getDate(), dayIndex: date.getDay(), isCurrentMonth: date.getMonth() === monthIndex };
  });
}

function isWeekendDateKey(dateKey) {
  const date = new Date(`${dateKey}T00:00:00`);
  const day = date.getDay();
  return day === 0 || day === 6;
}

function getLastTradingDays(count = 20) {
  const weeks = Math.ceil(count / 5);
  const today = new Date();
  const day = today.getDay();
  const mondayOffset = day === 0 ? -6 : 1 - day;
  const currentWeekMonday = new Date(today);
  currentWeekMonday.setDate(today.getDate() + mondayOffset);
  const start = new Date(currentWeekMonday);
  start.setDate(currentWeekMonday.getDate() - (weeks - 1) * 7);
  const days = [];
  for (let week = 0; week < weeks; week += 1) {
    for (let weekday = 0; weekday < 5; weekday += 1) {
      const date = new Date(start);
      date.setDate(start.getDate() + week * 7 + weekday);
      days.push({ key: formatDateKey(date), weekday });
    }
  }
  return days.slice(-count);
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function uploadScreenshotsForTrade(event, form, setForm) {
  const files = Array.from(event.target.files || []).filter((file) => file.type.startsWith("image/"));
  const current = normalizeScreenshots(form);
  const slots = Math.max(MAX_SCREENSHOTS - current.length, 0);
  const uploaded = await Promise.all(files.slice(0, slots).map(fileToBase64));
  setForm({ ...form, screenshots: [...current, ...uploaded].slice(0, MAX_SCREENSHOTS) });
  event.target.value = "";
}

function getNewestDashboardTrades(trades, limit = 8) {
  return [...trades]
    .sort((a, b) => Number(b.createdAt || b.id || 0) - Number(a.createdAt || a.id || 0))
    .slice(0, limit);
}

function tradeBelongsToAccount(trade, account) {
  if (!account) return true;
  if (trade?.accountId) return String(trade.accountId) === String(account.id);
  if (trade?.accountName) return String(trade.accountName) === String(account.name);
  return String(account.id) === String(defaultAccount.id) || String(account.name) === String(defaultAccount.name);
}

function getTradesForAccount(trades = [], account) {
  return (Array.isArray(trades) ? trades : []).filter((trade) => tradeBelongsToAccount(trade, account));
}

function calculateAccountBalance(account, trades = []) {
  const startingBalance = Number(account?.balance || 0);
  const accountTrades = getTradesForAccount(trades, account);
  const tradePnl = accountTrades.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0);
  return { startingBalance, tradePnl, currentBalance: startingBalance + tradePnl };
}

function getCurrentStreak(trades = []) {
  const ordered = [...trades].sort((a, b) => Number(b.createdAt || b.id || 0) - Number(a.createdAt || a.id || 0));
  const first = ordered.find((trade) => Number(trade.pnl || 0) !== 0);
  if (!first) return { type: "Neutral", count: 0 };
  const isWin = Number(first.pnl || 0) > 0;
  let count = 0;
  for (const trade of ordered) {
    const pnl = Number(trade.pnl || 0);
    if (pnl === 0) continue;
    if ((pnl > 0) === isWin) count += 1;
    else break;
  }
  return { type: isWin ? "Win" : "Loss", count };
}

function getTopGroup(statsGroup = {}, fallback = "No data") {
  const rows = Object.entries(statsGroup);
  if (!rows.length) return { name: fallback, count: 0, pnl: 0 };
  const [name, item] = rows.sort((a, b) => Number(b[1].pnl || 0) - Number(a[1].pnl || 0))[0];
  return { name, ...item };
}

function getWorstMistake(statsGroup = {}) {
  const rows = Object.entries(statsGroup).filter(([name]) => name && name !== "None");
  if (!rows.length) return { name: "No major mistake", count: 0, pnl: 0, losses: 0 };
  const [name, item] = rows.sort((a, b) => Number(a[1].pnl || 0) - Number(b[1].pnl || 0))[0];
  return { name, ...item };
}

function getDashboardInsights(trades = [], stats = {}) {
  const bestSession = getTopGroup(stats.sessionStats, "No session");
  const bestStrategy = getTopGroup(stats.strategyStats, "No strategy");
  const worstMistake = getWorstMistake(stats.mistakeStats);
  const streak = getCurrentStreak(trades);
  const avgRisk = trades.length ? trades.reduce((sum, trade) => sum + Number(trade.risk || 0), 0) / trades.length : 0;
  return [
    { title: "Best Session", value: bestSession.name, detail: `${formatMoney(bestSession.pnl || 0)} · ${bestSession.count || 0} trades`, tone: "emerald", icon: "☀" },
    { title: "Best Strategy", value: bestStrategy.name, detail: `${formatMoney(bestStrategy.pnl || 0)} net P&L`, tone: "fuchsia", icon: "ϟ" },
    { title: "Current Streak", value: streak.count ? `${streak.count} ${streak.type}` : "Neutral", detail: streak.type === "Loss" ? "Slow down and protect capital" : "Stay disciplined", tone: streak.type === "Loss" ? "red" : "emerald", icon: streak.type === "Loss" ? "↘" : "↗" },
    { title: "Avg Risk", value: formatMoney(avgRisk), detail: "Average risk per trade", tone: "amber", icon: "$" },
    { title: "Mistake Watch", value: worstMistake.name, detail: worstMistake.count ? `${worstMistake.losses || 0} losses · ${formatMoney(worstMistake.pnl || 0)}` : "Clean execution so far", tone: worstMistake.count ? "red" : "emerald", icon: "!" },
  ];
}

function getRiskWarnings(form, accountBalance) {
  const risk = Number(form?.risk || 0);
  const balance = Number(accountBalance?.currentBalance || accountBalance?.startingBalance || 0);
  const warnings = [];
  if (!risk || !balance) return warnings;
  const riskPercent = (risk / balance) * 100;
  if (riskPercent > 2) warnings.push({ tone: "red", title: "High Risk", text: `Risk is ${riskPercent.toFixed(2)}% of account. Consider reducing size.` });
  else if (riskPercent > 1) warnings.push({ tone: "amber", title: "Risk Warning", text: `Risk is ${riskPercent.toFixed(2)}% of account. Keep discipline.` });
  else warnings.push({ tone: "emerald", title: "Risk OK", text: `Risk is ${riskPercent.toFixed(2)}% of account.` });
  return warnings;
}

function getRiskDashboardStats(trades = [], startingBalance = 50000) {
  const safe = Array.isArray(trades) ? trades : [];
  const riskTrades = safe.filter((trade) => Number(trade.risk || 0) > 0);
  const avgRisk = riskTrades.length ? riskTrades.reduce((sum, trade) => sum + Number(trade.risk || 0), 0) / riskTrades.length : 0;
  const maxRisk = riskTrades.length ? Math.max(...riskTrades.map((trade) => Number(trade.risk || 0))) : 0;
  const avgRiskPercent = startingBalance ? (avgRisk / Number(startingBalance || 1)) * 100 : 0;
  const maxRiskPercent = startingBalance ? (maxRisk / Number(startingBalance || 1)) * 100 : 0;
  const losses = safe.filter((trade) => Number(trade.pnl || 0) < 0);
  const biggestLoss = losses.length ? Math.min(...losses.map((trade) => Number(trade.pnl || 0))) : 0;
  const riskScores = riskTrades.map((trade) => Number(trade.risk || 0));
  const riskMean = riskScores.length ? riskScores.reduce((sum, value) => sum + value, 0) / riskScores.length : 0;
  const riskVariance = riskScores.length > 1 ? riskScores.reduce((sum, value) => sum + Math.pow(value - riskMean, 2), 0) / (riskScores.length - 1) : 0;
  const riskStd = Math.sqrt(riskVariance);
  const consistencyScore = riskMean ? Math.max(0, Math.min(100, 100 - (riskStd / riskMean) * 100)) : 0;
  const streak = getCurrentStreak(safe);
  return { avgRisk, maxRisk, avgRiskPercent, maxRiskPercent, biggestLoss, consistencyScore, lossStreak: streak.type === "Loss" ? streak.count : 0, riskTrades: riskTrades.length };
}

function getMistakeDetectorStats(trades = []) {
  const safe = Array.isArray(trades) ? trades : [];
  const losses = safe.filter((trade) => Number(trade.pnl || 0) < 0);
  const wins = safe.filter((trade) => Number(trade.pnl || 0) > 0);
  const issueMap = {};
  const rootMap = {
    Execution: { key: "Execution", title: "Execution", count: 0, pnl: 0, issues: [] },
    Psychology: { key: "Psychology", title: "Psychology", count: 0, pnl: 0, issues: [] },
    Risk: { key: "Risk", title: "Risk", count: 0, pnl: 0, issues: [] },
    Setup: { key: "Setup", title: "Setup Quality", count: 0, pnl: 0, issues: [] },
    Discipline: { key: "Discipline", title: "Discipline", count: 0, pnl: 0, issues: [] },
  };

  function addIssue(key, title, trade, type, fix, weight = 1) {
    if (!issueMap[key]) issueMap[key] = { key, title, type, fix, count: 0, weightedCount: 0, pnl: 0, trades: [] };
    issueMap[key].count += 1;
    issueMap[key].weightedCount += weight;
    issueMap[key].pnl += Number(trade.pnl || 0);
    issueMap[key].trades.push(trade);
    if (rootMap[type]) {
      rootMap[type].count += weight;
      rootMap[type].pnl += Number(trade.pnl || 0);
      if (!rootMap[type].issues.includes(title)) rootMap[type].issues.push(title);
    }
  }

  losses.forEach((trade) => {
    const mistake = trade.mistake && trade.mistake !== "None" ? trade.mistake : "Unclassified mistake";
    const timing = trade.entryTiming || "On Time";
    const emotion = trade.emotion || "Calm";
    const ruleBroken = trade.ruleBroken || "None";
    const setupQuality = trade.setupQuality || getTradeGrade(trade);

    if (mistake !== "Unclassified mistake") addIssue(`mistake-${mistake}`, mistake, trade, "Execution", `Focus on removing ${mistake.toLowerCase()} before increasing size.`, 1.3);
    else addIssue("unclassified", "Unclassified mistake", trade, "Discipline", "Tag the exact mistake after each loss so the detector can become more accurate.", 0.6);

    if (["Early", "Late"].includes(timing)) addIssue(`timing-${timing}`, `${timing} entry timing`, trade, "Execution", timing === "Late" ? "Stop chasing price. Wait for the next valid retracement or skip the trade." : "Do not enter before full confirmation. Let the setup complete first.", 1.4);
    if (["Fearful", "Greedy", "FOMO", "Revenge"].includes(emotion)) addIssue(`emotion-${emotion}`, `${emotion} emotion`, trade, "Psychology", "Add a 30-second pause before entry and confirm you are not trading from emotion.", 1.2);
    if (Number(trade.entryQuality || 0) > 0 && Number(trade.entryQuality || 0) <= 2) addIssue("entry-low", "Low entry quality", trade, "Execution", "Wait for full confirmation. Do not enter before the setup is complete.", 1.25);
    if (Number(trade.exitQuality || 0) > 0 && Number(trade.exitQuality || 0) <= 2) addIssue("exit-low", "Low exit quality", trade, "Execution", "Pre-plan partials, target and invalidation before entering the trade.", 1);
    if (["No", "Partial"].includes(trade.ruleFollowed) || ruleBroken !== "None") addIssue("rules-broken", ruleBroken !== "None" ? ruleBroken : "Rules not fully followed", trade, "Discipline", "Only take trades that match your checklist. If rules are not met, skip the trade.", 1.35);
    if (["Bad Risk Management", "Moved Stop Loss", "Overrisk"].includes(mistake) || ["Moved SL", "Overrisk"].includes(ruleBroken)) addIssue("risk-control", "Risk control problem", trade, "Risk", "Reduce size and never move stop loss after entry. Risk must be decided before execution.", 1.4);
    if (["C", "D"].includes(setupQuality) || ["C", "D"].includes(getTradeGrade(trade))) addIssue("setup-quality", "Weak setup quality", trade, "Setup", "Trade only A/B setups and write why the setup deserves execution before entry.", 1.2);
  });

  const issues = Object.values(issueMap).sort((a, b) => b.weightedCount !== a.weightedCount ? b.weightedCount - a.weightedCount : Math.abs(b.pnl) - Math.abs(a.pnl));
  const roots = Object.values(rootMap).filter((root) => root.count > 0).sort((a, b) => b.count - a.count);
  const mainIssue = issues[0] || null;
  const mainRoot = roots[0] || null;
  const confidence = losses.length && mainIssue ? Math.round(Math.min(100, (mainIssue.count / losses.length) * 100)) : 0;
  const affectedPnl = mainIssue ? mainIssue.pnl : 0;
  const cleanTrades = safe.filter((trade) => Number(trade.pnl || 0) >= 0 && (!trade.mistake || trade.mistake === "None")).length;
  const winProfile = { emotion: getMostCommonValue(wins, "emotion", "No emotion"), timing: getMostCommonValue(wins, "entryTiming", "No timing"), setup: getMostCommonValue(wins, "setupQuality", "No grade"), session: getMostCommonValue(wins, "session", "No session") };
  const lossProfile = { emotion: getMostCommonValue(losses, "emotion", "No emotion"), timing: getMostCommonValue(losses, "entryTiming", "No timing"), setup: getMostCommonValue(losses, "setupQuality", "No grade"), session: getMostCommonValue(losses, "session", "No session") };
  const focusPlan = mainRoot ? buildFocusPlan(mainRoot.key, mainIssue?.title) : ["Log at least 5 losing trades with mistake, emotion and entry quality.", "Review screenshots after every trade.", "Keep the same risk until patterns become clear."];

  return { losses, wins, issues, roots, mainIssue, mainRoot, confidence, affectedPnl, cleanTrades, winProfile, lossProfile, focusPlan, summary: losses.length ? `${issues.length} mistake patterns detected from ${losses.length} losing trade${losses.length === 1 ? "" : "s"}.` : "No losing trades detected yet." };
}

function translateDetectorText(value) {
  const map = {
    "None": "No Mistake",
    "Early Entry": "Early Entry",
    "Late Entry": "Late Entry",
    "No Confirmation": "No Confirmation",
    "Overtrading": "Overtrading",
    "Emotional Trade": "Emotional Trade",
    "Bad Risk Management": "Bad Risk Management",
    "Moved Stop Loss": "Moved Stop Loss",
    "Unclassified mistake": "Unclassified Mistake",
    "Early entry timing": "Early Entry Timing",
    "Late entry timing": "Late Entry Timing",
    "Fearful emotion": "Fearful Emotion",
    "Greedy emotion": "Greedy Emotion",
    "FOMO emotion": "FOMO Emotion",
    "Revenge emotion": "Revenge Trading",
    "Low entry quality": "Low Entry Quality",
    "Low exit quality": "Low Exit Quality",
    "Rules not fully followed": "Rules Not Fully Followed",
    "Risk control problem": "Risk Control Problem",
    "Weak setup quality": "Weak Setup Quality",
    "Execution": "Execution",
    "Psychology": "Psychology",
    "Risk": "Risk",
    "Setup": "Setup Quality",
    "Setup Quality": "Setup Quality",
    "Discipline": "Discipline",
    "Calm": "Calm",
    "Confident": "Confident",
    "Fearful": "Fearful",
    "Greedy": "Greedy",
    "FOMO": "FOMO",
    "Revenge": "Revenge",
    "On Time": "On Time",
    "Early": "Early",
    "Late": "Late",
    "No timing": "No Timing Data",
    "No emotion": "No Emotion Data",
    "No grade": "No Grade Data",
    "No session": "No Session Data",
    "Moved SL": "Moved Stop Loss",
    "Overrisk": "Overrisk",
    "No confirmation": "No Confirmation",
    "Chased price": "Chased Price",
    "Revenge trade": "Revenge Trade"
  };
  return map[value] || value || "—";
}

function translateDetectorFix(value) {
  const map = {
    "Tag the exact mistake after each loss so the detector can become more accurate.": "Tag the exact mistake after each loss so the detector can become more accurate.",
    "Stop chasing price. Wait for the next valid retracement or skip the trade.": "Stop chasing price. Wait for the next valid retracement or skip the trade.",
    "Do not enter before full confirmation. Let the setup complete first.": "Do not enter before full confirmation. Let the setup complete first.",
    "Add a 30-second pause before entry and confirm you are not trading from emotion.": "Add a 30-second pause before entry and confirm you are not trading from emotion.",
    "Wait for full confirmation. Do not enter before the setup is complete.": "Wait for full confirmation. Do not enter before the setup is complete.",
    "Pre-plan partials, target and invalidation before entering the trade.": "Pre-plan partials, target and invalidation before entering the trade.",
    "Only take trades that match your checklist. If rules are not met, skip the trade.": "Only take trades that match your checklist. If rules are not met, skip the trade.",
    "Reduce size and never move stop loss after entry. Risk must be decided before execution.": "Reduce size and never move stop loss after entry. Risk must be decided before execution.",
    "Trade only A/B setups and write why the setup deserves execution before entry.": "Trade only A/B setups and write why the setup deserves execution before entry."
  };
  if (map[value]) return map[value];
  if (String(value || "").startsWith("Focus on removing")) return "Focus on removing this mistake before increasing size.";
  return value;
}

function getMostCommonValue(trades = [], key, fallback = "No data") {
  const counts = trades.reduce((output, trade) => {
    const value = trade?.[key] || fallback;
    output[value] = (output[value] || 0) + 1;
    return output;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || fallback;
}

function buildFocusPlan(rootType, issueTitle) {
  const translatedIssue = translateDetectorText(issueTitle || "entry timing");
  const plans = {
    Execution: ["Wait for full confirmation before entering.", "If price already moved away, do not chase it — wait for a new setup or skip.", `Main focus: ${translatedIssue}. Check the screenshot before every next trade.`],
    Psychology: ["Take a 30-second pause before clicking Buy/Sell.", "Write your emotion before the entry, not after the result.", "After an emotional loss, skip the next trade."],
    Risk: ["Define max risk before entry and do not change it.", "Never move the stop loss after entry.", "Reduce size until you complete 5 rule-followed trades in a row."],
    Setup: ["Trade only A/B quality setups this week.", "Before entry, write why the setup is valid.", "Skip C/D setups even if they look attractive."],
    Discipline: ["Use the pre-trade checklist before every trade.", "If one rule is missing, skip the trade.", "Review Rule Broken tags at the end of the day."],
  };
  return plans[rootType] || plans.Execution;
}

function exportTradesToCSV(trades) {
  const safeTrades = Array.isArray(trades) ? trades : [];
  const headers = ["date", "pair", "direction", "quantity", "setup", "session", "result", "emotion", "risk", "pnl", "notes"];
  const rows = safeTrades.map((trade) => headers.map((key) => `"${String(trade[key] ?? "").replaceAll('"', '""')}"`).join(","));
  const csv = [headers.join(","), ...rows].join(String.fromCharCode(10));
  downloadTextFile(csv, "critique-trades.csv", "text/csv;charset=utf-8;");
}

function downloadTextFile(content, filename, type = "application/json;charset=utf-8;") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportCritiqueBackup({ trades, account, routine, theme }) {
  const payload = {
    app: BRAND_NAME,
    version: 1,
    exportedAt: new Date().toISOString(),
    data: {
      trades: Array.isArray(trades) ? trades : [],
      account: account || defaultAccount,
      routine: routine || { date: formatDateKey(new Date()), checked: {}, notes: "" },
      theme: theme || "dark",
    },
  };
  downloadTextFile(JSON.stringify(payload, null, 2), `critique-backup-${formatDateKey(new Date())}.json`);
}

function validateCritiqueBackup(payload) {
  const data = payload?.data || payload;
  const trades = Array.isArray(data?.trades) ? data.trades : null;
  if (!trades) return { ok: false, error: "Backup file-ში trades ვერ მოიძებნა." };
  return {
    ok: true,
    trades: trades.map((trade, index) => ({
      ...trade,
      id: trade.id || Date.now() + index,
      createdAt: trade.createdAt || trade.id || Date.now() + index,
      screenshots: normalizeScreenshots(trade),
      tags: normalizeTags(trade),
    })),
    account: data.account || defaultAccount,
    routine: data.routine || { date: formatDateKey(new Date()), checked: {}, notes: "" },
    theme: data.theme || "dark",
  };
}

function parseCSVLine(line) {
  const values = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];
    if (char === '"' && quoted && next === '"') { current += '"'; index += 1; continue; }
    if (char === '"') { quoted = !quoted; continue; }
    if (char === "," && !quoted) { values.push(current); current = ""; continue; }
    current += char;
  }
  values.push(current);
  return values;
}

function normalizeCSVHeader(header) {
  return String(header || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function validateImportedTrade(trade) {
  const errors = [];
  if (!trade.pair) errors.push("Missing symbol/pair");
  if (!trade.date) errors.push("Missing date");
  if (!Number.isFinite(Number(trade.pnl))) errors.push("Invalid P&L");
  if (!Number.isFinite(Number(trade.quantity)) || Number(trade.quantity) <= 0) errors.push("Invalid quantity");
  if (!Number.isFinite(Number(trade.risk)) || Number(trade.risk) < 0) errors.push("Invalid risk");
  return errors;
}

function getTradeDuplicateKey(trade) {
  return [getTradeDateKey(trade), String(trade.pair || "").toUpperCase(), String(trade.direction || "").toUpperCase(), Number(trade.quantity || 0), Number(trade.pnl || 0), String(trade.setup || "")].join("|");
}

function parseTradesCSV(text, account, existingTrades = []) {
  const lines = String(text || "").replaceAll(String.fromCharCode(13) + String.fromCharCode(10), String.fromCharCode(10)).replaceAll(String.fromCharCode(13), String.fromCharCode(10)).split(String.fromCharCode(10)).filter((line) => line.trim());
  if (lines.length < 2) return { trades: [], duplicates: [], invalidRows: [{ row: 1, errors: ["CSV file is empty or missing data rows"] }] };
  const rawHeaders = parseCSVLine(lines[0]).map((header) => header.trim());
  const headers = rawHeaders.map(normalizeCSVHeader);
  const existingKeys = new Set((existingTrades || []).map(getTradeDuplicateKey));
  const trades = [];
  const duplicates = [];
  const invalidRows = [];

  lines.slice(1).forEach((line, index) => {
    const values = parseCSVLine(line);
    const row = headers.reduce((output, header, headerIndex) => ({ ...output, [header]: values[headerIndex] ?? "" }), {});
    const pnl = Number(row.pnl || row.pl || row.profitloss || 0);
    const result = getResultFromPnl(pnl);
    const trade = {
      id: Date.now() + index,
      createdAt: Date.now() + index,
      accountId: account?.id || defaultAccount.id,
      accountName: account?.name || "v",
      accountType: account?.type || "Demo Account",
      accountCurrency: account?.currency || "USD",
      date: getTradeDateKey({ date: row.date || row.tradedate || row.entrydate }) || formatDateKey(new Date()),
      pair: String(row.pair || row.symbol || row.ticker || "").toUpperCase(),
      direction: String(row.direction || row.type || "Buy").toUpperCase() === "SELL" ? "SELL" : "BUY",
      quantity: Number(row.quantity || row.qty || row.shares || 0),
      setup: row.setup || row.strategy || "Imported Trade",
      session: row.session || row.tradingsession || "Unknown",
      result,
      emotion: row.emotion || row.emotions || "Calm",
      risk: Number(row.risk || 0),
      pnl,
      notes: row.notes || row.note || "Imported from CSV",
      mistake: row.mistake || "None",
      screenshots: [],
      tags: normalizeTags({ tags: row.tags || `result:${result.toLowerCase().replaceAll(" ", "-")}` }),
    };
    const errors = validateImportedTrade(trade);
    const rowNumber = index + 2;
    if (errors.length) {
      invalidRows.push({ row: rowNumber, errors });
      return;
    }
    const duplicateKey = getTradeDuplicateKey(trade);
    if (existingKeys.has(duplicateKey)) {
      duplicates.push({ row: rowNumber, trade });
      return;
    }
    existingKeys.add(duplicateKey);
    trades.push(trade);
  });

  return { trades, duplicates, invalidRows };
}

function calculateStatistics(trades = [], startingBalance = 50000) {
  const safeTrades = Array.isArray(trades) ? trades : [];
  const base = summarizeTrades(safeTrades);
  const wins = safeTrades.filter((trade) => Number(trade.pnl) > 0);
  const losses = safeTrades.filter((trade) => Number(trade.pnl) < 0);
  const avgPnl = safeTrades.length ? base.pnl / safeTrades.length : 0;
  const avgWin = wins.length ? wins.reduce((sum, trade) => sum + Number(trade.pnl), 0) / wins.length : 0;
  const avgLoss = losses.length ? Math.abs(losses.reduce((sum, trade) => sum + Number(trade.pnl), 0) / losses.length) : 0;
  const gradeStats = { A: { count: 0, pnl: 0 }, B: { count: 0, pnl: 0 }, C: { count: 0, pnl: 0 }, D: { count: 0, pnl: 0 } };
  const strategyStats = {};
  const mistakeStats = {};
  const sessionStats = {};

  safeTrades.forEach((trade) => {
    const pnl = Number(trade.pnl || 0);
    const grade = getTradeGrade(trade);
    const strategy = trade.setup || "Manual Trade";
    const mistake = trade.mistake || "None";
    const session = trade.session || "Unknown";
    gradeStats[grade].count += 1;
    gradeStats[grade].pnl += pnl;
    if (!strategyStats[strategy]) strategyStats[strategy] = { count: 0, pnl: 0, wins: 0, losses: 0, breakEvens: 0, rrSum: 0, riskTrades: 0 };
    strategyStats[strategy].count += 1;
    strategyStats[strategy].pnl += pnl;
    if (Number(trade.risk || 0) > 0) { strategyStats[strategy].rrSum += getTradeRR(trade); strategyStats[strategy].riskTrades += 1; }
    if (pnl > 0) strategyStats[strategy].wins += 1;
    if (pnl < 0) strategyStats[strategy].losses += 1;
    if (pnl === 0) strategyStats[strategy].breakEvens += 1;
    if (!mistakeStats[mistake]) mistakeStats[mistake] = { count: 0, pnl: 0, losses: 0 };
    mistakeStats[mistake].count += 1;
    mistakeStats[mistake].pnl += pnl;
    if (pnl < 0) mistakeStats[mistake].losses += 1;
    if (!sessionStats[session]) sessionStats[session] = { count: 0, pnl: 0, wins: 0, losses: 0, breakEvens: 0, rrSum: 0, riskTrades: 0 };
    sessionStats[session].count += 1;
    sessionStats[session].pnl += pnl;
    if (Number(trade.risk || 0) > 0) { sessionStats[session].rrSum += getTradeRR(trade); sessionStats[session].riskTrades += 1; }
    if (pnl > 0) sessionStats[session].wins += 1;
    if (pnl < 0) sessionStats[session].losses += 1;
    if (pnl === 0) sessionStats[session].breakEvens += 1;
  });

  let equity = 0;
  let peak = 0;
  let maxDrawdown = 0;
  [...safeTrades].reverse().forEach((trade) => {
    equity += Number(trade.pnl || 0);
    peak = Math.max(peak, equity);
    maxDrawdown = Math.max(maxDrawdown, peak - equity);
  });

  const grossProfit = wins.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0);
  const grossLoss = Math.abs(losses.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0));
  const profitFactor = grossLoss ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;
  const avgWinLoss = avgLoss ? avgWin / avgLoss : avgWin > 0 ? 999 : 0;
  const tradesWithRisk = safeTrades.filter((trade) => Number(trade.risk || 0) > 0);
  const avgRR = tradesWithRisk.length ? tradesWithRisk.reduce((sum, trade) => sum + getTradeRR(trade), 0) / tradesWithRisk.length : 0;
  const recoveryFactor = maxDrawdown ? base.pnl / maxDrawdown : base.pnl > 0 ? 999 : 0;
  const maxDrawdownPercent = startingBalance ? (maxDrawdown / Number(startingBalance || 1)) * 100 : 0;
  const metricScores = {
    winRate: Math.min(100, Math.max(0, base.winRate)),
    profitFactor: Math.min(100, profitFactor >= 999 ? 100 : profitFactor * 33.33),
    avgWinLoss: Math.min(100, avgWinLoss >= 999 ? 100 : avgWinLoss * 33.33),
    recoveryFactor: Math.min(100, recoveryFactor >= 999 ? 100 : Math.max(0, recoveryFactor * 35)),
    maxDrawdown: Math.min(100, Math.max(0, 100 - maxDrawdownPercent * 10)),
    consistency: Math.min(100, Math.max(0, base.winRate)),
  };
  const score = Math.round((metricScores.winRate + metricScores.profitFactor + metricScores.avgWinLoss + metricScores.recoveryFactor + metricScores.maxDrawdown + metricScores.consistency) / 6);
  return {
    totalPnl: base.pnl, trades: base.count, wins: base.wins, losses: base.losses, breakEvens: base.breakEvens, decisive: base.decisive, winRate: base.winRate, breakEvenRate: base.breakEvenRate, avgPnl, avgWin, avgLoss, avgRR, score,
    grossProfit, grossLoss, profitFactor, avgWinLoss, maxDrawdown, maxDrawdownPercent, gradeStats, strategyStats, mistakeStats, sessionStats,
    metrics: {
      winRate: { label: "Win %", description: "Winning trades divided by total trades", actual: `${base.winRate.toFixed(1)}%`, score: metricScores.winRate },
      profitFactor: { label: "Profit factor", description: "Gross profit divided by gross loss", actual: profitFactor >= 999 ? "Perfect" : profitFactor.toFixed(2), score: metricScores.profitFactor },
      avgWinLoss: { label: "Avg win/loss", description: "Average win compared to average loss", actual: avgWinLoss >= 999 ? "Perfect" : avgWinLoss.toFixed(2), score: metricScores.avgWinLoss },
      recoveryFactor: { label: "Recovery factor", description: "Net profit compared to max drawdown", actual: recoveryFactor >= 999 ? "Perfect" : recoveryFactor.toFixed(2), score: metricScores.recoveryFactor },
      maxDrawdown: { label: "Max drawdown", description: "Largest peak-to-trough decline", actual: `${maxDrawdownPercent.toFixed(1)}%`, score: metricScores.maxDrawdown },
      consistency: { label: "Consistency", description: "How stable your winning performance is", actual: `${base.winRate.toFixed(1)}%`, score: metricScores.consistency },
    },
  };
}

async function loadTradesFromSupabase(userId) {
  if (!supabase || !userId) return null;
  const { data, error } = await supabase
    .from("trades")
    .select("id, created_at, trade_data")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data || []).map((row) => ({
    ...(row.trade_data || {}),
    id: row.id,
    supabaseId: row.id,
    createdAt: row.trade_data?.createdAt || new Date(row.created_at).getTime(),
    screenshots: normalizeScreenshots(row.trade_data || {}),
    tags: normalizeTags(row.trade_data || {}),
  }));
}

async function saveTradeToSupabase(userId, trade) {
  if (!supabase || !userId) return trade;
  const payload = { ...trade };
  delete payload.supabaseId;

  if (trade.supabaseId || (typeof trade.id === "string" && trade.id.includes("-"))) {
    const rowId = trade.supabaseId || trade.id;
    const { data, error } = await supabase
      .from("trades")
      .update({ trade_data: payload })
      .eq("id", rowId)
      .eq("user_id", userId)
      .select("id")
      .single();
    if (error) throw error;
    return { ...trade, id: data.id, supabaseId: data.id };
  }

  const { data, error } = await supabase
    .from("trades")
    .insert({ user_id: userId, trade_data: payload })
    .select("id")
    .single();
  if (error) throw error;
  return { ...trade, id: data.id, supabaseId: data.id };
}

async function deleteTradeFromSupabase(userId, trade) {
  if (!supabase || !userId || !trade) return;
  const rowId = trade.supabaseId || trade.id;
  if (!rowId || typeof rowId !== "string") return;
  const { error } = await supabase
    .from("trades")
    .delete()
    .eq("id", rowId)
    .eq("user_id", userId);
  if (error) throw error;
}

async function loadAccountFromSupabase(userId) {
  if (!supabase || !userId) return null;
  const { data, error } = await supabase
    .from("profiles")
    .select("account_data")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw error;
  return data?.account_data || null;
}

async function saveAccountToSupabase(userId, account) {
  const normalizedAccount = {
    ...defaultAccount,
    ...(account || {}),
    balance: Number(account?.balance || 0),
  };

  if (!supabase || !userId) return normalizedAccount;

  const { data, error } = await supabase
    .from("profiles")
    .upsert(
      {
        id: userId,
        account_data: normalizedAccount,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    )
    .select("account_data")
    .single();

  if (error) throw error;
  return data?.account_data || normalizedAccount;
}

function getRestoreCacheKey(userId) {
  return `${RESTORE_CACHE_PREFIX}_${userId || "guest"}`;
}

function saveRestoreCache(userId, payload) {
  try {
    localStorage.setItem(getRestoreCacheKey(userId), JSON.stringify({ ...payload, cachedAt: new Date().toISOString() }));
  } catch (error) {
    console.warn("Could not cache restored backup:", error?.message || error);
  }
}

function readRestoreCache(userId) {
  try {
    return JSON.parse(localStorage.getItem(getRestoreCacheKey(userId)) || "null");
  } catch {
    return null;
  }
}

function getUserTradesKey(userId) {
  return `${USER_TRADES_KEY_PREFIX}_${userId || "guest"}`;
}

function normalizeTradeForStorage(trade) {
  return {
    ...trade,
    screenshots: normalizeScreenshots(trade),
    tags: normalizeTags(trade),
  };
}

function readLocalTradesFallback(userId) {
  try {
    const userSaved = JSON.parse(localStorage.getItem(getUserTradesKey(userId)) || "[]");
    if (Array.isArray(userSaved) && userSaved.length) return userSaved.map(normalizeTradeForStorage);

    const oldSaved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(oldSaved) ? oldSaved.map(normalizeTradeForStorage) : [];
  } catch {
    return [];
  }
}

function saveLocalTradesFallback(tradesToSave, userId) {
  try {
    const safeTrades = Array.isArray(tradesToSave) ? tradesToSave.map(normalizeTradeForStorage) : [];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(safeTrades));
    localStorage.setItem(getUserTradesKey(userId), JSON.stringify(safeTrades));
  } catch (error) {
    console.warn("Could not save local trades fallback:", error?.message || error);
  }
}

function mergeTradesUnique(primary = [], secondary = []) {
  const output = [];
  const seen = new Set();
  [...primary, ...secondary].forEach((trade) => {
    const normalized = normalizeTradeForStorage(trade);
    const key = normalized.supabaseId || (typeof normalized.id === "string" && normalized.id.includes("-") ? normalized.id : getTradeDuplicateKey(normalized));
    if (seen.has(key)) return;
    seen.add(key);
    output.push(normalized);
  });
  return output.sort((a, b) => Number(b.createdAt || b.id || 0) - Number(a.createdAt || a.id || 0));
}

async function replaceTradesInSupabase(userId, tradesToRestore) {
  if (!supabase || !userId) throw new Error("Supabase/Auth არ არის მზად. თავიდან შედი ანგარიშში და მერე სცადე Restore.");

  const { error: deleteError } = await supabase
    .from("trades")
    .delete()
    .eq("user_id", userId);
  if (deleteError) throw deleteError;

  if (!tradesToRestore.length) return [];

  const rowsToInsert = tradesToRestore.map((trade, index) => {
    const localId = Date.now() + index;
    const tradeData = {
      ...trade,
      id: localId,
      createdAt: trade.createdAt || localId,
      screenshots: normalizeScreenshots(trade),
      tags: normalizeTags(trade),
    };
    delete tradeData.supabaseId;

    return {
      user_id: userId,
      trade_data: tradeData,
    };
  });

  const { data: insertedRows, error: insertError } = await supabase
    .from("trades")
    .insert(rowsToInsert)
    .select("id, created_at, trade_data");

  if (insertError) throw insertError;

  return (insertedRows || []).map((row) => ({
    ...(row.trade_data || {}),
    id: row.id,
    supabaseId: row.id,
    createdAt: row.trade_data?.createdAt || new Date(row.created_at).getTime(),
    screenshots: normalizeScreenshots(row.trade_data || {}),
    tags: normalizeTags(row.trade_data || {}),
  }));
}

function runHelperTests() {
  console.assert(normalizeTags({ tags: "A, B, C" }).length === 3, "tags split by comma");
  console.assert(getTradeRR({ pnl: 200, risk: 100 }) === 2, "R:R works");
  console.assert(getTradeGrade({ pnl: 200, risk: 100 }) === "A", "grade works");
  console.assert(getCalendarCells(2026, 4).length === 42, "calendar grid works");
  console.assert(getLastTradingDays(20).length === 20, "trading activity excludes weekends");
  console.assert(formatDateKey(new Date("2026-05-15T00:00:00")) === "2026-05-15", "date key format works");
  console.assert(formatMoney(400) === "$400", "money format removes cents");
  console.assert(getResultFromPnl(0) === "Break Even", "break even result works");
  console.assert(summarizeTrades([{ pnl: 100 }, { pnl: -50 }, { pnl: 0 }]).winRate === 50, "win rate excludes break even");
  console.assert(calculateStatistics([{ pnl: 100, risk: 50 }, { pnl: -50, risk: 50 }, { pnl: 0, risk: 50 }]).breakEvens === 1, "statistics counts break even");
}

if (typeof window !== "undefined" && !window.__CRITIQUE_VIDEO_STYLE_TESTS_RAN__) {
  window.__CRITIQUE_VIDEO_STYLE_TESTS_RAN__ = true;
  runHelperTests();
}

export default function TradingJournalDashboard() {
  useEffect(() => {
    document.title = BRAND_NAME;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="black"/><circle cx="32" cy="32" r="20" fill="none" stroke="#d946ef" stroke-width="6"/><circle cx="32" cy="32" r="7" fill="#d946ef"/><path d="M32 6v10M32 48v10M6 32h10M48 32h10" stroke="#22c55e" stroke-width="4" stroke-linecap="round"/></svg>`;
    let link = document.querySelector("link[rel~='icon']");
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = `data:image/svg+xml,${encodeURIComponent(svg)}`;
  }, []);
  const [active, setActive] = useState("Dashboard");
  const [tradeViewMode, setTradeViewMode] = useState(null);
  const [trades, setTrades] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const parsed = saved ? JSON.parse(saved) : starterTrades;
      return parsed.map((trade) => ({ ...trade, screenshots: normalizeScreenshots(trade), tags: normalizeTags(trade) }));
    } catch {
      return starterTrades;
    }
  });
  const [accounts, setAccounts] = useState(() => {
    try {
      const savedAccounts = JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "null");
      if (Array.isArray(savedAccounts) && savedAccounts.length) {
        return savedAccounts.map((item, index) => ({ ...defaultAccount, ...item, id: item.id || `acc-${index + 1}` }));
      }
      const legacyAccount = JSON.parse(localStorage.getItem(ACCOUNT_KEY) || "null");
      return [{ ...defaultAccount, ...(legacyAccount || {}), id: legacyAccount?.id || defaultAccount.id }];
    } catch {
      return [defaultAccount];
    }
  });
  const [activeAccountId, setActiveAccountId] = useState(() => {
    try {
      return localStorage.getItem(ACTIVE_ACCOUNT_KEY) || defaultAccount.id;
    } catch {
      return defaultAccount.id;
    }
  });
  const account = useMemo(() => accounts.find((item) => String(item.id) === String(activeAccountId)) || accounts[0] || defaultAccount, [accounts, activeAccountId]);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [isAccountSwitcherOpen, setIsAccountSwitcherOpen] = useState(false);
  const [isSidebarUserMenuOpen, setIsSidebarUserMenuOpen] = useState(false);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [isRoutineOpen, setIsRoutineOpen] = useState(false);
  const [routine, setRoutine] = useState(() => {
    try {
      const todayKey = formatDateKey(new Date());
      const saved = JSON.parse(localStorage.getItem(ROUTINE_KEY));
      if (saved?.date === todayKey) return saved;
      return { date: todayKey, checked: {}, notes: "" };
    } catch {
      return { date: formatDateKey(new Date()), checked: {}, notes: "" };
    }
  });
  const [editingTradeId, setEditingTradeId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [viewTrade, setViewTrade] = useState(null);
  const [importPreview, setImportPreview] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const importFileRef = useRef(null);
  const backupFileRef = useRef(null);
  const [filters, setFilters] = useState({ result: "All", direction: "All", strategy: "All", grade: "All", session: "All", dateFrom: "", dateTo: "", minPnl: "", maxPnl: "", emotion: "All", tag: "" });
  const [selectedCalendarDate, setSelectedCalendarDate] = useState("2026-05-15");
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem(THEME_KEY) || "light";
    } catch {
      return "dark";
    }
  });
  const [authPage, setAuthPage] = useState("login");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authUser, setAuthUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authMessage, setAuthMessage] = useState("");
  const [passwordRecoverySession, setPasswordRecoverySession] = useState(false);
  const [tradesLoading, setTradesLoading] = useState(false);
  const [dataMessage, setDataMessage] = useState("");

  useEffect(() => {
    if (authLoading || tradesLoading) return;
    saveLocalTradesFallback(trades, authUser?.id);
  }, [trades, authUser?.id, authLoading, tradesLoading]);

  useEffect(() => {
    if (!supabase || !authUser?.id || !isAuthenticated) return undefined;
    let mounted = true;
    setTradesLoading(true);
    setDataMessage("");

    const localBeforeFetch = readLocalTradesFallback(authUser.id);
    if (localBeforeFetch.length) {
      setTrades(localBeforeFetch);
      saveRestoreCache(authUser.id, { trades: localBeforeFetch, account, routine, theme });
    }

    loadTradesFromSupabase(authUser.id)
      .then(async (rows) => {
        if (!mounted || !Array.isArray(rows)) return;

        const cachedRestore = readRestoreCache(authUser.id);
        const cachedTrades = Array.isArray(cachedRestore?.trades) ? cachedRestore.trades : [];
        const localTrades = readLocalTradesFallback(authUser.id);

        if (rows.length) {
          const mergedTrades = mergeTradesUnique(rows, localTrades);
          setTrades(mergedTrades);
          saveLocalTradesFallback(mergedTrades, authUser.id);
          saveRestoreCache(authUser.id, { trades: mergedTrades, account, routine, theme });

          if (localTrades.length && mergedTrades.length > rows.length) {
            try {
              await replaceTradesInSupabase(authUser.id, mergedTrades);
              setDataMessage(`Local trades were merged back into Supabase ✅ Trades: ${mergedTrades.length}`);
            } catch (syncError) {
              setDataMessage(syncError?.message || "Local trades are safe in browser storage, but Supabase merge failed. Check RLS policies.");
            }
          }
          return;
        }

        const fallbackTrades = mergeTradesUnique(localTrades, cachedTrades);

        if (fallbackTrades.length) {
          setTrades(fallbackTrades);
          saveLocalTradesFallback(fallbackTrades, authUser.id);
          saveRestoreCache(authUser.id, { trades: fallbackTrades, account, routine, theme });

          try {
            const reSavedTrades = await replaceTradesInSupabase(authUser.id, fallbackTrades);
            if (!mounted) return;
            const finalTrades = reSavedTrades.length ? reSavedTrades : fallbackTrades;
            setTrades(finalTrades);
            saveLocalTradesFallback(finalTrades, authUser.id);
            saveRestoreCache(authUser.id, { trades: finalTrades, account, routine, theme });
            setDataMessage(`Supabase was empty, but your local trades were recovered and re-synced ✅ Trades: ${finalTrades.length}`);
            return;
          } catch (syncError) {
            if (!mounted) return;
            setDataMessage(syncError?.message || "Supabase returned empty. Trades are still safe in browser storage, but Supabase re-sync failed. Check RLS policies.");
            return;
          }
        }

        setTrades([]);
        setDataMessage("Supabase returned 0 trades and no local backup was found. Add/Restore trades again, then refresh to test.");
      })
      .catch((error) => {
        if (!mounted) return;
        const localTrades = readLocalTradesFallback(authUser.id);
        if (localTrades.length) {
          setTrades(localTrades);
          saveRestoreCache(authUser.id, { trades: localTrades, account, routine, theme });
          setDataMessage(`Supabase load failed, but your browser backup is loaded ✅ Trades: ${localTrades.length}. Error: ${error?.message || "Unknown error"}`);
          return;
        }
        setDataMessage(error?.message || "Could not load trades from Supabase.");
      })
      .finally(() => {
        if (mounted) setTradesLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [authUser?.id, isAuthenticated]);
  useEffect(() => {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
    localStorage.setItem(ACTIVE_ACCOUNT_KEY, account.id);
    localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
  }, [accounts, account]);

  useEffect(() => {
    if (!supabase || !authUser?.id || !isAuthenticated) return undefined;
    let mounted = true;

    loadAccountFromSupabase(authUser.id)
      .then((profileAccount) => {
        if (!mounted || !profileAccount) return;
        setAccounts((current) => {
          const normalized = { ...defaultAccount, ...profileAccount, id: profileAccount.id || activeAccountId || defaultAccount.id, balance: Number(profileAccount.balance || defaultAccount.balance) };
          const exists = current.some((item) => String(item.id) === String(normalized.id));
          return exists ? current.map((item) => String(item.id) === String(normalized.id) ? normalized : item) : [normalized, ...current];
        });
      })
      .catch((error) => {
        console.warn("Could not load account profile from Supabase:", error?.message || error);
      });

    return () => {
      mounted = false;
    };
  }, [authUser?.id, isAuthenticated]);
  useEffect(() => { localStorage.setItem(ROUTINE_KEY, JSON.stringify(routine)); }, [routine]);
  useEffect(() => { localStorage.setItem(THEME_KEY, theme); }, [theme]);

  useEffect(() => {
    if (!supabase) {
      setAuthLoading(false);
      return undefined;
    }

    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      const user = data?.session?.user || null;
      setAuthUser(user);
      setIsAuthenticated(Boolean(user));
      setAuthLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      const user = session?.user || null;

      if (event === "PASSWORD_RECOVERY") {
        setPasswordRecoverySession(true);
        setAuthPage("updatePassword");
        setAuthUser(user);
        setIsAuthenticated(false);
        setAuthLoading(false);
        return;
      }

      setAuthUser(user);
      setIsAuthenticated(Boolean(user));
      setAuthLoading(false);
    });

    return () => {
      mounted = false;
      listener?.subscription?.unsubscribe?.();
    };
  }, []);

  async function handleAuthSubmit(mode, values) {
    setAuthMessage("");

    if (!supabase) {
      setAuthMessage("Supabase is not connected. Check that .env is in the project root, contains VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY, then stop and restart npm run dev.");
      return { ok: false, error: new Error("Supabase is not connected") };
    }

    setAuthLoading(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email: values.email, password: values.password });
        if (error) throw error;
        return { ok: true };
      }

      if (mode === "register") {
        const { error } = await supabase.auth.signUp({
          email: values.email,
          password: values.password,
          options: { data: { full_name: values.name, account_type: values.accountType } },
        });
        if (error) throw error;
        setAuthMessage("Registration started. Check your Gmail inbox for the confirmation email.");
        setAuthPage("login");
        return { ok: true, needsConfirmation: true };
      }

      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(values.email, {
          redirectTo: `${window.location.origin}/auth/reset-password`,
        });
        if (error) throw error;
        setAuthMessage("Password reset email sent. Check your Gmail inbox.");
        return { ok: true };
      }

      if (mode === "updatePassword") {
        const { error } = await supabase.auth.updateUser({ password: values.password });
        if (error) throw error;
        setPasswordRecoverySession(false);
        setAuthMessage("Password updated successfully. You can now sign in with your new password.");
        setAuthPage("login");
        await supabase.auth.signOut();
        return { ok: true };
      }
    } catch (error) {
      setAuthMessage(error?.message || "Authentication failed. Try again.");
      return { ok: false, error };
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleSignOut() {
    if (supabase) await supabase.auth.signOut();
    setIsAuthenticated(false);
    setAuthUser(null);
    setIsSidebarUserMenuOpen(false);
  }

  async function handleSaveAccountSettings(nextAccount) {
    const normalizedAccount = {
      ...defaultAccount,
      ...(nextAccount || {}),
      id: nextAccount?.id || account?.id || `acc-${Date.now()}`,
      balance: Number(nextAccount?.balance || 0),
    };

    try {
      setDataMessage("");
      const savedAccount = await saveAccountToSupabase(authUser?.id, normalizedAccount);
      const finalAccount = { ...normalizedAccount, ...savedAccount, id: savedAccount?.id || normalizedAccount.id, balance: Number(savedAccount?.balance ?? normalizedAccount.balance ?? 0) };
      setAccounts((current) => {
        const exists = current.some((item) => String(item.id) === String(finalAccount.id));
        return exists ? current.map((item) => String(item.id) === String(finalAccount.id) ? finalAccount : item) : [finalAccount, ...current];
      });
      setActiveAccountId(finalAccount.id);
      return { ok: true };
    } catch (error) {
      setDataMessage(error?.message || "Could not save account settings to Supabase.");
      return { ok: false, error };
    }
  }

  function createNewAccount() {
    const newAccount = {
      ...defaultAccount,
      id: `acc-${Date.now()}`,
      name: `Account ${accounts.length + 1}`,
      type: "Demo Account",
      balance: 50000,
      description: "Another trading account",
    };
    setAccounts((current) => [newAccount, ...current]);
    setActiveAccountId(newAccount.id);
    setIsAccountSwitcherOpen(false);
    setIsAccountModalOpen(true);
  }

  useEffect(() => {
    const syncRoutineDate = () => {
      const todayKey = formatDateKey(new Date());
      setRoutine((current) => current?.date === todayKey ? current : { date: todayKey, checked: {}, notes: "" });
    };
    syncRoutineDate();
    const intervalId = window.setInterval(syncRoutineDate, 60 * 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  const activeTrades = useMemo(() => getTradesForAccount(trades, account), [trades, account]);
  const accountBalance = useMemo(() => calculateAccountBalance(account, trades), [account, trades]);

  const filteredTrades = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return activeTrades.filter((trade) => {
      const tags = normalizeTags(trade);
      const text = [trade.pair, trade.direction, trade.setup, trade.session, trade.result, trade.mistake, trade.notes, trade.date, tags.join(" ")].join(" ").toLowerCase();
      const dateKey = getTradeDateKey(trade);
      const pnl = Number(trade.pnl || 0);
      return (
        (!query || text.includes(query)) &&
        (filters.result === "All" || trade.result === filters.result) &&
        (filters.direction === "All" || trade.direction === filters.direction.toUpperCase()) &&
        (filters.strategy === "All" || trade.setup === filters.strategy) &&
        (filters.grade === "All" || getTradeGrade(trade) === filters.grade) &&
        (filters.session === "All" || trade.session === filters.session) &&
        (!filters.dateFrom || dateKey >= filters.dateFrom) &&
        (!filters.dateTo || dateKey <= filters.dateTo) &&
        (!filters.minPnl || pnl >= Number(filters.minPnl)) &&
        (!filters.maxPnl || pnl <= Number(filters.maxPnl)) &&
        (filters.emotion === "All" || trade.emotion === filters.emotion) &&
        (!filters.tag || tags.join(" ").toLowerCase().includes(filters.tag.toLowerCase()))
      );
    });
  }, [activeTrades, searchQuery, filters]);

  const stats = useMemo(() => calculateStatistics(activeTrades, Number(account.balance || 0)), [activeTrades, account.balance]);

  const curve = useMemo(() => {
    let balance = 0;
    return [...activeTrades].reverse().map((trade) => {
      balance += Number(trade.pnl || 0);
      return { date: trade.date, pnl: balance, winRate: stats.winRate };
    });
  }, [activeTrades, stats.winRate]);

  function openAddTrade(dateOverride) {
    setEditingTradeId(null);
    setForm({ ...emptyForm, date: typeof dateOverride === "string" ? dateOverride : formatDateKey(new Date()), screenshots: [] });
    setIsTradeModalOpen(true);
  }
  function openEditTrade(trade) {
    setEditingTradeId(trade.id);
    setForm(formFromTrade(trade));
    setIsTradeModalOpen(true);
  }
  function closeTradeModal() {
    setEditingTradeId(null);
    setForm({ ...emptyForm, screenshots: [] });
    setIsTradeModalOpen(false);
  }
  async function saveTrade() {
    const required = [form.symbol, form.date, form.session, form.strategy];
    const pnl = Number(form.pnl);
    const quantity = Number(form.quantity);
    const risk = Number(form.risk);
    if (required.some((item) => !item || String(item).startsWith("Select")) || Number.isNaN(pnl) || Number.isNaN(quantity) || quantity <= 0 || Number.isNaN(risk) || risk < 0) return;
    const normalizedResult = getResultFromPnl(pnl);
    const normalizedTags = normalizeTags(form).filter((tag) => !String(tag).toLowerCase().startsWith("result:"));
    const existingTrade = trades.find((item) => item.id === editingTradeId);
    const trade = createTradeFromForm({ ...form, result: normalizedResult, tags: [`result:${normalizedResult.toLowerCase().replaceAll(" ", "-")}`, ...normalizedTags].join(", "), pnl, quantity, risk }, editingTradeId || existingTrade?.id, account);
    const tradeForSave = existingTrade?.supabaseId ? { ...trade, supabaseId: existingTrade.supabaseId } : trade;

    try {
      setDataMessage("");
      const savedTrade = await saveTradeToSupabase(authUser?.id, tradeForSave);
      setTrades((current) => {
        const nextTrades = editingTradeId ? current.map((item) => (item.id === editingTradeId ? savedTrade : item)) : [savedTrade, ...current];
        saveLocalTradesFallback(nextTrades, authUser?.id);
        if (authUser?.id) saveRestoreCache(authUser.id, { trades: nextTrades, account, routine, theme });
        return nextTrades;
      });
      closeTradeModal();
    } catch (error) {
      setTrades((current) => {
        const localTrade = { ...tradeForSave, id: editingTradeId || Date.now(), createdAt: tradeForSave.createdAt || Date.now() };
        const nextTrades = editingTradeId ? current.map((item) => (item.id === editingTradeId ? localTrade : item)) : [localTrade, ...current];
        saveLocalTradesFallback(nextTrades, authUser?.id);
        if (authUser?.id) saveRestoreCache(authUser.id, { trades: nextTrades, account, routine, theme });
        return nextTrades;
      });
      closeTradeModal();
      setDataMessage(`Trade saved in browser backup ✅ Supabase save failed: ${error?.message || "check RLS policies"}`);
    }
  }
  async function importTradesFromFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const parsed = parseTradesCSV(text, account, trades);
    setImportPreview({ ...parsed, filename: file.name });
    event.target.value = "";
  }
  async function confirmImportTrades() {
    if (!importPreview?.trades?.length) return;

    try {
      setDataMessage("");
      const savedTrades = [];

      for (const trade of importPreview.trades) {
        const savedTrade = await saveTradeToSupabase(authUser?.id, trade);
        savedTrades.push(savedTrade);
      }

      setTrades((current) => {
        const nextTrades = [...savedTrades, ...current];
        saveLocalTradesFallback(nextTrades, authUser?.id);
        if (authUser?.id) saveRestoreCache(authUser.id, { trades: nextTrades, account, routine, theme });
        return nextTrades;
      });
      setImportPreview(null);
      setDataMessage(`${savedTrades.length} imported trade${savedTrades.length === 1 ? "" : "s"} saved locally + to Supabase ✅`);
    } catch (error) {
      setTrades((current) => {
        const nextTrades = [...importPreview.trades, ...current];
        saveLocalTradesFallback(nextTrades, authUser?.id);
        if (authUser?.id) saveRestoreCache(authUser.id, { trades: nextTrades, account, routine, theme });
        return nextTrades;
      });
      setImportPreview(null);
      setDataMessage(`Trades saved in browser backup ✅ Supabase import failed: ${error?.message || "check RLS policies"}`);
    }
  }
  async function restoreBackupFromFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      if (!supabase || !authUser?.id) {
        throw new Error("Supabase/Auth არ არის მზად. თავიდან შედი ანგარიშში და მერე სცადე Restore.");
      }

      const text = await file.text();
      const parsed = validateCritiqueBackup(JSON.parse(text));
      if (!parsed.ok) {
        window.alert(parsed.error || "Backup file ვერ წაიკითხა.");
        return;
      }

      const currentLocalTrades = readLocalTradesFallback(authUser.id);
      const currentSupabaseTrades = await loadTradesFromSupabase(authUser.id);
      const currentTrades = mergeTradesUnique(trades, mergeTradesUnique(currentSupabaseTrades || [], currentLocalTrades));
      const mergedTrades = mergeTradesUnique(parsed.trades, currentTrades);
      const addedCount = Math.max(0, mergedTrades.length - currentTrades.length);
      const duplicateCount = Math.max(0, parsed.trades.length - addedCount);

      const confirmed = window.confirm(`Backup restore/merge?

Backup trades: ${parsed.trades.length}
Current trades: ${currentTrades.length}
Final trades after merge: ${mergedTrades.length}
Skipped duplicates: ${duplicateCount}

ეს აღარ წაშლის ახალ trades-ს. Backup დაემატება არსებულ trades-ს და დუბლიკატები არ გამეორდება.`);
      if (!confirmed) return;

      setDataMessage("Merging backup with your current trades...");

      const restoredTrades = await replaceTradesInSupabase(authUser.id, mergedTrades);
      const restoredAccount = await saveAccountToSupabase(authUser.id, parsed.account);
      const verifiedTrades = await loadTradesFromSupabase(authUser.id);
      const finalTrades = Array.isArray(verifiedTrades) && verifiedTrades.length === mergedTrades.length ? verifiedTrades : restoredTrades;

      if (finalTrades.length !== mergedTrades.length) {
        throw new Error(`Restore merge verification failed. Expected ${mergedTrades.length} trades, but Supabase returned ${finalTrades.length}.`);
      }

      saveRestoreCache(authUser.id, {
        trades: finalTrades,
        account: restoredAccount,
        routine: parsed.routine,
        theme: parsed.theme,
      });

      saveLocalTradesFallback(finalTrades, authUser.id);
      localStorage.setItem(ACCOUNT_KEY, JSON.stringify(restoredAccount));
      localStorage.setItem(ROUTINE_KEY, JSON.stringify(parsed.routine));
      localStorage.setItem(THEME_KEY, parsed.theme);

      setTrades(finalTrades);
      setAccounts((current) => {
        const finalAccount = { ...defaultAccount, ...restoredAccount, id: restoredAccount.id || account.id || defaultAccount.id, balance: Number(restoredAccount.balance || defaultAccount.balance) };
        const exists = current.some((item) => String(item.id) === String(finalAccount.id));
        return exists ? current.map((item) => String(item.id) === String(finalAccount.id) ? finalAccount : item) : [finalAccount, ...current];
      });
      setRoutine(parsed.routine);
      setTheme(parsed.theme);
      setDataMessage(`Backup merged, verified and cached ✅ Final trades: ${finalTrades.length}. Added: ${addedCount}. Skipped duplicates: ${duplicateCount}.`);
      window.alert(`Backup წარმატებით დაემატა არსებულ trades-ს ✅
Final trades: ${finalTrades.length}
Added: ${addedCount}
Skipped duplicates: ${duplicateCount}

ახლა refresh გააკეთე. ახალი trades აღარ უნდა წაიშალოს.`);
    } catch (error) {
      setDataMessage(error?.message || "Backup file არასწორია ან Supabase-ში ვერ ჩაიწერა.");
      window.alert(error?.message || "Backup file არასწორია ან დაზიანებულია.");
    } finally {
      event.target.value = "";
    }
  }
  function openStrategyFilters() {
    setActive("Journal");
    setShowFilters(true);
    setFilters((current) => ({ ...current, strategy: current.strategy || "All" }));
  }
  async function deleteTrade(id) {
    const tradeToDelete = trades.find((trade) => trade.id === id);
    try {
      setDataMessage("");
      await deleteTradeFromSupabase(authUser?.id, tradeToDelete);
      setTrades((current) => {
        const nextTrades = current.filter((trade) => trade.id !== id);
        saveLocalTradesFallback(nextTrades, authUser?.id);
        if (authUser?.id) saveRestoreCache(authUser.id, { trades: nextTrades, account, routine, theme });
        return nextTrades;
      });
      setViewTrade(null);
      setTradeViewMode(null);
    } catch (error) {
      setDataMessage(error?.message || "Could not delete trade from Supabase.");
    }
  }
  function openTradeDetails(trade) {
    setViewTrade(trade);
    setTradeViewMode("details");
  }

  if (authLoading && !isAuthenticated) {
    return (
      <div className={theme === "light" ? "light-theme flex min-h-screen items-center justify-center bg-black text-white" : "flex min-h-screen items-center justify-center bg-black text-white"}>
        <style>{THEME_STYLE_CSS}</style>
        <div className="rounded-2xl border border-fuchsia-500/25 bg-black p-6 text-center shadow-[0_0_35px_rgba(217,70,239,0.16)]">
          <div className="text-3xl text-fuchsia-400">{BRAND_MARK}</div>
          <div className="mt-3 text-sm font-black text-zinc-300">Loading secure session...</div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className={theme === "light" ? "light-theme min-h-screen overflow-x-hidden bg-black text-white" : "min-h-screen overflow-x-hidden bg-black text-white"}>
        <style>{THEME_STYLE_CSS}</style>
        <AuthPage
          authPage={authPage}
          setAuthPage={setAuthPage}
          onSubmitAuth={handleAuthSubmit}
          authLoading={authLoading}
          authMessage={authMessage}
          isSupabaseReady={isSupabaseReady}
          passwordRecoverySession={passwordRecoverySession}
          theme={theme}
          setTheme={setTheme}
        />
      </div>
    );
  }

  return (
    <div className={theme === "light" ? "light-theme min-h-screen overflow-x-hidden bg-black text-white" : "min-h-screen overflow-x-hidden bg-black text-white"}>
      <style>{THEME_STYLE_CSS}</style>
      <aside className="fixed left-0 top-0 z-30 hidden h-full w-64 border-r border-white/10 bg-black p-5 lg:block">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-xl font-black"><span className="text-fuchsia-400 drop-shadow-[0_0_12px_rgba(217,70,239,0.85)]">{BRAND_MARK}</span><span className="tracking-tight">{BRAND_NAME}</span></div>
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 px-3 py-2 text-sm font-black text-fuchsia-300 transition hover:bg-fuchsia-500 hover:text-black"
            title={theme === "dark" ? "Switch to white mode" : "Switch to dark mode"}
          >
            {theme === "dark" ? "☀" : "🌙"}
          </button>
        </div>
        <div className="relative mt-10">
          <button onClick={() => setIsAccountSwitcherOpen((open) => !open)} className="account-sidebar-card flex w-full items-center justify-between rounded-lg border border-white/10 bg-zinc-950 px-3 py-3 text-left hover:border-fuchsia-500/40">
            <div>
              <div className="text-sm font-bold">🎯 {account.name}</div>
              <div className="text-xs text-zinc-400">{account.currency} {accountBalance.currentBalance.toLocaleString()}</div>
            </div>
            <span className={isAccountSwitcherOpen ? "rotate-180 text-zinc-500 transition" : "text-zinc-500 transition"}>⌄</span>
          </button>

          {isAccountSwitcherOpen && (
            <motion.div initial={{ opacity: 0, y: 8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} className="absolute left-0 top-14 z-50 w-80 overflow-hidden rounded-xl border border-white/10 bg-[#070707] p-1 shadow-[0_18px_55px_rgba(0,0,0,0.90)] ring-1 ring-fuchsia-500/15">
              <div className="flex items-center justify-between border-b border-white/10 px-3 py-3">
                <div className="text-sm font-black text-white">Trading Accounts</div>
                <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-black text-white">{accounts.length} Account{accounts.length === 1 ? "" : "s"}</span>
              </div>

              <div className="max-h-72 overflow-y-auto p-1">
                {accounts.map((item) => {
                  const itemBalance = calculateAccountBalance(item, trades);
                  const isActive = String(item.id) === String(account.id);
                  return (
                    <button key={item.id} onClick={() => { setActiveAccountId(item.id); setIsAccountSwitcherOpen(false); }} className={isActive ? "flex w-full items-center justify-between rounded-lg border border-fuchsia-500/25 bg-fuchsia-500/12 px-3 py-3 text-left" : "flex w-full items-center justify-between rounded-lg border border-transparent px-3 py-3 text-left hover:border-fuchsia-500/25 hover:bg-white/5"}>
                      <div className="flex min-w-0 items-center gap-3">
                        <span className="text-lg">🎯</span>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="truncate text-sm font-black text-white">{item.name}</span>
                            {isActive && <span className="rounded-full bg-fuchsia-500 px-2 py-0.5 text-[10px] font-black text-black">Active</span>}
                          </div>
                          <div className="mt-1 flex items-center gap-2 text-xs">
                            <span className="rounded-md bg-blue-500/15 px-2 py-0.5 font-black text-blue-300">{String(item.type || "Demo").replace(" Account", "")}</span>
                            <span className="font-bold text-zinc-400">{item.currency} {Number(itemBalance.currentBalance || 0).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                      <button type="button" onClick={(event) => { event.stopPropagation(); setActiveAccountId(item.id); setIsAccountModalOpen(true); setIsAccountSwitcherOpen(false); }} className="rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-[10px] font-black text-zinc-400 hover:border-fuchsia-500/50 hover:text-fuchsia-300">Edit</button>
                    </button>
                  );
                })}
              </div>

              <button onClick={createNewAccount} className="flex w-full items-center gap-3 border-t border-white/10 px-4 py-4 text-left transition hover:bg-fuchsia-500/10">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-fuchsia-500/15 text-xl font-black text-fuchsia-300">+</span>
                <span>
                  <span className="block text-sm font-black text-fuchsia-300">Create New Account</span>
                  <span className="block text-xs font-semibold text-zinc-400">Add another trading account</span>
                </span>
              </button>
            </motion.div>
          )}
        </div>
        <div className="mt-6 space-y-2">
          {nav.map(([Icon, label]) => (
            <button key={label} onClick={() => { setActive(label); setTradeViewMode(null); }} className={`flex w-full items-center gap-3 rounded-lg px-3 py-3 text-sm ${active === label && !tradeViewMode ? "bg-fuchsia-500 text-black font-black" : "text-zinc-300 hover:bg-white/5"}`}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </div>
        <div className="absolute bottom-5 left-5 right-5">
          {isSidebarUserMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="mb-3 overflow-hidden rounded-2xl border border-white/10 bg-[#070707] p-2 shadow-[0_18px_55px_rgba(0,0,0,0.85)] ring-1 ring-fuchsia-500/10"
            >
              <button
                onClick={() => {
                  setIsAccountModalOpen(true);
                  setIsSidebarUserMenuOpen(false);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-bold text-zinc-200 transition hover:bg-white/5 hover:text-white"
              >
                <Settings size={17} className="text-zinc-400" />
                Settings
              </button>
              <button
                onClick={() => window.alert("Billing page coming soon.")}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-bold text-zinc-200 transition hover:bg-white/5 hover:text-white"
              >
                <CreditCard size={17} className="text-zinc-400" />
                Billing
              </button>
              <div className="my-2 h-px bg-white/10" />
              <button
                onClick={handleSignOut}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-bold text-red-400 transition hover:bg-red-500/10 hover:text-red-300"
              >
                <LogOut size={17} />
                Sign out
              </button>
            </motion.div>
          )}

          <button
            onClick={() => setIsSidebarUserMenuOpen((open) => !open)}
            className="account-sidebar-card flex w-full items-center justify-between rounded-xl border border-fuchsia-500/20 bg-fuchsia-950/40 p-3 text-left transition hover:border-fuchsia-400/50 hover:bg-fuchsia-950/55"
          >
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-fuchsia-500 text-sm font-black text-black">v</div>
              <div className="min-w-0">
                <div className="truncate text-sm font-black text-white">{authUser?.user_metadata?.full_name || account.name || "vazha buianovi"}</div>
                <div className="text-xs font-semibold text-zinc-400">{authUser?.email || "Pro Trial"}</div>
              </div>
            </div>
            <span className={isSidebarUserMenuOpen ? "text-zinc-400 transition rotate-180" : "text-zinc-400 transition"}>⌄</span>
          </button>
        </div>
      </aside>
      <main className="min-h-screen overflow-x-hidden pb-24 p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-none">
        {tradesLoading && (
          <div className="mb-5 rounded-2xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-4 py-3 text-sm font-black text-fuchsia-300">
            Loading your saved trades from Supabase...
          </div>
        )}
        {dataMessage && (
          <div className="mb-5 rounded-2xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-black text-red-300">
            {dataMessage}
          </div>
        )}
        {tradeViewMode === "details" && viewTrade ? (
          <TradeDetailsPage
            trade={viewTrade}
            account={account}
            onBack={() => { setTradeViewMode(null); setViewTrade(null); }}
            onEdit={() => openEditTrade(viewTrade)}
            onDelete={() => deleteTrade(viewTrade.id)}
            onExport={() => exportTradesToCSV([viewTrade])}
          />
        ) : active === "Dashboard" ? (
          <Dashboard
            stats={stats}
            account={account}
            accountBalance={accountBalance}
            curve={curve}
            trades={activeTrades}
            recentTrades={getNewestDashboardTrades(activeTrades)}
            onAdd={openAddTrade}
            onView={openTradeDetails}
            onStartDay={() => setIsRoutineOpen(true)}
            routine={routine}
            selectedCalendarDate={selectedCalendarDate}
            onSelectCalendarDate={(dateKey) => { setSelectedCalendarDate(dateKey); setActive("Calendar"); }}
            onViewAllTrades={() => setActive("Journal")}
            onOpenMistakeDetector={() => setActive("Mistake Detector")}
            onOpenAccount={() => setIsAccountModalOpen(true)}
          />
        ) : active === "Journal" ? (
          <JournalPage
            trades={filteredTrades}
            allTrades={activeTrades}
            stats={stats}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            filters={filters}
            setFilters={setFilters}
            showFilters={showFilters}
            setShowFilters={setShowFilters}
            onAdd={openAddTrade}
            onEdit={openEditTrade}
            onView={openTradeDetails}
            onRemove={deleteTrade}
            onExport={() => exportTradesToCSV(activeTrades)}
            onImport={() => importFileRef.current?.click()}
            onBackup={() => exportCritiqueBackup({ trades: activeTrades, account, routine, theme })}
            onRestore={() => backupFileRef.current?.click()}
            onStrategies={openStrategyFilters}
          />
        ) : active === "Calendar" ? (
          <CalendarPage
            trades={activeTrades}
            onAdd={() => openAddTrade(selectedCalendarDate)}
            selectedDate={selectedCalendarDate}
            setSelectedDate={setSelectedCalendarDate}
          />
        ) : active === "Statistics" ? (
          <StatisticsPage stats={stats} curve={curve} trades={activeTrades} onExport={() => exportTradesToCSV(activeTrades)} />
        ) : (
          <MistakeDetectorPage trades={activeTrades} />
        )}
        </div>
      </main>
      <MobileBottomNav active={active} setActive={setActive} onAdd={openAddTrade} setTradeViewMode={setTradeViewMode} />
      <input ref={importFileRef} type="file" accept=".csv,text/csv" onChange={importTradesFromFile} className="hidden" />
      <input ref={backupFileRef} type="file" accept=".json,application/json" onChange={restoreBackupFromFile} className="hidden" />
      {isTradeModalOpen && <AddTradeModal isEditing={Boolean(editingTradeId)} form={form} setForm={setForm} onClose={closeTradeModal} onSave={saveTrade} account={account} accountBalance={accountBalance} />}
      {importPreview && <ImportPreviewModal preview={importPreview} onConfirm={confirmImportTrades} onClose={() => setImportPreview(null)} />}
      {isRoutineOpen && <PreTradeRoutineModal routine={routine} setRoutine={setRoutine} onClose={() => setIsRoutineOpen(false)} />}
      {isAccountModalOpen && <AccountModal account={account} accountBalance={accountBalance} onSaveAccount={handleSaveAccountSettings} onClose={() => setIsAccountModalOpen(false)} />}
    </div>
  );
}

function MobileHeader({ onAdd }) {
  return (
    <div className="mb-6 flex items-center justify-between rounded-2xl border border-fuchsia-500/25 bg-black p-4 lg:hidden">
      <div className="flex items-center gap-3 text-xl font-black"><span className="text-fuchsia-400 drop-shadow-[0_0_12px_rgba(217,70,239,0.85)]">{BRAND_MARK}</span><span className="tracking-tight">{BRAND_NAME}</span></div>
      <button onClick={onAdd} className="rounded-xl bg-fuchsia-500 px-3 py-2 text-sm font-black text-white">Add Trade</button>
    </div>
  );
}

function MobileBottomNav({ active, setActive, onAdd, setTradeViewMode }) {
  const items = [
    [LayoutDashboard, "Dashboard"],
    [BookOpen, "Journal"],
    [Calendar, "Calendar"],
    [BarChart3, "Statistics"],
    [Target, "Mistake Detector"],
  ];
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-fuchsia-500/25 bg-black/95 px-2 py-2 backdrop-blur lg:hidden">
      <button onClick={onAdd} className="absolute -top-7 left-1/2 flex h-14 w-14 -translate-x-1/2 items-center justify-center rounded-2xl bg-fuchsia-500 text-white shadow-[0_0_28px_rgba(217,70,239,.48)]"><Plus size={24} /></button>
      <div className="grid grid-cols-5 gap-1">
        {items.map(([Icon, label]) => {
          const isAdd = false;
          const selected = active === label;
          return (
            <button
              key={label}
              onClick={() => {
                setTradeViewMode(null);
                setActive(label);
              }}
              className={isAdd ? "mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-fuchsia-500 text-white shadow-[0_0_22px_rgba(217,70,239,.38)]" : selected ? "flex flex-col items-center justify-center rounded-xl border border-fuchsia-500/35 bg-fuchsia-500/15 px-1 py-2 text-fuchsia-300" : "flex flex-col items-center justify-center rounded-xl px-1 py-2 text-zinc-500"}
            >
              <Icon size={18} />
              <span className="mt-1 text-[9px] font-black leading-tight">{label === "Mistake Detector" ? "Mistake" : label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TopCrumb({ page }) {
  return (
    <div className="mb-8 flex items-center gap-3 text-sm font-semibold">
      <span className="text-fuchsia-400 drop-shadow-[0_0_12px_rgba(217,70,239,0.85)]">{BRAND_MARK}</span>
      <span className="tracking-tight">{BRAND_NAME}</span>
      <span className="text-zinc-500">/</span>
      <span>{page}</span>
    </div>
  );
}

function JournalPage({ trades, allTrades, stats, searchQuery, setSearchQuery, filters, setFilters, showFilters, setShowFilters, onAdd, onEdit, onView, onRemove, onExport, onImport, onBackup, onRestore, onStrategies }) {
  const [sortBy, setSortBy] = useState("Date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [viewMode, setViewMode] = useState("grid");
  const strategies = ["All", ...Array.from(new Set(allTrades.map((trade) => trade.setup).filter(Boolean)))];
  const sessions = ["All", ...TRADING_SESSIONS, ...Array.from(new Set(allTrades.map((trade) => trade.session).filter(Boolean))).filter((session) => !TRADING_SESSIONS.includes(session))];
  const activeFilters = Object.entries(filters).filter(([key, value]) => value && value !== "All" && key !== "tag").length + (filters.tag ? 1 : 0);
  const sortedTrades = useMemo(() => {
    const direction = sortDirection === "asc" ? 1 : -1;
    return [...trades].sort((a, b) => {
      if (sortBy === "P&L") return (Number(a.pnl || 0) - Number(b.pnl || 0)) * direction;
      if (sortBy === "Symbol") return String(a.pair || "").localeCompare(String(b.pair || "")) * direction;
      if (sortBy === "Grade") return getTradeGrade(a).localeCompare(getTradeGrade(b)) * direction;
      return String(getTradeDateKey(a)).localeCompare(String(getTradeDateKey(b))) * direction;
    });
  }, [trades, sortBy, sortDirection]);
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <TopCrumb page="Journal" />
      <div className="journal-hero flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-6 shadow-[0_18px_45px_rgba(217,70,239,0.10)]">
        <div className="flex items-center gap-4">
          <div className="journal-hero-icon rounded-xl border border-fuchsia-500/35 bg-fuchsia-500/15 p-3 text-fuchsia-300 shadow-[0_0_18px_rgba(217,70,239,0.18)]"><BookOpen /></div>
          <div><h1 className="text-3xl font-black">Trading Journal</h1><p className="text-zinc-400">v • Track and analyze your trades efficiently</p></div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={onStrategies} variant="outline" className="journal-action-btn border-white/15 bg-black text-white"><ListChecks size={16} /> Strategies</Button>
          <Button onClick={onImport} variant="outline" className="journal-action-btn border-white/15 bg-black text-white"><Upload size={16} /> CSV Import</Button>
          <Button onClick={onExport} variant="outline" className="journal-action-btn border-white/15 bg-black text-white"><Download size={16} /> CSV</Button>
          <Button onClick={onBackup} variant="outline" className="journal-action-btn border-emerald-500/35 bg-emerald-500/10 text-emerald-300"><Download size={16} /> Backup</Button>
          <Button onClick={onRestore} variant="outline" className="journal-action-btn border-amber-500/35 bg-amber-500/10 text-amber-300"><Upload size={16} /> Restore</Button>
          <Button onClick={onAdd} className="journal-add-btn bg-fuchsia-500 text-white shadow-[0_0_18px_rgba(217,70,239,0.22)]"><Plus size={16} /> Add Trade</Button>
        </div>
      </div>
      <div className="journal-search-panel mt-8 rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-zinc-950 via-black to-[#100716] p-4 shadow-[0_16px_38px_rgba(217,70,239,0.08)]">
        <div className="flex flex-col gap-4 lg:flex-row">
          <div className="group relative flex flex-1 items-center gap-3 overflow-hidden rounded-xl border border-fuchsia-500/35 bg-gradient-to-br from-zinc-950 via-black to-black px-4 py-3 text-zinc-400 shadow-[0_0_22px_rgba(217,70,239,0.12)] transition-all duration-300 hover:border-fuchsia-400/80 hover:shadow-2xl hover:shadow-fuchsia-500/25 focus-within:border-fuchsia-400/90 focus-within:shadow-[0_0_28px_rgba(217,70,239,0.28)]"><div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-500/50 to-transparent" /><div className="relative z-10 flex h-10 w-10 items-center justify-center rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300 shadow-[0_0_14px_rgba(217,70,239,0.18)]"><Search size={18} /></div><Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search trades, symbols, strategies..." className="relative z-10 border-0 bg-transparent text-white placeholder:text-zinc-500 focus-visible:ring-0" /></div>
          <Button onClick={() => setShowFilters(!showFilters)} variant="outline" className={showFilters ? "border-fuchsia-500/60 bg-fuchsia-500 text-white font-black shadow-[0_0_18px_rgba(217,70,239,0.28)] hover:bg-fuchsia-400" : "border-fuchsia-500/35 bg-fuchsia-500/15 text-fuchsia-300 font-black hover:border-fuchsia-400/70 hover:bg-fuchsia-500/25 hover:text-white"}><Filter size={16} /> Filters {showFilters ? "⌃" : "⌄"}</Button>
        </div>
        {showFilters && (
          <div className="mt-6 rounded-xl border border-fuchsia-500/45 bg-gradient-to-br from-zinc-950 via-black to-black p-5 shadow-[0_0_28px_rgba(217,70,239,0.22)] ring-1 ring-fuchsia-500/15">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Field label="Status"><Select value={filters.result} onChange={(e) => setFilters({ ...filters, result: e.target.value })}><option>All</option><option>Win</option><option>Loss</option><option>Break Even</option></Select></Field>
              <Field label="Type"><Select value={filters.direction} onChange={(e) => setFilters({ ...filters, direction: e.target.value })}><option>All</option><option>Buy</option><option>Sell</option></Select></Field>
              <Field label="Strategy"><Select value={filters.strategy} onChange={(e) => setFilters({ ...filters, strategy: e.target.value })}>{strategies.map((strategy) => <option key={strategy}>{strategy}</option>)}</Select></Field>
              <Field label="Grade"><Select value={filters.grade} onChange={(e) => setFilters({ ...filters, grade: e.target.value })}><option>All</option><option>A</option><option>B</option><option>C</option><option>D</option></Select></Field>
              <Field label="Session"><Select value={filters.session} onChange={(e) => setFilters({ ...filters, session: e.target.value })}>{sessions.map((session) => <option key={session}>{session}</option>)}</Select></Field>
              <DateFilterField label="From Date" value={filters.dateFrom} onChange={(value) => setFilters({ ...filters, dateFrom: value })} />
              <DateFilterField label="To Date" value={filters.dateTo} onChange={(value) => setFilters({ ...filters, dateTo: value })} />
              <Field label="Min P&L ($)"><MoneyInput value={filters.minPnl} onChange={(e) => setFilters({ ...filters, minPnl: e.target.value })} /></Field>
              <Field label="Max P&L ($)"><MoneyInput value={filters.maxPnl} onChange={(e) => setFilters({ ...filters, maxPnl: e.target.value })} /></Field>
              <Field label="Tags"><Input value={filters.tag} onChange={(e) => setFilters({ ...filters, tag: e.target.value })} placeholder="Add tag filter" className="border-white/15 bg-black focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" /></Field>
              <Field label="Emotions"><Select value={filters.emotion} onChange={(e) => setFilters({ ...filters, emotion: e.target.value })}><option>All</option><option>Calm</option><option>Confident</option><option>Fearful</option><option>Greedy</option></Select></Field>
            </div>
            <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4">
              <Button variant="outline" onClick={() => { setSearchQuery(""); setFilters({ result: "All", direction: "All", strategy: "All", grade: "All", session: "All", dateFrom: "", dateTo: "", minPnl: "", maxPnl: "", emotion: "All", tag: "" }); }} className="border-white/15 bg-black text-white">Clear All Filters</Button>
              <span className="text-xs text-fuchsia-400">{activeFilters} active filters</span>
            </div>
          </div>
        )}
      </div>
      <div className="journal-stats-grid mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
        <StatCard title="Total Trades" value={stats.trades} />
        <StatCard title="Win Rate" value={`${stats.winRate.toFixed(1)}%`} green />
        <StatCard title="Break Even" value={stats.breakEvens || 0} gold />
        <StatCard title="Avg P&L" value={formatMoney(stats.avgPnl)} green />
        <StatCard title="Avg R:R" value={`1:${stats.avgRR.toFixed(1)}`} gold />
        <StatCard title="Total P&L" value={formatMoney(stats.totalPnl)} green />
      </div>
      <div className="journal-sort-panel mt-6 rounded-2xl border border-fuchsia-500/35 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-4 shadow-[0_0_22px_rgba(217,70,239,0.12)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-sm text-zinc-400">
            <span>Sort by:</span>
            <div className="w-36"><Select value={sortBy} onChange={(e) => setSortBy(e.target.value)}><option>Date</option><option>P&L</option><option>Symbol</option><option>Grade</option></Select></div>
            <button onClick={() => setSortDirection(sortDirection === "asc" ? "desc" : "asc")} className="rounded-lg border border-fuchsia-500/35 bg-fuchsia-950/25 px-3 py-2 font-black text-fuchsia-300 shadow-[0_0_14px_rgba(217,70,239,0.12)] transition hover:border-fuchsia-400/80 hover:bg-fuchsia-500 hover:text-black hover:shadow-[0_0_20px_rgba(217,70,239,0.28)]">{sortDirection === "asc" ? "↑" : "↓"}</button>
          </div>
          <div className="flex items-center gap-3 text-sm text-zinc-400">
            <span>View:</span>
            <button onClick={() => setViewMode("grid")} className={viewMode === "grid" ? "rounded-lg border border-fuchsia-400 bg-fuchsia-500 px-3 py-2 font-black text-black shadow-[0_0_18px_rgba(217,70,239,0.35)]" : "rounded-lg border border-fuchsia-500/35 bg-fuchsia-950/20 px-3 py-2 text-fuchsia-300 transition hover:border-fuchsia-400/80 hover:bg-fuchsia-500/20"}>▦</button>
            <button onClick={() => setViewMode("list")} className={viewMode === "list" ? "rounded-lg border border-fuchsia-400 bg-fuchsia-500 px-3 py-2 font-black text-black shadow-[0_0_18px_rgba(217,70,239,0.35)]" : "rounded-lg border border-fuchsia-500/35 bg-fuchsia-950/20 px-3 py-2 text-fuchsia-300 transition hover:border-fuchsia-400/80 hover:bg-fuchsia-500/20"}>☷</button>
          </div>
        </div>
      </div>
      {viewMode === "grid" ? (
        <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          {sortedTrades.map((trade) => <TradeCard key={trade.id} trade={trade} onView={() => onView(trade)} onEdit={() => onEdit(trade)} onRemove={() => onRemove(trade.id)} />)}
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {sortedTrades.map((trade) => <TradeListRow key={trade.id} trade={trade} onView={() => onView(trade)} onEdit={() => onEdit(trade)} onRemove={() => onRemove(trade.id)} />)}
        </div>
      )}
      {sortedTrades.length === 0 && <div className="journal-empty mt-8 rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-zinc-950 via-black to-[#12081b] p-10 text-center text-zinc-400"><div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300"><Search size={20} /></div><div className="text-lg font-black text-white">No trades found</div><div className="mt-1 text-sm text-zinc-500">Try changing filters or add a new trade.</div></div>}
    </motion.div>
  );
}

function DateFilterField({ label, value, onChange }) {
  const [isOpen, setIsOpen] = useState(false);
  const baseDate = value ? new Date(`${value}T00:00:00`) : new Date();
  const [viewDate, setViewDate] = useState(new Date(baseDate.getFullYear(), baseDate.getMonth(), 1));
  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const monthName = viewDate.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const cells = getCalendarCells(year, month);

  function pickDate(dateKey) {
    setIsOpen(false);
    onChange(dateKey);
  }

  return (
    <Field label={label}>
      <div className="relative">
        <button
          type="button"
          onClick={() => setIsOpen((open) => !open)}
          className="date-picker-trigger flex h-10 w-full items-center gap-3 rounded-md border border-white/15 bg-black px-3 text-left text-sm text-white outline-none transition-all hover:border-fuchsia-400 focus:border-fuchsia-400 focus:shadow-[0_0_14px_rgba(217,70,239,0.16)]"
        >
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300 shadow-[0_0_12px_rgba(217,70,239,0.16)]"><Calendar size={16} /></span>
          <span className={value ? "date-picker-value text-white" : "date-picker-placeholder text-zinc-500"}>{value || "mm/dd/yyyy"}</span>
        </button>
        {isOpen && (
          <div className="date-picker-popover absolute left-0 top-12 z-[9999] w-80 rounded-xl border border-fuchsia-500/40 bg-black p-4 shadow-[0_18px_55px_rgba(0,0,0,0.95)] ring-1 ring-fuchsia-500/20">
            <div className="mb-4 flex items-center justify-between">
              <button type="button" onClick={() => setViewDate(new Date(year, month - 1, 1))} className="date-picker-nav rounded-lg border border-white/10 bg-zinc-950 p-2 text-zinc-300 hover:border-fuchsia-500/50"><ChevronLeft size={16} /></button>
              <div className="date-picker-title font-black text-white">{monthName}</div>
              <button type="button" onClick={() => setViewDate(new Date(year, month + 1, 1))} className="date-picker-nav rounded-lg border border-white/10 bg-zinc-950 p-2 text-zinc-300 hover:border-fuchsia-500/50"><ChevronRight size={16} /></button>
            </div>
            <div className="date-picker-weekdays grid grid-cols-7 gap-1 text-center text-[10px] font-black text-zinc-500">
              {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => <div key={`${day}-${index}`} className="py-1">{day}</div>)}
            </div>
            <div className="mt-2 grid grid-cols-7 gap-1">
              {cells.map((cell) => (
                <button
                  type="button"
                  key={cell.key}
                  onMouseDown={(event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    pickDate(cell.key);
                  }}
                  onClick={(event) => event.stopPropagation()}
                  className={`date-picker-day relative z-10 h-9 rounded-lg text-xs font-bold transition-all hover:bg-fuchsia-500/20 ${value === cell.key ? "date-picker-day-selected bg-fuchsia-500 text-black" : cell.isCurrentMonth ? "date-picker-day-current bg-zinc-950 text-white" : "date-picker-day-muted bg-black text-zinc-600"}`}
                >
                  <span
                    className="date-picker-day-number"
                    style={{ color: value === cell.key ? "#ffffff" : cell.isCurrentMonth ? "#0f172a" : "#475569", opacity: 1, visibility: "visible", display: "inline-block", fontWeight: 900 }}
                  >
                    {cell.day}
                  </span>
                </button>
              ))}
            </div>
            <div className="mt-3 flex justify-between border-t border-white/10 pt-3">
              <button type="button" onClick={() => { onChange(""); setIsOpen(false); }} className="text-xs font-bold text-zinc-400 hover:text-white">Clear</button>
              <button type="button" onClick={() => setIsOpen(false)} className="text-xs font-bold text-fuchsia-300 hover:text-fuchsia-200">Done</button>
            </div>
          </div>
        )}
      </div>
    </Field>
  );
}

function TradeCard({ trade, onView, onEdit, onRemove }) {
  const screenshots = normalizeScreenshots(trade);
  const pnl = Number(trade.pnl || 0);
  const isWin = pnl > 0;
  const isBreakEven = pnl === 0;
  const grade = getTradeGrade(trade);
  const rr = getTradeRR(trade);
  const tags = normalizeTags(trade).slice(0, 3);
  return (
    <div className="trade-card group relative overflow-hidden rounded-2xl border border-fuchsia-500/35 bg-gradient-to-br from-zinc-950 via-black to-black shadow-[0_0_22px_rgba(217,70,239,0.12)] transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:border-fuchsia-400/80 hover:shadow-2xl hover:shadow-fuchsia-500/25">
      <div className="absolute right-0 top-0 h-28 w-28 rounded-bl-[2rem] bg-fuchsia-500/10" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-500/50 to-transparent" />
      <button onClick={onView} className="trade-screenshot-area relative block h-48 w-full overflow-hidden bg-zinc-900 text-left">
        {screenshots.length ? <><img src={screenshots[0]} alt="Trade screenshot" className="trade-screenshot-image h-full w-full object-cover transition-all duration-500 group-hover:scale-105 group-hover:opacity-95" /><div className="absolute inset-0 bg-gradient-to-t from-black via-black/15 to-transparent" /></> : <div className="trade-no-screenshot flex h-full flex-col items-center justify-center bg-gradient-to-br from-zinc-950 via-black to-fuchsia-950/20 text-zinc-500"><div className="trade-no-screenshot-icon flex h-14 w-14 items-center justify-center rounded-2xl border border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300"><Camera size={24} /></div><span className="trade-no-screenshot-text mt-3 text-xs font-bold">No Screenshot</span><span className="mt-1 text-[11px] font-semibold text-zinc-500">Edit trade → upload image</span></div>}
        <div className="absolute left-4 top-4 flex gap-2"><span className="rounded-full border border-fuchsia-500/30 bg-black/70 px-3 py-1 text-xs font-black text-fuchsia-300 backdrop-blur">{trade.pair}</span><span className={`rounded-full border px-3 py-1 text-xs font-black tracking-wider backdrop-blur ${getTradeDirectionClass(trade.direction)}`}>{trade.direction}</span></div>
        <div className={`absolute bottom-4 right-4 rounded-xl border px-4 py-2 text-lg font-black backdrop-blur ${getPnlPillClass(pnl)}`}>{getPnlArrow(pnl)} {formatMoney(pnl)}</div>
      </button>
      <div className="relative z-10 p-5">
        <div className="flex items-start justify-between gap-3"><div><div className="text-xs font-bold uppercase tracking-wider text-zinc-500">{trade.date} • {trade.session || "No session"}</div><div className="mt-2 text-lg font-black text-white">{trade.setup}</div><div className="mt-1 text-xs text-zinc-400">{trade.accountName || "v"} • {trade.accountType || "Account"}</div></div><span className={`rounded-full border px-3 py-1 text-xs font-black ${getTradeGradeClass(grade)}`}>Grade {grade}</span></div>
        <div className="mt-4 grid grid-cols-3 gap-3"><MetricBox label="Risk" value={formatMoney(trade.risk)} tone="fuchsia" /><MetricBox label="R:R" value={`${rr.toFixed(2)}R`} tone="fuchsia" /><MetricBox label="Qty" value={trade.quantity} tone="fuchsia" /></div>
        <div className="mt-4 flex flex-wrap gap-2">{tags.length ? tags.map((tag) => <span key={tag} className="trade-tag rounded-full border border-fuchsia-500/35 bg-fuchsia-500/15 px-3 py-1.5 text-xs font-black text-fuchsia-200 shadow-[0_0_10px_rgba(217,70,239,0.16)]">#{tag}</span>) : <span className="text-xs text-zinc-500">No tags</span>}</div>
        <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4"><div className="flex items-center gap-2 text-xs"><span className="rounded-full border border-cyan-500/25 bg-cyan-500/10 px-3 py-1.5 font-bold text-cyan-200">{trade.emotion || "No emotion"}</span><span className={trade.mistake && trade.mistake !== "None" ? "rounded-full border border-red-500/30 bg-red-500/10 px-3 py-1.5 font-bold text-red-300" : "rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 font-bold text-emerald-300"}>{trade.mistake || "None"}</span></div><div className="flex gap-2"><button onClick={onView} className="rounded-lg border border-white/10 bg-black p-2 text-zinc-300 transition hover:border-fuchsia-500/50 hover:text-fuchsia-300"><Eye size={16} /></button><button onClick={onEdit} className="rounded-lg border border-white/10 bg-black p-2 text-zinc-300 transition hover:border-fuchsia-500/50 hover:text-fuchsia-300"><Edit3 size={16} /></button><button onClick={onRemove} className="rounded-lg border border-red-500/20 bg-red-500/10 p-2 text-red-400 transition hover:border-red-500/60"><Trash2 size={16} /></button></div></div>
      </div>
    </div>
  );
}

function TradeListRow({ trade, onView, onEdit, onRemove }) {
  const pnl = Number(trade.pnl || 0);
  const isWin = pnl > 0;
  const isBreakEven = pnl === 0;
  const rr = getTradeRR(trade);
  const tags = normalizeTags(trade).slice(0, 2);
  return (
    <div className="group relative overflow-hidden rounded-xl border border-fuchsia-500/35 bg-gradient-to-br from-zinc-950 via-black to-black p-5 shadow-[0_0_18px_rgba(217,70,239,0.10)] transition-all duration-300 hover:border-fuchsia-400/80 hover:shadow-2xl hover:shadow-fuchsia-500/20">
      <div className="absolute right-0 top-0 h-20 w-20 rounded-bl-[2rem] bg-fuchsia-500/10" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-500/50 to-transparent" />
      <div className="relative z-10 flex items-center justify-between gap-5">
        <div className="flex min-w-0 items-center gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-fuchsia-500/35 bg-fuchsia-500/15 text-sm font-black text-fuchsia-300">{trade.pair}</span>
          <span className={`rounded-full border px-3 py-1 text-xs font-black tracking-wider ${getTradeDirectionClass(trade.direction)}`}>{trade.direction}</span>
          <span className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-black text-white">{trade.setup}</span>
          {tags.map((tag) => <span key={tag} className="hidden rounded-full bg-white/5 px-2 py-1 text-xs text-zinc-400 xl:inline">{tag}</span>)}
        </div>
        <div className="flex items-center gap-7 text-sm text-zinc-400">
          <span className="journal-list-metric-chip">Qty {trade.quantity}</span>
          <span className="journal-list-metric-chip">◎ 1:{Math.abs(rr).toFixed(1)}</span>
          <span className="text-fuchsia-300">⌖ {trade.session || "—"}</span>
          <span>{trade.date}</span>
          <span className={`min-w-28 text-right text-xl font-black ${getPnlToneClass(pnl)}`}>{getPnlArrow(pnl)} {formatMoney(pnl)}</span>
          <div className="flex gap-2">
            <button onClick={onView} className="rounded-lg border border-white/10 bg-black p-2 text-zinc-300 transition hover:border-fuchsia-500/50 hover:text-fuchsia-300"><Eye size={16} /></button>
            <button onClick={onEdit} className="rounded-lg border border-white/10 bg-black p-2 text-zinc-300 transition hover:border-fuchsia-500/50 hover:text-fuchsia-300"><Edit3 size={16} /></button>
            <button onClick={onRemove} className="rounded-lg border border-red-500/20 bg-red-500/10 p-2 text-red-400 transition hover:border-red-500/60"><Trash2 size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricBox({ label, value, tone }) {
  return (
    <div className="journal-metric-box group relative overflow-hidden rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 p-3 shadow-[0_0_14px_rgba(217,70,239,0.10)] transition-all duration-300 hover:-translate-y-0.5 hover:border-fuchsia-400/75 hover:bg-fuchsia-500/15 hover:shadow-[0_0_22px_rgba(217,70,239,0.22)]">
      <div className="pointer-events-none absolute right-0 top-0 h-10 w-10 rounded-bl-2xl bg-fuchsia-500/10" />
      <div className="relative z-10 text-xs font-black uppercase tracking-wider text-fuchsia-300">{label}</div>
      <div className="relative z-10 mt-1 text-xl font-black text-white">{value}</div>
    </div>
  );
}

function TradeDetailsPage({ trade, account, onBack, onEdit, onDelete, onExport }) {
  const screenshots = normalizeScreenshots(trade);
  const [activeIndex, setActiveIndex] = useState(null);
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-5xl">
      <TopCrumb page="Journal" />
      <div className="mb-8 flex items-center justify-between"><button onClick={onBack} className="text-sm font-bold text-zinc-300 hover:text-white">← Back</button><div className="flex gap-3"><Button onClick={onExport} variant="outline" className="border-white/15 bg-black text-white"><Download size={16} /> Export</Button><Button onClick={onEdit} variant="outline" className="border-white/15 bg-black text-white"><Edit3 size={16} /> Edit</Button><Button onClick={onDelete} className="bg-red-600 text-white"><Trash2 size={16} /> Delete</Button></div></div>
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1fr_320px]">
        <div className="flex h-full flex-col gap-6">
          <div className="flex items-center gap-4"><div className="rounded-xl bg-fuchsia-500/20 p-4 text-fuchsia-300">{trade.pair}</div><div><h1 className="text-3xl font-black">{trade.pair} Trade Details</h1><p className="text-zinc-400">{trade.direction} • {trade.quantity} shares • {trade.date}</p></div></div>
          <div className={`rounded-xl border p-6 ${Number(trade.pnl) > 0 ? "border-emerald-500/30 bg-emerald-950/30" : Number(trade.pnl) < 0 ? "border-red-500/30 bg-red-950/30" : "border-amber-500/30 bg-amber-950/30"}`}><div className="text-sm text-zinc-400">Total P&L</div><div className={`mt-2 text-4xl font-black ${getPnlToneClass(trade.pnl)}`}>{getPnlArrow(trade.pnl)} {formatMoney(trade.pnl)}</div></div>
          <div className="rounded-xl border border-white/10 bg-zinc-950 p-6"><SectionTitle title="Trade Metadata" icon={<BarChart3 size={18} />} /><div className="mt-8 grid grid-cols-2 gap-8 border-b border-white/10 pb-6"><Meta label="Quantity" value={trade.quantity} /><Meta label="Session" value={trade.session || "—"} /></div><div className="grid grid-cols-2 gap-8 border-b border-white/10 py-6"><Meta label="Entry Date" value={trade.date} /><Meta label="Exit Date" value={trade.date} /></div><div className="grid grid-cols-3 gap-8 pt-6"><Meta label="Risk" value={formatMoney(trade.risk)} danger /><Meta label="Risk/Reward Ratio" value={`${getTradeRR(trade).toFixed(2)}:1`} gold /><Meta label="Realized P&L" value={formatMoney(trade.pnl)} green={Number(trade.pnl) > 0} gold={Number(trade.pnl) === 0} danger={Number(trade.pnl) < 0} /></div></div>
          <div className="rounded-xl border border-white/10 bg-zinc-950 p-6"><SectionTitle title={`Trade Screenshots (${screenshots.length})`} icon={<Camera size={18} />} /><div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">{screenshots.length ? screenshots.map((img, index) => <button key={index} onClick={() => setActiveIndex(index)}><img src={img} alt="Trade screenshot" className="h-56 w-full rounded-lg object-cover hover:opacity-80" /></button>) : <div className="col-span-2 rounded-xl border border-dashed border-white/10 bg-black p-10 text-center text-zinc-500">No screenshots uploaded</div>}</div></div>
          <div className="rounded-xl border border-white/10 bg-zinc-950 p-6"><SectionTitle title="Trade Analysis" icon={<BookOpen size={18} />} /><p className="trade-analysis-note mt-4 rounded-xl bg-black p-4 text-zinc-300">{trade.notes || "No notes"}</p><div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2"><ReviewBox title="What went well?" value={trade.whatWentWell || "No review yet"} tone="emerald" /><ReviewBox title="What went wrong?" value={trade.whatWentWrong || "No review yet"} tone="red" /></div><div className="mt-5 grid grid-cols-2 gap-4 md:grid-cols-4"><Meta label="Rule Followed" value={trade.ruleFollowed || "—"} green={trade.ruleFollowed === "Yes"} danger={trade.ruleFollowed === "No"} /><Meta label="Entry Timing" value={trade.entryTiming || "—"} gold /><Meta label="Setup Quality" value={trade.setupQuality || getTradeGrade(trade)} gold /><Meta label="Market" value={trade.marketCondition || "—"} /><Meta label="Confirmation" value={trade.confirmation || "—"} green={trade.confirmation === "Yes"} danger={trade.confirmation === "No"} /><Meta label="Rule Broken" value={trade.ruleBroken || "None"} danger={trade.ruleBroken && trade.ruleBroken !== "None"} /><Meta label="Entry Quality" value={`${trade.entryQuality || "—"}/5`} gold /><Meta label="Exit Quality" value={`${trade.exitQuality || "—"}/5`} gold /></div></div>
        </div>
        <div className="space-y-5"><SideBox title="Trade Info"><MiniInfo label="Strategy" value={trade.setup} /><MiniInfo label="Account" value={trade.accountName || account?.name || "v"} /><MiniInfo label="Account Type" value={trade.accountType || account?.type || "—"} /><MiniInfo label="Trade Type" value={trade.direction} badge tone={trade.direction === "SELL" ? "red" : "green"} /></SideBox><SideBox title="Tags"><div className="flex flex-wrap gap-2">{normalizeTags(trade).length ? normalizeTags(trade).map((tag) => <span key={tag} className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold">{tag}</span>) : <span className="text-zinc-500">No tags</span>}</div></SideBox><SideBox title="Emotions"><span className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold">{trade.emotion || "—"}</span></SideBox><SideBox title="Quality"><div className={`w-fit rounded-full border px-3 py-1 text-xs font-black ${getTradeGradeClass(getTradeGrade(trade))}`}>Grade {getTradeGrade(trade)}</div><div className="mt-3 text-sm text-zinc-400">Mistake: {trade.mistake || "None"}</div></SideBox></div>
      </div>
      {activeIndex !== null && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95"><button onClick={() => setActiveIndex(null)} className="absolute right-8 top-8 text-3xl text-white">×</button><button onClick={() => setActiveIndex((activeIndex - 1 + screenshots.length) % screenshots.length)} className="absolute left-8 text-5xl text-white">‹</button><img src={screenshots[activeIndex]} alt="Fullscreen screenshot" className="max-h-[90vh] max-w-[90vw] rounded" /><button onClick={() => setActiveIndex((activeIndex + 1) % screenshots.length)} className="absolute right-8 text-5xl text-white">›</button></div>}
    </motion.div>
  );
}

function ReviewBox({ title, value, tone }) {
  const cls = tone === "emerald" ? "border-emerald-500/25 bg-emerald-500/10" : "border-red-500/25 bg-red-500/10";
  return <div className={`rounded-xl border p-4 ${cls}`}><div className="text-xs font-black uppercase tracking-widest text-zinc-400">{title}</div><div className="mt-2 text-sm font-semibold text-zinc-300">{value}</div></div>;
}

function Dashboard({ stats, account, accountBalance, curve, trades, recentTrades, onAdd, onView, onStartDay, routine, selectedCalendarDate, onSelectCalendarDate, onViewAllTrades, onOpenMistakeDetector, onOpenAccount }) {
  const [performanceMode, setPerformanceMode] = useState("EquityCurve");
  const quote = quotes[new Date().getDate() % quotes.length];
  const checkedCount = routineItems.filter((item) => routine.checked?.[item.id]).length;
  const routinePercent = Math.round((checkedCount / routineItems.length) * 100);

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <MobileHeader onAdd={onAdd} />

      <div className="mb-8 flex items-center justify-between gap-4">
        <TopCrumb page="Dashboard" />
        <div className="hidden items-center gap-4 lg:flex">
          <button onClick={onOpenAccount} className="flex items-center gap-2 rounded-xl border border-white/10 bg-zinc-950/80 px-4 py-2 text-sm font-black text-white shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
            <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]" />
            {account.name}
            <span className="rounded-lg bg-white/10 px-2 py-0.5 text-xs">{account.currency}</span>
          </button>
          <button className="rounded-xl border border-white/10 bg-black px-3 py-2 text-zinc-300 hover:border-fuchsia-500/40 hover:text-white">♧</button>
          <button className="rounded-xl border border-white/10 bg-black px-3 py-2 text-zinc-300 hover:border-fuchsia-500/40 hover:text-white">☼</button>
        </div>
      </div>

      <div className="dashboard-hero rounded-2xl border border-fuchsia-500/35 bg-gradient-to-r from-fuchsia-950/45 via-black to-orange-950/10 p-6 shadow-[0_0_45px_rgba(168,85,247,0.13)]">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div>
            <h1 className="text-3xl font-black xl:text-4xl">Welcome back, vazha! 👋</h1>
            <p className="mt-3 flex items-center gap-2 text-base font-semibold text-zinc-400">▣ {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button onClick={onAdd} className="dashboard-primary-btn bg-fuchsia-500 px-5 py-3 font-black text-black shadow-[0_0_24px_rgba(217,70,239,0.28)]">▣ Log Trade</Button>
            <Button onClick={onStartDay} className="dashboard-start-btn border border-emerald-500/45 bg-black px-5 py-3 font-black text-white hover:bg-emerald-500/15">Start Your Day</Button>
          </div>
        </div>
        <div className="dashboard-inspiration mt-6 rounded-xl border border-white/10 bg-gradient-to-r from-white/[0.04] via-fuchsia-500/[0.05] to-orange-500/[0.05] p-5 text-center">
          <div className="text-sm font-black uppercase tracking-widest text-fuchsia-400">✬ Daily Inspiration ✬</div>
          <div className="moving-text-wrap mt-2">
            <div className="moving-text-track">
              {quotes.map((item, index) => (
                <div key={index} className="moving-text-slide">
                  <span className="moving-text-item">
                    <span className="moving-text-spark">✦</span>
                    {item}
                    <span className="moving-text-spark">✦</span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <DashCard title="TOTAL P&L" value={<RotatingPnlValue pnl={stats.totalPnl} balance={accountBalance.startingBalance} />} badge={stats.totalPnl >= 0 ? "↗ Positive P&L" : "↘ Negative P&L"} tone={stats.totalPnl >= 0 ? "emerald" : "amber"} icon="$" />
        <DashCard title="WIN RATE" value={`${stats.winRate.toFixed(1)}%`} badge={`↗ ${stats.wins}W / ${stats.losses}L`} tone="fuchsia" icon="🏆" />
        <DashCard title="TOTAL TRADES" value={stats.trades} badge={`▣ ${stats.trades} closed`} tone="cyan" icon="⌁" />
        <DashCard title="AVG WIN/LOSS" value={`${formatMoney(stats.avgWin)} / ${formatMoney(stats.avgLoss)}`} badge={stats.avgWinLoss >= 999 ? "↗ Positive R:R" : `${stats.avgWinLoss.toFixed(2)} ratio`} tone="amber" icon="↗" />
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 xl:grid-cols-[2fr_1fr]">
        <div className="dashboard-performance-card light-card rounded-2xl border border-white/15 bg-gradient-to-br from-[#08070b] via-black to-[#050307] p-6 shadow-[0_20px_55px_rgba(217,70,239,0.10)]">
          <div className="relative z-10 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/35 bg-black text-fuchsia-300"><TrendingUp size={22} /></div>
              <div>
                <h2 className="text-2xl font-black">Performance Overview</h2>
                <p className="text-sm text-zinc-400">Your cumulative P&L over time</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 rounded-xl border border-white/10 bg-black/70 p-1.5">
              {[
                ["EquityCurve", "↗ EquityCurve"],
                ["WinRate", "⌁ WinRate"],
                ["DailyP&L", "▥ DailyP&L"],
              ].map(([mode, label]) => (
                <button key={mode} onClick={() => setPerformanceMode(mode)} className={performanceMode === mode ? "rounded-lg bg-fuchsia-500 px-4 py-2 text-sm font-black text-black" : "rounded-lg px-4 py-2 text-sm font-black text-zinc-300 hover:bg-white/5"}>{label}</button>
              ))}
            </div>
          </div>
          <PerformanceOverviewChart mode={performanceMode} trades={trades} curve={curve} stats={stats} />
        </div>
        <PerformanceScorePanel stats={stats} />
      </div>

      <QuickInsights insights={getDashboardInsights(trades, stats)} />

      <DashboardMistakeAlert trades={trades} onOpen={onOpenMistakeDetector} />

      <div className="mt-8 grid grid-cols-1 items-stretch gap-6 xl:grid-cols-[2fr_1fr]">
        <div className="flex h-full min-h-0 flex-col gap-6">
          <div className="dashboard-recent-card light-card relative flex flex-1 flex-col overflow-hidden rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-6 shadow-[0_20px_55px_rgba(217,70,239,0.10)]">
            <div className="relative z-10 mb-5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/15 text-fuchsia-300"><TrendingUp size={22} /></div>
                <div>
                  <h2 className="text-2xl font-black">Recent Trades</h2>
                  <p className="text-sm text-zinc-400">Your latest activity</p>
                </div>
              </div>
              <button onClick={onViewAllTrades} className="view-all-button rounded-xl border border-fuchsia-500/35 bg-fuchsia-500 px-4 py-2 text-sm font-black text-white">View All</button>
            </div>
            <div className="dashboard-recent-list light-card-soft relative z-10 flex-1 rounded-2xl border border-fuchsia-500/18 bg-black/45 p-4">
              {recentTrades.map((trade) => {
                const screenshots = normalizeScreenshots(trade);
                const pnl = Number(trade.pnl || 0);
                return (
                  <button key={trade.id} onClick={() => onView(trade)} className="dashboard-recent-row group flex w-full items-center justify-between rounded-xl border border-transparent p-3 text-left transition-all hover:border-fuchsia-500/35 hover:bg-fuchsia-500/8">
                    <div className="flex items-center gap-4">
                      <div className="h-16 w-16 overflow-hidden rounded-xl border border-white/10 bg-zinc-900">
                        {screenshots.length ? <img src={screenshots[0]} alt="Trade" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-zinc-500"><Camera size={18} /></div>}
                      </div>
                      <div>
                        <div className="flex items-center gap-2"><span className="text-xl font-black">{trade.pair}</span><span className="rounded-full border border-fuchsia-500/30 bg-fuchsia-500/10 px-2.5 py-1 text-xs font-black text-fuchsia-100">{trade.setup}</span></div>
                        <div className="mt-1 text-sm font-semibold text-zinc-400">{trade.quantity} shares • {trade.date}</div>
                      </div>
                    </div>
                    <div className={`rounded-xl border px-3 py-2 font-black ${getPnlPillClass(pnl)}`}>{getPnlArrow(pnl)} {formatMoney(pnl)}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <button onClick={onStartDay} className="group relative min-h-[220px] w-full overflow-hidden rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-emerald-950/50 via-black to-[#050307] p-6 text-left">
            <div className="relative z-10 flex h-full flex-col justify-between">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs font-black uppercase tracking-wider text-zinc-400">Pre-Trade Routine</div>
                  <div className="mt-4 text-4xl font-black text-white">{checkedCount}/{routineItems.length}</div>
                  <div className="mt-2 text-sm font-bold text-emerald-300">{routinePercent === 100 ? "Ready to Trade" : `${routinePercent}% complete`}</div>
                </div>
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-emerald-500/30 bg-emerald-500/15 text-2xl text-emerald-300">✅</div>
              </div>
              <div className="mt-6">
                <div className="mb-2 flex justify-between text-[10px] font-black uppercase tracking-wider text-zinc-500"><span>Checklist Progress</span><span>{routinePercent}%</span></div>
                <div className="h-4 overflow-hidden rounded-full bg-zinc-800"><div className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-emerald-300 to-fuchsia-400" style={{ width: `${routinePercent}%` }} /></div>
              </div>
            </div>
          </button>
        </div>
        <TradingActivityPanel trades={trades} selectedDate={selectedCalendarDate} onSelectDate={onSelectCalendarDate} />
      </div>
    </motion.div>
  );
}

function DashboardMistakeAlert({ trades, onOpen }) {
  const detector = getMistakeDetectorStats(trades);
  if (!detector.mainIssue) return null;
  return (
    <button onClick={onOpen} className="mt-8 w-full rounded-2xl border border-red-500/35 bg-gradient-to-r from-red-950/45 via-black to-fuchsia-950/25 p-5 text-left shadow-[0_18px_45px_rgba(239,68,68,0.10)] transition hover:border-red-400/75 hover:shadow-[0_0_28px_rgba(239,68,68,0.18)]">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-xs font-black uppercase tracking-widest text-red-300">Main Mistake Warning</div>
          <div className="mt-2 text-2xl font-black text-white">{translateDetectorText(detector.mainIssue.title)}</div>
          <div className="mt-1 text-sm font-bold text-zinc-400">{translateDetectorText(detector.mainRoot?.title || detector.mainIssue.type)} · {detector.confidence}% confidence · {formatMoney(detector.affectedPnl)} lost P&L</div>
        </div>
        <span className="rounded-xl border border-red-500/35 bg-red-500/15 px-4 py-3 text-sm font-black text-red-300">Open Mistake Analysis →</span>
      </div>
    </button>
  );
}

function QuickInsights({ insights }) {
  const styles = {
    emerald: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
    fuchsia: "border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300",
    amber: "border-amber-500/30 bg-amber-500/10 text-amber-300",
    red: "border-red-500/30 bg-red-500/10 text-red-300",
  };
  return (
    <section className="mt-8 rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-5 shadow-[0_18px_45px_rgba(217,70,239,0.10)]">
      <div className="mb-4 flex items-center justify-between">
        <SectionTitle title="Quick Insights" icon={<Target size={18} />} />
        <span className="rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black text-fuchsia-300">Auto analysis</span>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {insights.map((item) => (
          <div key={item.title} className={`relative overflow-hidden rounded-2xl border p-4 ${styles[item.tone] || styles.fuchsia}`}>
            <div className="absolute right-0 top-0 h-16 w-16 rounded-bl-3xl bg-white/5" />
            <div className="relative z-10 flex items-center justify-between">
              <div className="text-[10px] font-black uppercase tracking-widest text-zinc-400">{item.title}</div>
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-black/25 text-sm font-black">{item.icon}</div>
            </div>
            <div className="relative z-10 mt-4 truncate text-xl font-black text-white">{item.value}</div>
            <div className="relative z-10 mt-1 text-xs font-bold text-zinc-400">{item.detail}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function TradingActivityPanel({ trades, selectedDate, onSelectDate }) {
  const [hoveredDay, setHoveredDay] = useState(null);
  const grouped = groupTradesByDate(trades);
  const days = getLastTradingDays(20).map((day) => ({ ...day, summary: summarizeTrades(grouped[day.key] || []) }));
  const activeDays = days.filter((day) => day.summary.count > 0).length;
  const winDays = days.filter((day) => day.summary.pnl > 0).length;
  const lossDays = days.filter((day) => day.summary.pnl < 0).length;
  const breakEvenDays = days.filter((day) => day.summary.count > 0 && day.summary.pnl === 0).length;

  return (
    <div className="dashboard-activity-card light-card relative flex h-full min-h-0 flex-col overflow-visible rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-5 shadow-[0_20px_55px_rgba(217,70,239,0.10)]">
      <div className="relative z-10 flex items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/15 text-fuchsia-300">
            <Calendar size={22} />
          </div>
          <div>
            <h2 className="text-2xl font-black">Trading Activity</h2>
            <p className="text-sm text-zinc-400">Click a day to open it in Calendar</p>
          </div>
        </div>
        <div className="flex flex-wrap justify-end gap-3 text-[11px] text-zinc-400">
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full border border-white/10 bg-zinc-900" />No trades</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" />Win</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-500" />Loss</span>
          <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" />BE</span>
        </div>
      </div>

      <div className="relative z-10 mt-4 rounded-2xl border border-fuchsia-500/18 bg-black/40 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
        <div className="mb-4 grid grid-cols-5 gap-3 text-center text-xs font-black">
          {["MON", "TUE", "WED", "THU", "FRI"].map((day) => (
            <div key={day} className="rounded-xl border border-fuchsia-500/25 bg-gradient-to-br from-fuchsia-950/45 via-black to-black py-2 text-fuchsia-300 shadow-[0_0_14px_rgba(217,70,239,0.10)]">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-5 gap-3">
          {days.map((day) => {
            const hasTrade = day.summary.count > 0;
            const isWin = day.summary.pnl > 0;
            const isBreakEven = day.summary.pnl === 0;
            const dayClass = hasTrade ? (isWin ? "activity-day-win" : isBreakEven ? "activity-day-breakeven" : "activity-day-loss") : "activity-day-empty";
            const selectedClass = selectedDate === day.key ? "activity-day-selected ring-2 ring-fuchsia-500 ring-offset-2 ring-offset-black" : "";
            const tooltipDate = new Date(`${day.key}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

            return (
              <button
                key={day.key}
                type="button"
                onClick={() => onSelectDate?.(day.key)}
                onMouseEnter={() => setHoveredDay(day)}
                onMouseLeave={() => setHoveredDay(null)}
                className={`activity-day-cell group relative h-14 overflow-visible rounded-xl border transition-all duration-300 hover:scale-110 ${dayClass} ${selectedClass} cursor-pointer`}
              >
                {hoveredDay?.key === day.key && (
                  <div className="light-tooltip pointer-events-none absolute bottom-[4.2rem] left-1/2 z-50 w-48 -translate-x-1/2 rounded-xl border border-white/15 bg-[#070707] p-4 text-left shadow-[0_18px_55px_rgba(0,0,0,0.95)] ring-1 ring-fuchsia-500/20">
                    <div className="flex items-center gap-2 text-sm font-black text-white">
                      <Calendar size={15} className="text-fuchsia-300" />
                      {tooltipDate}
                    </div>
                    <div className="mt-3 flex items-center gap-2 text-sm text-zinc-300">
                      <span className="text-zinc-500">-</span>
                      {day.summary.count} trade{day.summary.count === 1 ? "" : "s"}
                    </div>
                    <div className={`mt-3 w-fit rounded-lg border px-3 py-2 text-sm font-black ${hasTrade ? getPnlPillClass(day.summary.pnl) : "border-fuchsia-500/18 bg-black text-zinc-400"}`}>
                      {hasTrade ? `${getPnlArrow(day.summary.pnl)} ` : ""}{formatMoney(day.summary.pnl)}
                    </div>
                    <div className="absolute -bottom-2 left-1/2 h-4 w-4 -translate-x-1/2 rotate-45 border-b border-r border-white/15 bg-[#070707]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative z-10 mt-auto border-t border-white/10 pt-5">
        <div className="grid grid-cols-2 gap-3">
          <ActivityStat tone="fuchsia" title="ACTIVE" value={activeDays} subtitle="sessions" icon="●" />
          <ActivityStat tone="emerald" title="WINS" value={winDays} subtitle="profitable" icon="↗" />
          <ActivityStat tone="red" title="LOSSES" value={lossDays} subtitle="unprofitable" icon="↘" />
          <ActivityStat tone="amber" title="BE" value={breakEvenDays} subtitle="neutral" icon="—" />
        </div>
      </div>
    </div>
  );
}

function ActivityStat({ tone, title, value, subtitle, icon }) {
  const styles = {
    fuchsia: { card: "border-fuchsia-500/45 bg-gradient-to-br from-fuchsia-950/35 via-black to-black text-fuchsia-300", icon: "bg-fuchsia-500/20 text-fuchsia-300", value: "text-fuchsia-300" },
    emerald: { card: "border-emerald-500/45 bg-gradient-to-br from-emerald-950/35 via-black to-black text-emerald-300", icon: "bg-emerald-500/20 text-emerald-300", value: "text-emerald-300" },
    red: { card: "border-red-500/45 bg-gradient-to-br from-red-950/35 via-black to-black text-red-300", icon: "bg-red-500/20 text-red-300", value: "text-red-300" },
    amber: { card: "border-amber-500/45 bg-gradient-to-br from-amber-950/35 via-black to-black text-amber-300", icon: "bg-amber-500/20 text-amber-300", value: "text-amber-300" },
  };
  const s = styles[tone] || styles.fuchsia;
  return (
    <div className={`activity-stat-${tone} group relative min-h-[118px] overflow-hidden rounded-2xl border p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-fuchsia-400/55 hover:shadow-[0_0_22px_rgba(217,70,239,0.16)] ${s.card}`}>
      <div className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full bg-white/5 blur-xl" />
      <div className="relative z-10 flex items-center justify-between gap-2">
        <div className="min-w-0 text-[11px] font-black uppercase tracking-wider text-zinc-400">{title}</div>
        <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-sm font-black ${s.icon}`}>{icon}</div>
      </div>
      <div className={`relative z-10 mt-4 text-4xl font-black leading-none ${s.value}`}>{value}</div>
      <div className="relative z-10 mt-2 text-xs font-bold text-zinc-400">{subtitle}</div>
    </div>
  );
}

function PerformanceOverviewChart({ mode, trades, curve, stats }) {
  const chartData = useMemo(() => {
    if (mode === "WinRate") {
      let total = 0;
      let wins = 0;
      return [...trades].reverse().map((trade) => {
        total += 1;
        if (Number(trade.pnl) > 0) wins += 1;
        return { date: trade.date, value: total ? (wins / total) * 100 : 0 };
      });
    }
    if (mode === "DailyP&L") {
      return Object.entries(groupTradesByDate(trades))
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([date, dayTrades]) => ({ date, value: summarizeTrades(dayTrades).pnl }));
    }
    return curve.map((point) => ({ date: point.date, value: point.pnl }));
  }, [mode, trades, curve]);

  const latestValue = chartData.length ? chartData[chartData.length - 1].value : 0;
  const isWinRate = mode === "WinRate";
  const isDaily = mode === "DailyP&L";
  const headline = isWinRate ? `${stats.winRate.toFixed(1)}%` : isDaily ? formatMoney(latestValue) : formatMoney(stats.totalPnl);
  const subtitle = isWinRate ? "Current cumulative win rate" : isDaily ? "Daily profit / loss by trading day" : "Current cumulative equity curve";
  const accent = isWinRate ? "text-fuchsia-400" : isDaily ? "text-amber-400" : "text-emerald-400";
  const stroke = isWinRate ? "#d946ef" : isDaily ? "#f59e0b" : "#22c55e";
  const border = isWinRate ? "border-fuchsia-500/30 bg-fuchsia-950/15" : isDaily ? "border-amber-500/30 bg-amber-950/15" : "border-emerald-500/30 bg-emerald-950/15";

  return (
    <div className="relative z-10 mt-5">
      <div className={`dashboard-chart-summary relative mb-5 overflow-hidden rounded-2xl border p-5 ${border}`}>
        <div className="pointer-events-none absolute right-0 top-0 h-24 w-24 rounded-bl-3xl bg-white/5" />
        <div className="relative z-10 text-xs font-black uppercase tracking-widest text-zinc-400">{mode}</div>
        <div className={`relative z-10 mt-2 text-5xl font-black ${accent}`}>{headline}</div>
        <div className="relative z-10 mt-2 text-sm text-zinc-400">{subtitle}</div>
      </div>
      <div className="dashboard-chart-area h-80 rounded-2xl border border-white/10 bg-black/25 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 16, right: 18, left: 8, bottom: 6 }}>
            <CartesianGrid strokeDasharray="4 6" stroke="rgba(148,163,184,0.16)" vertical={false} />
            <XAxis dataKey="date" stroke="#94a3b8" tickLine={false} axisLine={{ stroke: "rgba(168,85,247,0.25)" }} />
            <YAxis stroke="#94a3b8" tickLine={false} axisLine={{ stroke: "rgba(168,85,247,0.25)" }} tickFormatter={(value) => (isWinRate ? `${value}%` : `$${value}`)} />
            <Tooltip contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }} formatter={(value) => [isWinRate ? `${Number(value).toFixed(1)}%` : formatMoney(value), mode]} />
            <Line type="monotone" dataKey="value" stroke={stroke} strokeWidth={4} dot={{ r: 5, fill: stroke, stroke: "#ffffff", strokeWidth: 2 }} activeDot={{ r: 8, fill: "#d946ef", stroke: "#ffffff", strokeWidth: 3 }} />
            <Line type="monotone" dataKey="value" stroke="#d946ef" strokeWidth={2} dot={false} opacity={0.22} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function PerformanceScorePanel({ stats }) {
  const [hoveredMetric, setHoveredMetric] = useState(null);
  const score = Math.min(100, Math.max(0, Number(stats.score || 0)));
  const center = { x: 140, y: 138 };
  const baseMetrics = stats.metrics || {};
  const metricOrder = [
    { key: "winRate", x: 140, y: 34, anchor: "middle" },
    { key: "profitFactor", x: 214, y: 76, anchor: "start" },
    { key: "avgWinLoss", x: 214, y: 160, anchor: "start" },
    { key: "recoveryFactor", x: 140, y: 202, anchor: "middle" },
    { key: "maxDrawdown", x: 66, y: 160, anchor: "end" },
    { key: "consistency", x: 66, y: 76, anchor: "end" },
  ];

  const chartPoints = metricOrder.map((point) => {
    const metric = baseMetrics[point.key] || { label: point.key, description: "", actual: "—", score: 0 };
    const scale = Math.max(0.12, Number(metric.score || 0) / 100);
    return {
      ...point,
      px: center.x + (point.x - center.x) * scale,
      py: center.y + (point.y - center.y) * scale,
      metric,
    };
  });

  const radarPoints = chartPoints.map((point) => `${point.px},${point.py}`).join(" ");
  const hovered = hoveredMetric ? chartPoints.find((point) => point.key === hoveredMetric) : null;

  return (
    <div className="dashboard-score-card light-card relative overflow-hidden rounded-2xl border border-fuchsia-500/25 bg-gradient-to-br from-[#12081b] via-black to-[#050307] p-6 shadow-[0_20px_55px_rgba(16,185,129,0.10)]">
      <div className="pointer-events-none absolute right-0 top-0 h-40 w-40 rounded-bl-[5rem] bg-emerald-500/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-0 h-36 w-36 rounded-tr-[4rem] bg-fuchsia-500/8 blur-3xl" />

      <div className="relative z-10 flex items-start gap-4">
        <div className="dashboard-section-icon flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/15 text-fuchsia-300 shadow-[0_0_18px_rgba(217,70,239,0.25)]">
          <span className="text-2xl font-black">ⓘ</span>
        </div>
        <div>
          <h2 className="text-2xl font-black">Performance <span className="text-zinc-300">Score</span></h2>
          <p className="text-sm text-zinc-400">Your trading metrics</p>
        </div>
      </div>

      <div className="dashboard-radar-card light-card-soft relative z-10 mt-5 overflow-hidden rounded-2xl border border-white/10 bg-black/35 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
        {hovered && (
          <div className="light-tooltip pointer-events-none absolute left-6 top-7 z-50 w-64 rounded-xl border border-white/20 bg-[#020202] p-4 shadow-[0_18px_55px_rgba(0,0,0,0.95)] ring-1 ring-black">
            <div className="text-lg font-black text-white">{hovered.metric.label}</div>
            <div className="mt-1 text-sm font-medium text-zinc-300">{hovered.metric.description}</div>
            <div className="mt-3 border-t border-white/10 pt-3">
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Actual</span>
                <span className="font-black text-white">{hovered.metric.actual}</span>
              </div>
              <div className="mt-2 flex justify-between text-sm">
                <span className="text-zinc-400">Score</span>
                <span className="font-black text-emerald-400">{Number(hovered.metric.score || 0).toFixed(0)} / 100</span>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-center">
          <svg width="290" height="235" viewBox="0 0 280 235" className="overflow-visible">
            <polygon points="140,34 214,76 214,160 140,202 66,160 66,76" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
            <polygon points="140,60 196,92 196,148 140,180 84,148 84,92" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="1" />
            <polygon points="140,86 177,107 177,139 140,160 103,139 103,107" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="1" />

            {metricOrder.map((point) => (
              <line key={point.key} x1="140" y1="138" x2={point.x} y2={point.y} stroke="rgba(255,255,255,0.18)" />
            ))}

            <polygon points={radarPoints} fill="rgba(34,197,94,0.28)" stroke="#22c55e" strokeWidth="3" />

            {chartPoints.map((point) => (
              <circle
                key={point.key}
                cx={point.px}
                cy={point.py}
                r={hoveredMetric === point.key ? 7 : 5}
                fill="#22c55e"
                stroke="#06150c"
                strokeWidth="2"
                onMouseEnter={() => setHoveredMetric(point.key)}
                onMouseLeave={() => setHoveredMetric(null)}
                className="cursor-pointer transition-all"
              />
            ))}

            {metricOrder.map((point) => {
              const metric = baseMetrics[point.key] || { label: point.key };
              const labelX = point.key === "profitFactor" || point.key === "avgWinLoss" ? point.x + 8 : point.key === "maxDrawdown" || point.key === "consistency" ? 8 : point.x;
              const labelY = point.key === "winRate" ? point.y - 12 : point.key === "recoveryFactor" ? point.y + 18 : point.y + 4;
              const labelAnchor = point.key === "maxDrawdown" || point.key === "consistency" ? "start" : point.anchor;
              return (
                <text
                  key={point.key}
                  x={labelX}
                  y={labelY}
                  textAnchor={labelAnchor}
                  fill={hoveredMetric === point.key ? "#22c55e" : "white"}
                  fontSize="12"
                  fontWeight="800"
                  onMouseEnter={() => setHoveredMetric(point.key)}
                  onMouseLeave={() => setHoveredMetric(null)}
                  className="cursor-pointer"
                >
                  {metric.label}
                </text>
              );
            })}
          </svg>
        </div>
      </div>

      <div className="dashboard-score-summary light-card-soft relative z-10 mt-5 rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-950/25 via-black to-fuchsia-950/10 p-5 shadow-[0_0_24px_rgba(16,185,129,0.08)]">
        <div className="text-sm font-black uppercase tracking-wider text-zinc-400">Your Performance Score</div>
        <div className="mt-4 flex items-center gap-5">
          <div className="text-6xl font-black leading-none text-emerald-500">{score.toFixed(2)}</div>
          <div className="flex-1">
            <div className="h-5 overflow-hidden rounded-full bg-zinc-800 shadow-inner">
              <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-emerald-400 to-fuchsia-400 shadow-[0_0_18px_rgba(16,185,129,0.30)]" style={{ width: `${score}%` }} />
            </div>
            <div className="mt-3 flex justify-between text-xs font-bold text-zinc-400">
              <span>0</span>
              <span>25</span>
              <span>50</span>
              <span>75</span>
              <span>100</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function getCalendarDayVisual(dayStats, isWeekend, selected) {
  const base = "calendar-day calendar-day-simple group relative h-28 rounded-xl border p-3 text-left transition-all duration-200";
  if (dayStats.count > 0 && dayStats.pnl > 0) return `${base} calendar-day-win ${selected ? "calendar-day-selected" : ""}`;
  if (dayStats.count > 0 && dayStats.pnl < 0) return `${base} calendar-day-loss ${selected ? "calendar-day-selected" : ""}`;
  if (dayStats.count > 0 && dayStats.pnl === 0) return `${base} calendar-day-breakeven ${selected ? "calendar-day-selected" : ""}`;
  if (isWeekend) return `${base} calendar-day-weekend ${selected ? "calendar-day-selected" : ""}`;
  return `${base} calendar-day-empty ${selected ? "calendar-day-selected" : ""}`;
}

function CalendarPage({ trades, onAdd, selectedDate, setSelectedDate }) {
  const initialDate = selectedDate ? new Date(`${selectedDate}T00:00:00`) : new Date(2026, 4, 1);
  const [calendarMonth, setCalendarMonth] = useState(new Date(initialDate.getFullYear(), initialDate.getMonth(), 1));
  const [dayModalDate, setDayModalDate] = useState(null);

  useEffect(() => {
    if (!selectedDate) return;
    const nextDate = new Date(`${selectedDate}T00:00:00`);
    if (!Number.isNaN(nextDate.getTime())) setCalendarMonth(new Date(nextDate.getFullYear(), nextDate.getMonth(), 1));
  }, [selectedDate]);

  const year = calendarMonth.getFullYear();
  const monthIndex = calendarMonth.getMonth();
  const cells = getCalendarCells(year, monthIndex);
  const grouped = groupTradesByDate(trades);
  const monthName = calendarMonth.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const monthKey = `${year}-${String(monthIndex + 1).padStart(2, "0")}`;
  const monthStats = summarizeTrades(trades.filter((trade) => getTradeDateKey(trade).startsWith(monthKey)));
  const weekRows = Array.from({ length: 6 }, (_, weekIndex) => cells.slice(weekIndex * 7, weekIndex * 7 + 7));
  const selectedDayTrades = grouped[selectedDate] || [];
  const selectedDayStats = summarizeTrades(selectedDayTrades);
  const activeMonthDays = Object.entries(grouped).filter(([dateKey]) => dateKey.startsWith(monthKey));
  const bestMonthDay = activeMonthDays.map(([dateKey, rows]) => ({ dateKey, ...summarizeTrades(rows) })).sort((a, b) => Number(b.pnl || 0) - Number(a.pnl || 0))[0];
  const worstMonthDay = activeMonthDays.map(([dateKey, rows]) => ({ dateKey, ...summarizeTrades(rows) })).sort((a, b) => Number(a.pnl || 0) - Number(b.pnl || 0))[0];

  function goToday() {
    const today = new Date();
    const todayKey = formatDateKey(today);
    setSelectedDate(todayKey);
    setCalendarMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setDayModalDate(todayKey);
  }

  function openDayDetails(dateKey) {
    setSelectedDate(dateKey);
    setDayModalDate(dateKey);
  }

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="relative -m-4 min-h-screen bg-black p-4 sm:-m-6 sm:p-6 lg:-m-8 lg:p-8">
      <div className="mb-8 flex items-center justify-between gap-4">
        <TopCrumb page="Calendar" />
        <div className="hidden items-center gap-5 lg:flex">
          <button className="flex items-center gap-2 rounded-xl border border-white/10 bg-zinc-950/85 px-4 py-2 text-sm font-black text-white shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
            <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]" />
            v
            <span className="rounded-lg bg-white/10 px-2 py-0.5 text-xs">USD</span>
          </button>
          <button className="text-xl text-zinc-300 hover:text-white">♧</button>
          <button className="text-xl text-zinc-300 hover:text-white">☼</button>
        </div>
      </div>

      <div className="calendar-hero-pro calendar-neon-panel relative overflow-hidden rounded-2xl border border-fuchsia-500/40 bg-gradient-to-r from-fuchsia-950/35 via-black to-red-950/10 p-7 shadow-[0_0_38px_rgba(217,70,239,0.20)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400/75 to-transparent" />
        <div className="relative z-10 flex flex-col gap-6 xl:flex-row xl:items-center xl:justify-between">
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black uppercase tracking-widest text-fuchsia-300">
              <span className="h-2 w-2 rounded-full bg-fuchsia-400 shadow-[0_0_12px_rgba(217,70,239,.85)]" /> Calendar Intelligence
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <button onClick={() => setCalendarMonth(new Date(year, monthIndex - 1, 1))} className="calendar-nav-button flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-black text-zinc-300 shadow-[0_0_14px_rgba(217,70,239,0.10)] transition hover:border-fuchsia-400/70 hover:text-fuchsia-200">
                <ChevronLeft size={20} />
              </button>
              <div className="calendar-title-icon flex h-12 w-12 items-center justify-center rounded-xl border border-fuchsia-500/35 bg-fuchsia-500/18 text-fuchsia-300 shadow-[0_0_18px_rgba(217,70,239,0.18)]">
                <Calendar size={22} />
              </div>
              <div>
                <h1 className="text-3xl font-black tracking-tight text-white xl:text-5xl">{monthName}</h1>
                <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-zinc-400">Track trading days, weekly performance, best/worst days and selected day details in one clean view.</p>
              </div>
              <button onClick={() => setCalendarMonth(new Date(year, monthIndex + 1, 1))} className="calendar-nav-button flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-black text-zinc-300 shadow-[0_0_14px_rgba(217,70,239,0.10)] transition hover:border-fuchsia-400/70 hover:text-fuchsia-200">
                <ChevronRight size={20} />
              </button>
            </div>
          </div>

          <div className="calendar-hero-stats-pro">
            <TopPill label="TRADES:" value={monthStats.count} />
            <TopPill label="P&L:" value={formatMoney(monthStats.pnl)} green={monthStats.pnl >= 0} red={monthStats.pnl < 0} />
            <TopPill label="WIN:" value={`${monthStats.winRate.toFixed(0)}%`} />
            <button onClick={goToday} className="calendar-top-pill rounded-xl border border-white/15 bg-black px-4 py-3 text-sm font-black text-white shadow-[0_0_16px_rgba(217,70,239,0.10)] transition hover:border-fuchsia-400/60">
              ▣ Today
            </button>
          </div>
        </div>
      </div>

      <CalendarMonthSummary
        monthStats={monthStats}
        selectedDate={selectedDate}
        selectedDayStats={selectedDayStats}
        bestMonthDay={bestMonthDay}
        worstMonthDay={worstMonthDay}
      />

      <CalendarGuide />

      <div className="calendar-shell-pro calendar-neon-panel mt-7 overflow-x-auto rounded-2xl border border-white/10 bg-black p-6 shadow-[0_0_34px_rgba(217,70,239,0.10)]">
        <div className="grid min-w-[1120px] grid-cols-[repeat(7,minmax(0,1fr))_170px] gap-3">
          {["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT", "WEEK"].map((day) => (
            <div key={day} className={`calendar-week-header rounded-lg border py-3 text-center text-xs font-black tracking-widest ${day === "SUN" || day === "SAT" || day === "WEEK" ? "calendar-week-header-special border-fuchsia-500/35 bg-fuchsia-500/12 text-fuchsia-300" : "border-white/10 bg-white/5 text-zinc-400"}`}>
              {day}
            </div>
          ))}

          {weekRows.map((week, weekIndex) => {
            const weekTrades = week.filter((cell) => !isWeekendDateKey(cell.key)).flatMap((cell) => grouped[cell.key] || []);
            const weekStats = summarizeTrades(weekTrades);

            return (
              <React.Fragment key={weekIndex}>
                {week.map((cell, dayIndex) => {
                  const dayTrades = grouped[cell.key] || [];
                  const dayStats = summarizeTrades(dayTrades);
                  const isWeekend = dayIndex === 0 || dayIndex === 6;
                  const selected = selectedDate === cell.key;
                  const hasTrade = dayTrades.length > 0;

                  return (
                    <button key={cell.key} onClick={() => openDayDetails(cell.key)} className={`${getCalendarDayVisual(dayStats, isWeekend, selected)} h-[116px] rounded-xl`}>
                      <div className="relative z-10 flex items-start justify-between">
                        <div className={cell.isCurrentMonth ? "calendar-day-number font-black text-white" : "calendar-day-number-muted font-black text-zinc-500"}>{cell.day}</div>
                        {selected && <span className="mt-1 h-2.5 w-2.5 rounded-full bg-fuchsia-400 shadow-[0_0_14px_rgba(217,70,239,0.95)]" />}
                      </div>

                      {hasTrade ? (
                        <div className="absolute bottom-3 left-3 right-3 z-10 flex flex-col items-end gap-2">
                          <div className={dayStats.pnl > 0 ? "w-full rounded-md border border-emerald-500/45 bg-emerald-500/18 px-2 py-1 text-center text-sm font-black text-emerald-300" : dayStats.pnl < 0 ? "w-full rounded-md border border-red-500/45 bg-red-500/18 px-2 py-1 text-center text-sm font-black text-red-300" : "w-full rounded-md border border-amber-500/45 bg-amber-500/18 px-2 py-1 text-center text-sm font-black text-amber-300"}>
                            {formatMoney(dayStats.pnl)}
                          </div>
                          <div className="calendar-trade-count w-full rounded-md bg-white/10 py-1 text-center text-xs font-black text-zinc-300">
                            {dayStats.count} trade{dayStats.count === 1 ? "" : "s"}
                          </div>
                        </div>
                      ) : (
                        <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 text-center text-zinc-600">
                          {isWeekend ? <span className="text-lg opacity-80">🏖️</span> : <span className="calendar-empty-dash text-2xl">–</span>}
                        </div>
                      )}
                    </button>
                  );
                })}

                <div className="calendar-week-summary calendar-week-summary-pro relative h-[116px] overflow-hidden rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/12 p-3 shadow-[0_0_18px_rgba(217,70,239,0.12)]">
                  <div className="absolute right-0 top-0 h-16 w-16 rounded-bl-2xl bg-fuchsia-500/12" />
                  {weekStats.count ? (
                    <div className="relative z-10 flex h-full flex-col items-center justify-center">
                      <div className={weekStats.pnl >= 0 ? "text-lg font-black text-emerald-400" : "text-lg font-black text-red-400"}>{formatMoney(weekStats.pnl)}</div>
                      <div className="calendar-trade-count mt-2 rounded-md bg-white/10 px-3 py-1 text-xs font-black text-zinc-300">
                        {weekStats.count} trade{weekStats.count === 1 ? "" : "s"}
                      </div>
                    </div>
                  ) : (
                    <div className="relative z-10 flex h-full items-center justify-center text-sm font-bold text-zinc-500">No activity</div>
                  )}
                </div>
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <button onClick={() => onAdd(selectedDate)} className="fixed bottom-24 right-8 z-40 flex h-16 w-16 items-center justify-center rounded-full bg-fuchsia-500 text-3xl font-light text-black shadow-[0_0_30px_rgba(217,70,239,0.48)] transition hover:scale-105 hover:bg-fuchsia-400 lg:bottom-10">
        +
      </button>

      {dayModalDate && (
        <CalendarDayDetailsModal
          dateKey={dayModalDate}
          trades={grouped[dayModalDate] || []}
          onClose={() => setDayModalDate(null)}
          onAdd={() => onAdd(dayModalDate)}
        />
      )}
    </motion.div>
  );
}

function CalendarDayDetailsModal({ dateKey, trades = [], onClose, onAdd }) {
  const stats = summarizeTrades(trades);
  const date = new Date(`${dateKey}T00:00:00`);
  const dayNumber = Number.isNaN(date.getTime()) ? "—" : date.getDate();
  const title = Number.isNaN(date.getTime()) ? dateKey : date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  const sortedTrades = [...trades].sort((a, b) => Number(b.createdAt || b.id || 0) - Number(a.createdAt || a.id || 0));
  const resultTone = stats.pnl > 0 ? "win" : stats.pnl < 0 ? "loss" : stats.count ? "be" : "empty";
  const resultLabel = stats.pnl > 0 ? "High Performer" : stats.pnl < 0 ? "Review Needed" : stats.count ? "Break Even Day" : "No Activity";

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.96, y: 12 }} animate={{ opacity: 1, scale: 1, y: 0 }} className="calendar-day-modal-pro w-full max-w-3xl overflow-hidden rounded-2xl border border-white/10 bg-[#050505] shadow-[0_26px_90px_rgba(0,0,0,0.80)]">
        <div className="calendar-day-modal-head flex items-center justify-between gap-4 border-b border-white/10 p-5">
          <div className="flex items-center gap-4">
            <div className={resultTone === "win" ? "calendar-modal-day-badge calendar-modal-day-win" : resultTone === "loss" ? "calendar-modal-day-badge calendar-modal-day-loss" : resultTone === "be" ? "calendar-modal-day-badge calendar-modal-day-be" : "calendar-modal-day-badge calendar-modal-day-empty"}>{dayNumber}</div>
            <div>
              <h2 className="text-2xl font-black text-white">{title}</h2>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-sm font-bold text-zinc-400">
                <span>{stats.count} trade{stats.count === 1 ? "" : "s"}</span>
                <span>•</span>
                <span>{stats.winRate.toFixed(1)}% win</span>
                <span className={resultTone === "win" ? "calendar-modal-status calendar-modal-status-win" : resultTone === "loss" ? "calendar-modal-status calendar-modal-status-loss" : resultTone === "be" ? "calendar-modal-status calendar-modal-status-be" : "calendar-modal-status calendar-modal-status-empty"}>{resultLabel}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="rounded-xl border border-white/10 bg-black px-3 py-2 text-xl font-black text-zinc-400 transition hover:border-fuchsia-500/50 hover:text-white">×</button>
        </div>

        <div className={resultTone === "win" ? "calendar-day-modal-summary calendar-day-modal-summary-win" : resultTone === "loss" ? "calendar-day-modal-summary calendar-day-modal-summary-loss" : resultTone === "be" ? "calendar-day-modal-summary calendar-day-modal-summary-be" : "calendar-day-modal-summary calendar-day-modal-summary-empty"}>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <CalendarModalMetric value={stats.wins} label="Wins" tone="win" />
            <CalendarModalMetric value={stats.losses} label="Losses" tone="loss" />
            <CalendarModalMetric value={`${getPnlArrow(stats.pnl)} ${formatMoney(stats.pnl)}`} label="Total P&L" tone={resultTone} />
          </div>
          <div className="mt-5">
            <div className="mb-2 flex items-center justify-between text-sm font-black text-white"><span>Win Rate</span><span>{stats.winRate.toFixed(1)}%</span></div>
            <div className="h-2.5 overflow-hidden rounded-full bg-zinc-800"><div className={resultTone === "loss" ? "h-full rounded-full bg-gradient-to-r from-red-500 to-red-300" : "h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-300"} style={{ width: `${Math.max(0, Math.min(100, stats.winRate))}%` }} /></div>
          </div>
        </div>

        <div className="p-5">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-xl border border-fuchsia-500/45 bg-black px-4 py-2 text-sm font-black text-white">All Trades</span>
              <span className="rounded-xl border border-white/10 bg-black px-4 py-2 text-sm font-black text-zinc-400">By Time</span>
            </div>
            <button onClick={onAdd} className="rounded-xl border border-fuchsia-500/35 bg-fuchsia-500 px-4 py-2 text-sm font-black text-black shadow-[0_0_18px_rgba(217,70,239,0.24)]">+ Add Trade</button>
          </div>

          <div className="max-h-[340px] space-y-3 overflow-y-auto pr-1">
            {sortedTrades.length ? sortedTrades.map((trade) => <CalendarModalTradeRow key={trade.id} trade={trade} />) : (
              <div className="rounded-2xl border border-dashed border-white/10 bg-black/35 p-8 text-center">
                <div className="text-lg font-black text-white">No trades on this day</div>
                <div className="mt-2 text-sm font-semibold text-zinc-500">Click Add Trade to log a win, loss, or break-even trade for this date.</div>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function CalendarModalMetric({ value, label, tone }) {
  const cls = tone === "win" ? "text-emerald-400" : tone === "loss" ? "text-red-400" : tone === "be" ? "text-amber-400" : "text-fuchsia-300";
  return <div className="text-center"><div className={`text-3xl font-black ${cls}`}>{value}</div><div className="mt-1 text-sm font-bold text-zinc-400">{label}</div></div>;
}

function CalendarModalTradeRow({ trade }) {
  const pnl = Number(trade.pnl || 0);
  const isWin = pnl > 0;
  const tag = normalizeTags(trade)[0] || `result:${getResultFromPnl(pnl).toLowerCase().replaceAll(" ", "-")}`;
  return (
    <div className={isWin ? "calendar-modal-trade-row calendar-modal-trade-win" : pnl < 0 ? "calendar-modal-trade-row calendar-modal-trade-loss" : "calendar-modal-trade-row calendar-modal-trade-be"}>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <span className={trade.direction === "SELL" ? "rounded-full border border-red-500/40 bg-red-500/20 px-3 py-1 text-xs font-black text-red-200" : "rounded-full border border-fuchsia-500/40 bg-fuchsia-500 px-3 py-1 text-xs font-black text-black"}>{trade.direction} {trade.pair}</span>
          <span className="rounded-full border border-white/15 bg-white/8 px-3 py-1 text-xs font-black text-white">{trade.setup || "Manual Trade"}</span>
          <span className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-black text-zinc-300">{trade.session || "—"}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-zinc-400">◷ {trade.createdAt ? new Date(Number(trade.createdAt)).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : "—"}</span>
          <span className={pnl > 0 ? "text-3xl font-black text-emerald-400" : pnl < 0 ? "text-3xl font-black text-red-400" : "text-3xl font-black text-amber-400"}>{getPnlArrow(pnl)} {formatMoney(pnl)}</span>
        </div>
      </div>
      <div className="mt-4 border-t border-white/10 pt-3">
        <span className="rounded-full border border-white/12 bg-black/35 px-3 py-1 text-xs font-black text-zinc-300">◇ {tag}</span>
      </div>
    </div>
  );
}

function CalendarMonthSummary({ monthStats, selectedDate, selectedDayStats, bestMonthDay, worstMonthDay }) {
  const selectedLabel = selectedDate ? new Date(`${selectedDate}T00:00:00`).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }) : "No date";
  return (
    <section className="calendar-summary-pro mt-7 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
      <CalendarSummaryCard title="Month Result" value={formatMoney(monthStats.pnl)} text={`${monthStats.count} trades this month`} tone={monthStats.pnl >= 0 ? "emerald" : "red"} />
      <CalendarSummaryCard title="Selected Day" value={formatMoney(selectedDayStats.pnl)} text={`${selectedLabel} · ${selectedDayStats.count} trade${selectedDayStats.count === 1 ? "" : "s"}`} tone={selectedDayStats.pnl > 0 ? "emerald" : selectedDayStats.pnl < 0 ? "red" : "amber"} />
      <CalendarSummaryCard title="Best Day" value={bestMonthDay ? formatMoney(bestMonthDay.pnl) : "$0"} text={bestMonthDay ? bestMonthDay.dateKey : "No profitable day yet"} tone="emerald" />
      <CalendarSummaryCard title="Worst Day" value={worstMonthDay ? formatMoney(worstMonthDay.pnl) : "$0"} text={worstMonthDay ? worstMonthDay.dateKey : "No losing day yet"} tone="red" />
    </section>
  );
}

function CalendarSummaryCard({ title, value, text, tone }) {
  const cls = tone === "emerald" ? "calendar-summary-card-pro calendar-summary-good" : tone === "red" ? "calendar-summary-card-pro calendar-summary-bad" : "calendar-summary-card-pro calendar-summary-warn";
  return (
    <div className={cls}>
      <div className="flex items-center justify-between gap-3">
        <div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{title}</div>
        <span className="calendar-summary-dot-pro" />
      </div>
      <div className="mt-3 text-3xl font-black text-white"><AnimatedValue value={value} /></div>
      <div className="mt-2 text-xs font-bold leading-5 text-zinc-400">{text}</div>
    </div>
  );
}

function CalendarGuide() {
  return (
    <section className="calendar-guide-pro mt-7">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <div className="text-xs font-black uppercase tracking-widest text-fuchsia-300">How to read the calendar</div>
          <h3 className="mt-2 text-2xl font-black text-white">Each day tells you the result instantly.</h3>
          <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-zinc-400">Green days are profitable, red days are losing, amber days are break-even, and purple empty days mean no trade or weekend.</p>
        </div>
        <div className="calendar-legend-pro">
          <span><i className="bg-emerald-400" /> Win day</span>
          <span><i className="bg-red-400" /> Loss day</span>
          <span><i className="bg-amber-400" /> Break-even</span>
          <span><i className="bg-fuchsia-400" /> Selected</span>
        </div>
      </div>
    </section>
  );
}

function AddTradeModal({ isEditing, form, setForm, onClose, onSave, account, accountBalance }) {
  const rr = Number(form.risk) ? (Number(form.pnl || 0) / Number(form.risk)).toFixed(2) : "—";
  const screenshots = normalizeScreenshots(form);
  const previewGrade = getTradeGrade(createTradeFromForm(form, 1, account));
  const riskWarnings = getRiskWarnings(form, accountBalance);
  const formErrors = getTradeFormErrors(form);
  const hasFormErrors = Object.keys(formErrors).length > 0;

  function updateField(key, value) {
    setForm({ ...form, [key]: value });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/75 py-8 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-[820px] rounded-xl border border-white/15 bg-zinc-950 p-6 shadow-2xl"
      >
        <div className="flex items-start justify-between">
          <div>
            <h2 className="flex items-center gap-2 text-xl font-black">
              <TrendingUp className="text-fuchsia-400" size={18} />
              {isEditing ? "Edit Trade" : "Add New Trade"}
            </h2>
            <p className="mt-2 text-sm text-zinc-400">Record a new trade to track your performance and analyze your strategy.</p>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X /></button>
        </div>

        <Section title="Trade Basics" icon={<TrendingUp size={17} />}>
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field label="Symbol">
              <Input autoFocus value={form.symbol} onChange={(e) => updateField("symbol", e.target.value.toUpperCase())} placeholder="E.g., MNQ, MES" className={inputPurpleClass("uppercase")} />
              <FieldError text={formErrors.symbol} />
            </Field>
            <Field label="Trade Type">
              <Select value={form.direction} onChange={(e) => updateField("direction", e.target.value)}><option>Buy</option><option>Sell</option></Select>
            </Field>
            <Field label="Quantity">
              <Input value={form.quantity} onChange={(e) => updateField("quantity", e.target.value)} className={inputPurpleClass()} />
              <FieldError text={formErrors.quantity} />
            </Field>
            <Field label="P&L">
              <MoneyInput value={form.pnl} onChange={(e) => updateField("pnl", e.target.value)} />
              <FieldError text={formErrors.pnl} />
            </Field>
            <Field label="Risk">
              <MoneyInput value={form.risk} onChange={(e) => updateField("risk", e.target.value)} />
              <FieldError text={formErrors.risk} />
            </Field>
            <Field label="R:R Ratio">
              <Input disabled value={rr === "NaN" ? "—" : `${rr}R`} className="border-white/10 bg-zinc-900" />
            </Field>
            <Field label="Trade Grade">
              <Input disabled value={previewGrade} className="border-white/10 bg-zinc-900" />
            </Field>
            <div>
              <DateFilterField label="Trade Date" value={form.date} onChange={(value) => updateField("date", value)} />
              <FieldError text={formErrors.date} />
            </div>
            <Field label="Trading Session">
              <Select value={form.session} onChange={(e) => updateField("session", e.target.value)}>
                <option value="Select trading session">Select trading session</option>
                {TRADING_SESSIONS.map((session) => <option key={session} value={session}>{session}</option>)}
              </Select>
              <FieldError text={formErrors.session} />
            </Field>
          </div>
          {riskWarnings.length > 0 && (
            <div className="mt-5 space-y-2">
              {riskWarnings.map((warning) => (
                <div key={warning.title} className={warning.tone === "red" ? "rounded-xl border border-red-500/35 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-300" : warning.tone === "amber" ? "rounded-xl border border-amber-500/35 bg-amber-500/10 px-4 py-3 text-sm font-bold text-amber-300" : "rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-4 py-3 text-sm font-bold text-emerald-300"}>
                  <span className="font-black">{warning.title}:</span> {warning.text}
                </div>
              ))}
            </div>
          )}
        </Section>

        <div className="trade-context-modern mt-6 overflow-visible rounded-[1.6rem] border border-fuchsia-500/30 bg-gradient-to-br from-[#09030d] via-black to-[#050505] p-6 shadow-[0_0_30px_rgba(217,70,239,0.10)]">
          <div className="mb-6 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-fuchsia-500/35 bg-fuchsia-500/12 text-fuchsia-300 shadow-[0_0_16px_rgba(217,70,239,0.18)]"><Target size={18} /></span>
              <div>
                <h3 className="text-xl font-black text-white">Strategy & Trade Context</h3>
                <p className="mt-1 text-xs font-bold text-zinc-500">Clean selection fields for setup, mindset and execution quality.</p>
              </div>
            </div>
            <span className="hidden rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-[11px] font-black uppercase tracking-wider text-fuchsia-300 sm:inline-flex">Context</span>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="trade-context-card md:col-span-2">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Field label="Strategy">
                  <Select value={form.strategy} onChange={(e) => updateField("strategy", e.target.value)}>
                    <option>Select strategy</option>
                    <option>Liquidity Sweep</option>
                    <option>ICT FVG</option>
                    <option>Order Block</option>
                    <option>Breaker Block</option>
                    <option>Silver Bullet</option>
                  </Select>
                  <FieldError text={formErrors.strategy} />
                </Field>
                <Field label="Account">
                  <Input value={`${account.name} • ${account.currency} ${Number(accountBalance?.currentBalance ?? account.balance).toLocaleString()} • ${account.type}`} disabled className="trade-context-input border-white/10 bg-black/45 text-zinc-400" />
                </Field>
              </div>
            </div>

            <div className="trade-context-card">
              <Field label="Result">
                <div className={getResultTone(getResultFromPnl(form.pnl)) === "emerald" ? "trade-context-result border-emerald-500/35 bg-emerald-500/10 text-emerald-300" : getResultTone(getResultFromPnl(form.pnl)) === "red" ? "trade-context-result border-red-500/35 bg-red-500/10 text-red-300" : "trade-context-result border-amber-500/35 bg-amber-500/10 text-amber-300"}>
                  {getResultFromPnl(form.pnl)} <span className="ml-2 text-xs font-bold text-zinc-500">auto by P&L</span>
                </div>
              </Field>
            </div>

            <div className="trade-context-card">
              <Field label="Tags"><Input value={form.tags} onChange={(e) => updateField("tags", e.target.value)} placeholder="A+ Setup, NY AM, FVG" className="trade-context-input border-white/10 bg-black/45 focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" /></Field>
            </div>

            <div className="trade-context-card"><Field label="Emotions"><Select value={form.emotion} onChange={(e) => updateField("emotion", e.target.value)}><option>Calm</option><option>Confident</option><option>Fearful</option><option>Greedy</option><option>FOMO</option><option>Revenge</option></Select></Field></div>
            <div className="trade-context-card"><Field label="Mistake"><Select value={form.mistake} onChange={(e) => updateField("mistake", e.target.value)}><option>None</option><option>Early Entry</option><option>Late Entry</option><option>No Confirmation</option><option>Overtrading</option><option>Emotional Trade</option><option>Bad Risk Management</option><option>Moved Stop Loss</option></Select></Field></div>
            <div className="trade-context-card"><Field label="Entry Timing"><Select value={form.entryTiming} onChange={(e) => updateField("entryTiming", e.target.value)}><option>Early</option><option>On Time</option><option>Late</option></Select></Field></div>
            <div className="trade-context-card"><Field label="Confirmation"><Select value={form.confirmation} onChange={(e) => updateField("confirmation", e.target.value)}><option>Yes</option><option>No</option><option>Partial</option></Select></Field></div>
            <div className="trade-context-card"><Field label="Rule Broken"><Select value={form.ruleBroken} onChange={(e) => updateField("ruleBroken", e.target.value)}><option>None</option><option>Moved SL</option><option>Overrisk</option><option>No confirmation</option><option>Chased price</option><option>Revenge trade</option></Select></Field></div>
            <div className="trade-context-card"><Field label="Market Condition"><Select value={form.marketCondition} onChange={(e) => updateField("marketCondition", e.target.value)}><option>Trending</option><option>Ranging</option><option>Choppy</option><option>News</option><option>Low Volume</option></Select></Field></div>
            <div className="trade-context-card md:col-span-2"><Field label="Setup Quality"><Select value={form.setupQuality} onChange={(e) => updateField("setupQuality", e.target.value)}><option>A</option><option>B</option><option>C</option><option>D</option></Select></Field></div>
          </div>
        </div>

        <Section title={`Screenshots (${screenshots.length}/${MAX_SCREENSHOTS})`} icon={<Camera size={17} />}>
          <div className="rounded-xl border border-dashed border-white/20 bg-black p-5 text-center">
            {screenshots.length ? (
              <div className="grid grid-cols-2 gap-2">
                {screenshots.map((img, index) => (
                  <div key={index} className="relative">
                    <img src={img} alt="Uploaded screenshot" className="h-32 w-full rounded object-cover" />
                    <button type="button" onClick={() => updateField("screenshots", screenshots.filter((_, i) => i !== index))} className="absolute right-1 top-1 rounded bg-black/70 px-2 py-1 text-xs text-white">X</button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-zinc-400"><Camera className="mx-auto mb-3" /><div>No screenshot uploaded yet</div><div className="mt-1 text-xs">Upload chart screenshots or paste from clipboard</div></div>
            )}
            <Input type="file" accept="image/*" multiple disabled={screenshots.length >= MAX_SCREENSHOTS} onChange={(event) => uploadScreenshotsForTrade(event, form, setForm)} className="mt-4 cursor-pointer border-white/15 bg-black text-white file:mr-4 file:rounded-md file:border-0 file:bg-fuchsia-500 file:px-4 file:py-2 file:text-black" />
          </div>
        </Section>

        <Section title="Notes" icon={<BookOpen size={17} />}>
          <Textarea rows={5} value={form.notes} onChange={(e) => updateField("notes", e.target.value)} placeholder="Market conditions, rationale, lessons learned..." className="border-white/15 bg-black focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
        </Section>

        <Section title="Trade Review" icon={<ListChecks size={17} />}>
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field label="What went well?"><Textarea rows={3} value={form.whatWentWell} onChange={(e) => updateField("whatWentWell", e.target.value)} placeholder="Good entry, patience, clean confirmation..." className="border-white/15 bg-black" /></Field>
            <Field label="What went wrong?"><Textarea rows={3} value={form.whatWentWrong} onChange={(e) => updateField("whatWentWrong", e.target.value)} placeholder="Early entry, moved SL, emotional decision..." className="border-white/15 bg-black" /></Field>
            <Field label="Rule Followed"><Select value={form.ruleFollowed} onChange={(e) => updateField("ruleFollowed", e.target.value)}><option>Yes</option><option>No</option><option>Partial</option></Select></Field>
            <Field label="Entry Quality"><Select value={form.entryQuality} onChange={(e) => updateField("entryQuality", e.target.value)}><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></Select></Field>
            <Field label="Exit Quality"><Select value={form.exitQuality} onChange={(e) => updateField("exitQuality", e.target.value)}><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></Select></Field>
          </div>
        </Section>

        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-5">
          <Button variant="ghost" onClick={onClose} className="text-white hover:bg-white/10">Cancel</Button>
          <Button onClick={onSave} disabled={hasFormErrors} className="bg-fuchsia-500 text-black hover:bg-fuchsia-400 disabled:cursor-not-allowed disabled:opacity-40"><Plus size={16} /> {isEditing ? "Update Trade" : "Save Trade"}</Button>
        </div>
      </motion.div>
    </div>
  );
}

function getTradeFormErrors(form) {
  const errors = {};
  if (!String(form.symbol || "").trim()) errors.symbol = "Symbol აუცილებელია.";
  if (!form.date) errors.date = "Trade Date აუცილებელია.";
  if (!form.session || String(form.session).startsWith("Select")) errors.session = "Trading Session აირჩიე.";
  if (!form.strategy || String(form.strategy).startsWith("Select")) errors.strategy = "Strategy აირჩიე.";
  if (!form.quantity || Number.isNaN(Number(form.quantity)) || Number(form.quantity) <= 0) errors.quantity = "Quantity უნდა იყოს 0-ზე მეტი.";
  if (form.pnl === "" || Number.isNaN(Number(form.pnl))) errors.pnl = "P&L სწორად შეიყვანე.";
  if (form.risk === "" || Number.isNaN(Number(form.risk)) || Number(form.risk) < 0) errors.risk = "Risk არ უნდა იყოს უარყოფითი.";
  return errors;
}

function FieldError({ text }) {
  if (!text) return null;
  return <div className="mt-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs font-black text-red-300">⚠ {text}</div>;
}

function ImportPreviewModal({ preview, onConfirm, onClose }) {
  const validCount = preview?.trades?.length || 0;
  const duplicateCount = preview?.duplicates?.length || 0;
  const invalidCount = preview?.invalidRows?.length || 0;
  const totalPnl = (preview?.trades || []).reduce((sum, trade) => sum + Number(trade.pnl || 0), 0);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="max-h-[90vh] w-full max-w-[860px] overflow-y-auto rounded-2xl border border-fuchsia-500/35 bg-black p-6 shadow-[0_22px_70px_rgba(0,0,0,0.75)]">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="flex items-center gap-3 text-2xl font-black"><Upload className="text-fuchsia-400" size={22} /> Import Preview</h2>
            <p className="mt-2 text-sm text-zinc-400">{preview.filename} · Review trades before adding them to your journal.</p>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X /></button>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard title="Valid Trades" value={validCount} green />
          <StatCard title="Total P&L" value={formatMoney(totalPnl)} green={totalPnl >= 0} gold={totalPnl === 0} />
          <StatCard title="Duplicates" value={duplicateCount} gold />
          <StatCard title="Invalid Rows" value={invalidCount} gold />
        </div>

        <div className="mt-6 rounded-2xl border border-fuchsia-500/20 bg-zinc-950/70 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-black text-white">Trades to import</h3>
            <span className="rounded-full border border-emerald-500/25 bg-emerald-500/10 px-3 py-1 text-xs font-black text-emerald-300">{validCount} ready</span>
          </div>
          {validCount ? (
            <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
              {preview.trades.map((trade) => (
                <div key={trade.id} className="grid grid-cols-[90px_90px_1fr_90px_110px] items-center gap-3 rounded-xl border border-white/10 bg-black p-3 text-sm">
                  <span className="font-black text-white">{trade.pair}</span>
                  <span className={`w-fit rounded-full border px-2 py-1 text-xs font-black ${getTradeDirectionClass(trade.direction)}`}>{trade.direction}</span>
                  <span className="truncate text-zinc-400">{trade.date} · {trade.session} · {trade.setup}</span>
                  <span className="text-zinc-400">Qty {trade.quantity}</span>
                  <span className={`text-right font-black ${getPnlToneClass(trade.pnl)}`}>{getPnlArrow(trade.pnl)} {formatMoney(trade.pnl)}</span>
                </div>
              ))}
            </div>
          ) : <div className="rounded-xl border border-dashed border-white/10 bg-black p-8 text-center text-zinc-500">No valid trades found in this CSV.</div>}
        </div>

        {(duplicateCount > 0 || invalidCount > 0) && (
          <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 p-4">
              <div className="font-black text-amber-300">Skipped duplicates</div>
              <div className="mt-2 text-sm text-zinc-400">{duplicateCount ? preview.duplicates.map((item) => `Row ${item.row}`).join(", ") : "None"}</div>
            </div>
            <div className="rounded-2xl border border-red-500/25 bg-red-500/10 p-4">
              <div className="font-black text-red-300">Invalid rows</div>
              <div className="mt-2 max-h-28 overflow-y-auto text-sm text-zinc-400">
                {invalidCount ? preview.invalidRows.map((item) => <div key={item.row}>Row {item.row}: {item.errors.join(", ")}</div>) : "None"}
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-5">
          <Button variant="outline" onClick={onClose} className="border-white/15 bg-black text-white">Cancel</Button>
          <Button onClick={onConfirm} disabled={!validCount} className="bg-fuchsia-500 text-black hover:bg-fuchsia-400 disabled:cursor-not-allowed disabled:opacity-40"><Upload size={16} /> Import {validCount} Trades</Button>
        </div>
      </motion.div>
    </div>
  );
}

function PreTradeRoutineModal({ routine, setRoutine, onClose }) {
  const checkedCount = routineItems.filter((item) => routine.checked?.[item.id]).length;
  const percent = Math.round((checkedCount / routineItems.length) * 100);
  const ready = percent === 100;

  function toggleItem(id) {
    setRoutine({ ...routine, checked: { ...routine.checked, [id]: !routine.checked?.[id] } });
  }

  function resetRoutine() {
    setRoutine({ date: formatDateKey(new Date()), checked: {}, notes: "" });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="max-h-[90vh] w-full max-w-[860px] overflow-y-auto rounded-2xl border border-white/15 bg-black p-6 shadow-2xl">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-emerald-500/40 bg-emerald-500/15 text-emerald-300">✅</div>
            <div>
              <h2 className="text-2xl font-black">Start Your Day</h2>
              <p className="text-sm text-zinc-400">Pre-trade routine checklist before taking any trade.</p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X /></button>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          <DashCard title="ROUTINE STATUS" value={ready ? "READY" : "WAIT"} badge={ready ? "✓ All checked" : "Finish checklist"} tone={ready ? "emerald" : "amber"} icon={ready ? "✓" : "!"} />
          <DashCard title="COMPLETED" value={`${percent}%`} badge={`${checkedCount}/${routineItems.length} items`} tone="fuchsia" icon="%" />
          <DashCard title="TRADE MODE" value={ready ? "ACTIVE" : "LOCKED"} badge={ready ? "Trade with plan" : "No impulse trades"} tone="cyan" icon="⌁" />
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          {routineItems.map((item) => {
            const checked = Boolean(routine.checked?.[item.id]);
            return (
              <button key={item.id} onClick={() => toggleItem(item.id)} className={`group relative overflow-hidden rounded-xl border bg-gradient-to-br p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:shadow-2xl ${checked ? "border-emerald-500/60 from-emerald-950/45 via-emerald-950/10 to-black shadow-emerald-500/10" : "border-white/10 from-zinc-950 via-black to-black hover:border-fuchsia-500/40 hover:shadow-fuchsia-500/10"}`}>
                <div className="flex items-start justify-between">
                  <div className="flex gap-4">
                    <div className={checked ? "flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-300" : "flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 text-zinc-300"}>{item.icon}</div>
                    <div>
                      <div className="font-black text-white">{item.label}</div>
                      <div className="mt-1 text-xs text-zinc-400">{item.detail}</div>
                    </div>
                  </div>
                  <div className={checked ? "flex h-7 w-7 items-center justify-center rounded-full border border-emerald-500 bg-emerald-500 text-xs font-black text-black" : "flex h-7 w-7 items-center justify-center rounded-full border border-white/20 text-xs font-black text-zinc-500"}>
                    {checked ? "✓" : ""}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-6 rounded-xl border border-white/10 bg-zinc-950 p-5">
          <div className="mb-2 text-sm font-black uppercase tracking-wider text-zinc-400">Daily Notes</div>
          <Textarea value={routine.notes} onChange={(e) => setRoutine({ ...routine, notes: e.target.value })} placeholder="Market bias, important levels, news, mental state..." className="min-h-28 border-white/15 bg-black" />
        </div>

        <div className={ready ? "mt-6 rounded-xl border border-emerald-500/40 bg-emerald-950/25 p-5" : "mt-6 rounded-xl border border-amber-500/40 bg-amber-950/20 p-5"}>
          <div className={ready ? "text-2xl font-black text-emerald-400" : "text-2xl font-black text-amber-400"}>{ready ? "Ready to Trade" : "Not Ready Yet"}</div>
          <p className="mt-1 text-sm text-zinc-400">{ready ? "Checklist complete. Follow your plan and risk limits." : "Finish the checklist before opening a position."}</p>
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-5">
          <Button variant="outline" onClick={resetRoutine} className="border-white/15 bg-black text-white">Reset</Button>
          <Button onClick={onClose} className="bg-fuchsia-500 text-black">Save Routine</Button>
        </div>
      </motion.div>
    </div>
  );
}

function getMondayDate(date) {
  const next = new Date(date);
  const day = next.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  next.setDate(next.getDate() + diff);
  next.setHours(0, 0, 0, 0);
  return next;
}

function getWeekGroupKey(dateKey) {
  const date = new Date(`${dateKey}T00:00:00`);
  if (Number.isNaN(date.getTime())) return dateKey || "Unknown";
  const monday = getMondayDate(date);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return `${formatDateKey(monday)}|${monday.toLocaleDateString("en-US", { month: "short", day: "numeric" })} - ${sunday.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`;
}

function getMonthGroupKey(dateKey) {
  const date = new Date(`${dateKey}T00:00:00`);
  if (Number.isNaN(date.getTime())) return dateKey || "Unknown";
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}|${date.toLocaleDateString("en-US", { month: "long" })}`;
}

function getYearGroupKey(dateKey) {
  const date = new Date(`${dateKey}T00:00:00`);
  if (Number.isNaN(date.getTime())) return dateKey || "Unknown";
  return `${date.getFullYear()}|${date.getFullYear()}`;
}

function summarizeGroupedTrades(trades, getKey) {
  return trades.reduce((groups, trade) => {
    const dateKey = getTradeDateKey(trade);
    const rawKey = getKey(dateKey);
    const [sortKey, label = sortKey] = String(rawKey).split("|");
    if (!groups[sortKey]) groups[sortKey] = { label, trades: [] };
    groups[sortKey].trades.push(trade);
    return groups;
  }, {});
}

function bestGroupSummary(groups, fallbackLabel = "No data") {
  const rows = Object.entries(groups).map(([sortKey, group]) => ({ sortKey, label: group.label, ...summarizeTrades(group.trades) }));
  return rows.sort((a, b) => Number(b.pnl || 0) - Number(a.pnl || 0))[0] || { label: fallbackLabel, count: 0, pnl: 0, wins: 0, losses: 0, breakEvens: 0, decisive: 0, winRate: 0, breakEvenRate: 0 };
}

function getBestPerformanceStats(trades = []) {
  const dayGroups = summarizeGroupedTrades(trades, (dateKey) => {
    const date = new Date(`${dateKey}T00:00:00`);
    const label = Number.isNaN(date.getTime()) ? dateKey : date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
    return `${dateKey}|${label}`;
  });
  return {
    day: bestGroupSummary(dayGroups, "No day"),
    week: bestGroupSummary(summarizeGroupedTrades(trades, getWeekGroupKey), "No week"),
    month: bestGroupSummary(summarizeGroupedTrades(trades, getMonthGroupKey), "No month"),
    year: bestGroupSummary(summarizeGroupedTrades(trades, getYearGroupKey), "No year"),
  };
}

function AccountModal({ account, accountBalance, onSaveAccount, onClose }) {
  const [draft, setDraft] = useState(account);
  const types = [
    ["💰", "Live Account", "Real money trading account"],
    ["🎯", "Demo Account", "Practice trading with virtual money"],
    ["📈", "Backtesting", "Historical strategy testing"],
    ["🏆", "Funded Account", "Prop firm or funded trading account"],
    ["📋", "Paper Trading", "Simulated trading environment"],
  ];

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");

  async function saveAccount() {
    setSaving(true);
    setSaveError("");
    const result = await onSaveAccount?.({ ...draft, balance: Number(draft.balance || 0) });
    setSaving(false);

    if (result?.ok === false) {
      setSaveError(result.error?.message || "Could not save account settings.");
      return;
    }

    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-6 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="light-card max-h-[90vh] w-full max-w-[520px] overflow-y-auto rounded-xl border border-white/15 bg-black p-6"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black">Create / Edit Account</h2>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X /></button>
        </div>
        <Field label="Account Type">
          <div className="mt-2 space-y-3">
            {types.map(([emoji, type, desc]) => (
              <button
                key={type}
                type="button"
                onClick={() => setDraft({ ...draft, type })}
                className={`account-type-card flex w-full items-center gap-4 rounded-lg border p-4 text-left ${draft.type === type ? "border-fuchsia-500 bg-fuchsia-950/30" : "border-white/15 bg-zinc-950"}`}
              >
                <span className="text-2xl">{emoji}</span>
                <div>
                  <div className="font-bold">
                    {type}
                    {draft.type === type && <span className="ml-2 rounded-full bg-fuchsia-500 px-2 py-1 text-xs text-black">Selected</span>}
                  </div>
                  <div className="text-xs text-zinc-400">{desc}</div>
                </div>
              </button>
            ))}
          </div>
        </Field>

        <div className="mt-5 grid grid-cols-2 gap-4">
          <Field label="Account Name">
            <Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className="border-white/15 bg-black focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
          </Field>
          <Field label="Currency">
            <Select value={draft.currency} onChange={(e) => setDraft({ ...draft, currency: e.target.value })}>
              <option>USD</option>
              <option>EUR</option>
              <option>GBP</option>
            </Select>
          </Field>
        </div>

        <Field label="Starting / Current Balance">
          <Input value={draft.balance} onChange={(e) => setDraft({ ...draft, balance: e.target.value })} placeholder="E.g., 5200" className="border-white/15 bg-black focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
        </Field>

        <Field label="Description (Optional)">
          <Textarea value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className="border-white/15 bg-zinc-900" />
        </Field>

        <div className="light-card-soft mt-5 rounded-xl border border-white/10 bg-zinc-950 p-4">
          <div className="text-sm font-bold">Account Preview:</div>
          <div className="mt-4 flex items-center justify-between">
            <div>
              <div className="font-bold">🎯 {draft.name || "Account Name"}</div>
              <div className="text-xs text-zinc-400">{draft.type}</div>
            </div>
            <div className="text-right">
              <div className="text-xl font-black">{draft.currency} {Number(draft.balance || 0).toLocaleString()}</div>
              <div className="text-xs text-zinc-400">Base Balance</div>
            </div>
          </div>
          <div className="mt-4 rounded-lg border border-emerald-500/20 bg-emerald-950/20 p-3">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-400">Current balance with trades</span>
              <span className="font-black text-emerald-400">{draft.currency} {Number(Number(draft.balance || 0) + Number(accountBalance?.tradePnl || 0)).toLocaleString()}</span>
            </div>
            <div className="mt-1 flex justify-between text-xs">
              <span className="text-zinc-500">Trade P&L impact</span>
              <span className={Number(accountBalance?.tradePnl || 0) >= 0 ? "text-emerald-400" : "text-red-400"}>{formatMoney(accountBalance?.tradePnl || 0)}</span>
            </div>
          </div>
        </div>

        {saveError && <div className="mt-5 rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-300">{saveError}</div>}

        <div className="mt-6 grid grid-cols-2 gap-3">
          <Button variant="outline" onClick={onClose} className="border-white/15 bg-black text-white">Cancel</Button>
          <Button onClick={saveAccount} disabled={saving} className="bg-fuchsia-500 text-black disabled:cursor-not-allowed disabled:opacity-50"><Plus size={16} /> {saving ? "Saving..." : "Save Account"}</Button>
        </div>
      </motion.div>
    </div>
  );
}

function StatisticsPage({ stats: initialStats, curve: initialCurve, trades = [], onExport }) {
  const [statisticsTab, setStatisticsTab] = useState("Overview");
  const [strategyFilter, setStrategyFilter] = useState("All");
  const [rangeFilter, setRangeFilter] = useState("All time");
  const [refreshTick, setRefreshTick] = useState(0);
  const allTrades = Array.isArray(trades) ? trades : [];
  const strategyOptions = ["All", ...Array.from(new Set(allTrades.map((trade) => trade.setup).filter(Boolean)))];
  const closedTrades = useMemo(() => {
    const today = new Date();
    const days = rangeFilter === "Today" ? 1 : rangeFilter === "7 days" ? 7 : rangeFilter === "30 days" ? 30 : rangeFilter === "90 days" ? 90 : null;
    return allTrades.filter((trade) => {
      const strategyMatch = strategyFilter === "All" || trade.setup === strategyFilter;
      if (!strategyMatch) return false;
      if (!days) return true;
      const date = new Date(`${getTradeDateKey(trade)}T00:00:00`);
      if (Number.isNaN(date.getTime())) return false;
      const start = new Date(today);
      start.setDate(today.getDate() - days + 1);
      start.setHours(0, 0, 0, 0);
      return date >= start && date <= today;
    });
  }, [allTrades, strategyFilter, rangeFilter, refreshTick]);

  const stats = useMemo(() => calculateStatistics(closedTrades), [closedTrades, refreshTick]);
  const curve = useMemo(() => {
    let balance = 0;
    return [...closedTrades].reverse().map((trade) => {
      balance += Number(trade.pnl || 0);
      return { date: trade.date, pnl: balance, winRate: stats.winRate };
    });
  }, [closedTrades, stats.winRate, refreshTick]);

  const profitFactor = Number(stats.profitFactor || 0);
  const expectancy = stats.trades ? stats.totalPnl / stats.trades : 0;
  const wins = closedTrades.filter((trade) => Number(trade.pnl || 0) > 0);
  const bestTradeItem = [...closedTrades].sort((a, b) => Number(b.pnl || 0) - Number(a.pnl || 0))[0];
  const smallestWinItem = [...wins].sort((a, b) => Number(a.pnl || 0) - Number(b.pnl || 0))[0];
  const bestTrade = Number(bestTradeItem?.pnl || 0);
  const smallestWin = Number(smallestWinItem?.pnl || 0);
  const bestSession = Object.entries(stats.sessionStats || {}).sort((a, b) => Number(b[1].pnl || 0) - Number(a[1].pnl || 0))[0];
  const bestPerformance = useMemo(() => getBestPerformanceStats(closedTrades), [closedTrades]);
  const pnlValues = closedTrades.map((trade) => Number(trade.pnl || 0));
  const pnlMean = pnlValues.length ? pnlValues.reduce((sum, value) => sum + value, 0) / pnlValues.length : 0;
  const pnlStd = pnlValues.length > 1 ? Math.sqrt(pnlValues.reduce((sum, value) => sum + Math.pow(value - pnlMean, 2), 0) / (pnlValues.length - 1)) : 0;
  const riskAdjusted = pnlStd ? expectancy / pnlStd : expectancy > 0 ? 999 : 0;
  const tabs = ["Overview", "Patterns", "Strategies", "Charts", "Risk"];
  const edgeStatus = stats.trades < 5 ? "Need more data" : stats.totalPnl > 0 && profitFactor >= 1.2 && expectancy > 0 ? "Edge forming" : stats.totalPnl > 0 ? "Profitable, keep refining" : "Needs improvement";
  const edgeTone = edgeStatus === "Edge forming" || edgeStatus === "Profitable, keep refining" ? "emerald" : stats.trades < 5 ? "amber" : "red";
  const riskStatus = stats.maxDrawdownPercent <= 3 ? "Controlled" : stats.maxDrawdownPercent <= 6 ? "Moderate" : "High drawdown";
  const consistencyText = stats.trades < 5 ? "Add more trades before judging performance." : stats.winRate >= 55 && profitFactor >= 1.2 ? "Your stats are showing a positive trading profile." : profitFactor >= 1 ? "You are close. Improve win quality and reduce avoidable losses." : "Focus on reducing loss size and improving setup quality.";

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="statistics-page-pro">
      <TopCrumb page="Statistics" />

      <div className="statistics-hero-pro">
        <div className="relative z-10 grid grid-cols-1 gap-6 xl:grid-cols-[1.15fr_.85fr] xl:items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black uppercase tracking-widest text-fuchsia-300">
              <span className="h-2 w-2 rounded-full bg-fuchsia-400 shadow-[0_0_12px_rgba(217,70,239,.85)]" /> Performance Intelligence
            </div>
            <h1 className="mt-4 text-4xl font-black tracking-tight text-white xl:text-5xl">Statistics that actually explain your trading.</h1>
            <p className="mt-3 max-w-3xl text-sm font-semibold leading-6 text-zinc-400">
              A clean analytics report for P&L, win rate, consistency, strategy performance, risk control and the next area to improve.
            </p>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <StatsFlowStep number="1" title="Measure" text="Track the numbers that matter" />
              <StatsFlowStep number="2" title="Compare" text="Find your best days, sessions and setups" />
              <StatsFlowStep number="3" title="Improve" text="Use the report to trade with more discipline" />
            </div>
          </div>

          <div className="statistics-filter-pro">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Report Filters</div>
                <div className="mt-1 text-lg font-black text-white">Customize the analysis</div>
              </div>
              <span className="rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black text-fuchsia-300">Live</span>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Select value={strategyFilter} onChange={(e) => setStrategyFilter(e.target.value)}>{strategyOptions.map((strategy) => <option key={strategy} value={strategy}>{strategy === "All" ? "All Strategies" : strategy}</option>)}</Select>
              <Select value={rangeFilter} onChange={(e) => setRangeFilter(e.target.value)}><option>Today</option><option>7 days</option><option>30 days</option><option>90 days</option><option>All time</option></Select>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <button onClick={() => { setStrategyFilter("All"); setRangeFilter("All time"); }} className="statistics-filter-btn-pro">Clear</button>
              <button onClick={() => setRefreshTick((tick) => tick + 1)} className="statistics-filter-btn-pro">Refresh</button>
              <button onClick={() => exportTradesToCSV(closedTrades)} className="statistics-filter-btn-pro"><Download size={14} className="inline" /> CSV</button>
            </div>
          </div>
        </div>
      </div>

      <div className="statistics-status-strip-pro">
        <div><span>Strategy</span><b>{strategyFilter === "All" ? "All Strategies" : strategyFilter}</b></div>
        <div><span>Range</span><b>{rangeFilter}</b></div>
        <div><span>Trades Used</span><b>{closedTrades.length}</b></div>
        <div><span>Health</span><b>{edgeStatus}</b></div>
      </div>

      <section className="statistics-command-center-pro mt-7">
        <div className="statistics-command-main-pro">
          <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
            <div>
              <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Analytics Summary</div>
              <h2 className="mt-2 text-3xl font-black text-white">Your trading score is {Math.round(stats.score || 0)}/100</h2>
              <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-zinc-400">{consistencyText}</p>
            </div>
            <div className={edgeTone === "emerald" ? "stats-edge-badge stats-edge-good" : edgeTone === "amber" ? "stats-edge-badge stats-edge-warn" : "stats-edge-badge stats-edge-bad"}>{edgeStatus}</div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatsHeroMetric label="Net P&L" value={formatMoney(stats.totalPnl)} detail="How much money you made or lost from the selected trades." tone={stats.totalPnl >= 0 ? "emerald" : "red"} />
            <StatsHeroMetric label="Win Rate" value={`${stats.winRate.toFixed(1)}%`} detail="How many trades closed in profit compared to losing trades." tone="fuchsia" />
            <StatsHeroMetric label="Profit Factor" value={profitFactor >= 999 ? "Perfect" : profitFactor.toFixed(2)} detail="Above 1.00 means your winners are bigger than your losses overall." tone={profitFactor >= 1.2 ? "emerald" : profitFactor >= 1 ? "amber" : "red"} />
            <StatsHeroMetric label="Expectancy" value={formatMoney(expectancy)} detail="The average amount you can expect to make or lose per trade." tone={expectancy >= 0 ? "emerald" : "red"} />
          </div>
        </div>

        <div className="statistics-command-side-pro">
          <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Plain-English Result</div>
          <div className="mt-4 space-y-3">
            <StatsInsightCard title="System Edge" value={edgeStatus} text="This tells the user whether the strategy is currently working or needs improvement." tone={edgeTone} />
            <StatsInsightCard title="Risk Control" value={riskStatus} text={`Max drawdown is ${stats.maxDrawdownPercent.toFixed(1)}%. Smaller drawdown means the account is more stable.`} tone={riskStatus === "Controlled" ? "emerald" : riskStatus === "Moderate" ? "amber" : "red"} />
            <StatsInsightCard title="Best Session" value={bestSession?.[0] || "No session"} text={`${formatMoney(bestSession?.[1]?.pnl || 0)} net P&L from this session. This shows where performance is strongest.`} tone="fuchsia" />
          </div>
        </div>
      </section>

      <StatsBeginnerGuide />

      <div className="statistics-tabs-pro mt-7">
        {tabs.map((tab) => (
          <button key={tab} onClick={() => setStatisticsTab(tab)} className={statisticsTab === tab ? "statistics-tab-pro statistics-tab-pro-active" : "statistics-tab-pro"}>
            <span className="statistics-tab-icon-pro">{tab === "Overview" ? "▥" : tab === "Patterns" ? "◷" : tab === "Strategies" ? "◈" : tab === "Charts" ? "⌁" : "$"}</span>
            <span>{tab}</span>
          </button>
        ))}
      </div>

      {statisticsTab === "Overview" && (
        <>
          <section className="mt-8 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-black/25 p-5">
            <div className="mb-4 flex items-center justify-between gap-3">
              <SectionTitle title="Core Performance" icon={<BarChart3 size={20} />} />
              <span className="rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black text-fuchsia-300">Main numbers</span>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatisticsMetricCard title="TOTAL P&L" value={formatMoney(stats.totalPnl)} sub="Net result" icon="$" tone={stats.totalPnl >= 0 ? "green" : "red"} />
              <StatisticsMetricCard title="WIN RATE" value={`${stats.winRate.toFixed(1)}%`} sub={`${stats.wins}W/${stats.losses}L`} icon="◎" tone="green" />
              <StatisticsMetricCard title="BREAK EVEN" value={stats.breakEvens || 0} sub={`${(stats.breakEvenRate || 0).toFixed(1)}% BE`} icon="—" tone="amber" />
              <StatisticsMetricCard title="TRADES" value={stats.trades} sub={`${stats.trades} closed`} icon="⌁" tone="white" />
              <StatisticsMetricCard title="AVG WIN" value={formatMoney(stats.avgWin)} sub="Average winner" icon="↗" tone="green" active />
              <StatisticsMetricCard title="AVG LOSS" value={formatMoney(stats.avgLoss)} sub="Average loser" icon="↘" tone="red" />
              <StatisticsMetricCard title="PROFIT FACTOR" value={profitFactor >= 999 ? "999.00" : profitFactor.toFixed(2)} sub={profitFactor >= 999 ? "Perfect" : "Gross P/L"} icon="▣" tone={profitFactor >= 1 ? "green" : "red"} />
              <StatisticsMetricCard title="MAX DRAWDOWN" value={formatMoney(stats.maxDrawdown)} sub={`${stats.maxDrawdownPercent.toFixed(1)}% DD`} icon="↓" tone={stats.maxDrawdownPercent <= 3 ? "green" : stats.maxDrawdownPercent <= 6 ? "amber" : "red"} />
            </div>
          </section>

          <section className="mt-8 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-black/25 p-5">
            <div className="mb-4 flex items-center justify-between gap-3">
              <SectionTitle title="Advanced Analytics" icon={<span className="text-xl">%</span>} />
              <span className="rounded-full border border-emerald-500/25 bg-emerald-500/10 px-3 py-1 text-xs font-black text-emerald-300">Quality metrics</span>
            </div>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
              <AdvancedStatCard title="EXPECTANCY" value={formatMoney(expectancy)} sub="Per trade" tone={expectancy >= 0 ? "green" : "red"} />
              <AdvancedStatCard title="RISK-ADJUSTED" value={riskAdjusted >= 999 ? "Perfect" : riskAdjusted.toFixed(2)} sub="P&L stability" tone="fuchsia" muted />
              <AdvancedStatCard title="BEST TRADE" value={formatMoney(bestTrade)} sub={bestTradeItem?.pair || "No trade"} tone="green" />
              <AdvancedStatCard title="SMALLEST WIN" value={formatMoney(smallestWin)} sub={smallestWinItem?.pair || "No win"} tone="red" />
            </div>
          </section>

          <section className="mt-8 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-black/25 p-5">
            <div className="mb-4 flex items-center justify-between gap-3">
              <SectionTitle title="Best Performance" gold icon={<span className="text-xl">🏆</span>} />
              <span className="rounded-full border border-amber-500/25 bg-amber-500/10 px-3 py-1 text-xs font-black text-amber-300">Best results</span>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5">
              <BestPerformanceCard title="BEST DAY" value={formatMoney(bestPerformance.day.pnl)} detail={bestPerformance.day.label} badge={`${bestPerformance.day.count} trades`} icon="▣" accent="amber" />
              <BestPerformanceCard title="BEST WEEK" value={formatMoney(bestPerformance.week.pnl)} detail={bestPerformance.week.label} badge={`${bestPerformance.week.count} trades`} icon="♛" accent="fuchsia" />
              <BestPerformanceCard title="BEST MONTH" value={formatMoney(bestPerformance.month.pnl)} detail={bestPerformance.month.label} badge={`${bestPerformance.month.count} trades`} icon="↗" accent="blue" />
              <BestPerformanceCard title="BEST YEAR" value={formatMoney(bestPerformance.year.pnl)} detail={bestPerformance.year.label} badge={`${bestPerformance.year.count} trades`} icon="♙" accent="green" />
              <BestPerformanceCard title="BEST SESSION" value={formatMoney(bestSession?.[1]?.pnl || 0)} detail={bestSession?.[0] || "No session"} badge={`${bestSession?.[1]?.count || 0} trades`} icon="☀" accent="cyan" />
            </div>
          </section>

          <section className="mt-8 grid grid-cols-1 gap-8 xl:grid-cols-2">
            <StatisticsPerformanceTimeline curve={curve} stats={stats} />
            <StatisticsWinLossPanel stats={stats} />
          </section>
        </>
      )}

      {statisticsTab === "Patterns" && <StatisticsPatternsView stats={stats} trades={closedTrades} />}
      {statisticsTab === "Strategies" && <StatisticsStrategiesView stats={stats} />}
      {statisticsTab === "Charts" && <StatisticsChartsView stats={stats} curve={curve} trades={closedTrades} />}
      {statisticsTab === "Risk" && <StatisticsRiskView stats={stats} trades={closedTrades} />}
    </motion.div>
  );
}

function StatsFlowStep({ number, title, text }) {
  return (
    <div className="stats-flow-step-pro">
      <div className="stats-flow-number-pro">{number}</div>
      <div>
        <div className="font-black text-white">{title}</div>
        <div className="mt-1 text-xs font-semibold leading-5 text-zinc-400">{text}</div>
      </div>
    </div>
  );
}

function StatsHeroMetric({ label, value, detail, tone }) {
  const cls = tone === "emerald" ? "stats-hero-metric stats-hero-good" : tone === "red" ? "stats-hero-metric stats-hero-bad" : tone === "amber" ? "stats-hero-metric stats-hero-warn" : "stats-hero-metric stats-hero-main";
  return <div className={cls}><div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{label}</div><div className="mt-2 text-2xl font-black text-white"><AnimatedValue value={value} /></div><div className="mt-2 text-xs font-semibold leading-5 text-zinc-400">{detail}</div></div>;
}

function StatsInsightCard({ title, value, text, tone }) {
  const cls = tone === "emerald" ? "stats-insight-card stats-insight-good" : tone === "red" ? "stats-insight-card stats-insight-bad" : tone === "amber" ? "stats-insight-card stats-insight-warn" : "stats-insight-card stats-insight-main";
  return <div className={cls}><div className="flex items-center justify-between gap-3"><div className="text-xs font-black uppercase tracking-widest text-zinc-500">{title}</div><div className="font-black text-white">{value}</div></div><div className="mt-2 text-xs font-semibold leading-5 text-zinc-400">{text}</div></div>;
}

function StatsBeginnerGuide() {
  return (
    <section className="stats-beginner-guide-pro mt-7">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <div className="text-xs font-black uppercase tracking-widest text-fuchsia-300">How to read this page</div>
          <h3 className="mt-2 text-2xl font-black text-white">Start with these 4 numbers. Everything else is deeper detail.</h3>
          <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-zinc-400">The Statistics page is designed like a trading health report: first it shows if you are profitable, then if the system has edge, then where the performance is coming from.</p>
        </div>
        <div className="stats-reading-order-pro">
          <span>1. Net P&L</span>
          <span>2. Win Rate</span>
          <span>3. Profit Factor</span>
          <span>4. Expectancy</span>
        </div>
      </div>
      <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatDefinitionCard title="Net P&L" meaning="Your total money result." good="Green means profitable." bad="Red means losing." />
        <StatDefinitionCard title="Win Rate" meaning="How often your trades win." good="Higher is better." bad="But it still needs good risk/reward." />
        <StatDefinitionCard title="Profit Factor" meaning="Gross wins divided by gross losses." good="Above 1.20 is strong." bad="Below 1.00 means losses are bigger." />
        <StatDefinitionCard title="Expectancy" meaning="Average result per trade." good="Positive means each trade has value." bad="Negative means the system needs fixing." />
      </div>
    </section>
  );
}

function StatDefinitionCard({ title, meaning, good, bad }) {
  return (
    <div className="stat-definition-card-pro">
      <div className="flex items-center justify-between gap-3">
        <div className="text-lg font-black text-white">{title}</div>
        <span className="stats-help-dot-pro">?</span>
      </div>
      <div className="mt-2 text-sm font-semibold leading-6 text-zinc-400">{meaning}</div>
      <div className="mt-4 grid grid-cols-1 gap-2">
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-3 py-2 text-xs font-black text-emerald-300">✓ {good}</div>
        <div className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs font-black text-red-300">! {bad}</div>
      </div>
    </div>
  );
}

function MistakeDetectorPage({ trades = [] }) {
  const [strategyFilter, setStrategyFilter] = useState("All");
  const [rangeFilter, setRangeFilter] = useState("All time");
  const allTrades = Array.isArray(trades) ? trades : [];
  const strategyOptions = ["All", ...Array.from(new Set(allTrades.map((trade) => trade.setup).filter(Boolean)))];
  const filteredTrades = useMemo(() => {
    const today = new Date();
    const days = rangeFilter === "Today" ? 1 : rangeFilter === "7 days" ? 7 : rangeFilter === "30 days" ? 30 : rangeFilter === "90 days" ? 90 : null;
    return allTrades.filter((trade) => {
      const strategyMatch = strategyFilter === "All" || trade.setup === strategyFilter;
      if (!strategyMatch) return false;
      if (!days) return true;
      const date = new Date(`${getTradeDateKey(trade)}T00:00:00`);
      if (Number.isNaN(date.getTime())) return false;
      const start = new Date(today);
      start.setDate(today.getDate() - days + 1);
      start.setHours(0, 0, 0, 0);
      return date >= start && date <= today;
    });
  }, [allTrades, strategyFilter, rangeFilter]);

  const analyzedLosses = filteredTrades.filter((trade) => Number(trade.pnl || 0) < 0).length;

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mistake-page-pro">
      <TopCrumb page="Mistake Detector" />

      <div className="mistake-page-header-pro">
        <div>
          <div className="flex items-center gap-3">
            <span className="mistake-page-icon-pro"><Target size={22} /></span>
            <div>
              <h1 className="text-4xl font-black tracking-tight text-white">Mistake Detector</h1>
              <p className="mt-2 max-w-2xl text-base font-semibold leading-7 text-zinc-400">A clean trading coach report that shows your biggest mistake, the reason behind it, and the rule to follow on your next trade.</p>
            </div>
          </div>
        </div>

        <div className="mistake-filter-card-pro">
          <div className="mb-3 text-xs font-black uppercase tracking-widest text-zinc-500">Report Filters</div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            <Select value={strategyFilter} onChange={(e) => setStrategyFilter(e.target.value)}>{strategyOptions.map((strategy) => <option key={strategy} value={strategy}>{strategy === "All" ? "All Strategies" : strategy}</option>)}</Select>
            <Select value={rangeFilter} onChange={(e) => setRangeFilter(e.target.value)}><option>Today</option><option>7 days</option><option>30 days</option><option>90 days</option><option>All time</option></Select>
            <button onClick={() => { setStrategyFilter("All"); setRangeFilter("All time"); }} className="mistake-clear-btn-pro">Clear</button>
          </div>
        </div>
      </div>

      <div className="mistake-status-strip-pro">
        <div>
          <span className="text-zinc-500">Strategy</span>
          <b>{strategyFilter === "All" ? "All Strategies" : strategyFilter}</b>
        </div>
        <div>
          <span className="text-zinc-500">Range</span>
          <b>{rangeFilter}</b>
        </div>
        <div>
          <span className="text-zinc-500">Analyzed Losses</span>
          <b>{analyzedLosses}</b>
        </div>
        <div>
          <span className="text-zinc-500">Purpose</span>
          <b>Find → Understand → Fix</b>
        </div>
      </div>

      <MistakeDetector trades={filteredTrades} />
    </motion.div>
  );
}

function MistakeDetector({ trades = [] }) {
  const detector = getMistakeDetectorStats(trades);
  const extra = getDetectorEnhancements(trades, detector);
  const [selectedIssueKey, setSelectedIssueKey] = useState(null);
  const selectedIssue = detector.issues.find((issue) => issue.key === selectedIssueKey);
  const main = selectedIssue || detector.mainIssue;
  const selectedRoot = detector.roots.find((root) => root.issues.includes(main?.title)) || detector.mainRoot;
  const selectedFocusPlan = selectedRoot ? buildFocusPlan(selectedRoot.key, main?.title) : detector.focusPlan;
  const selectedAffectedPnl = main ? main.pnl : detector.affectedPnl;
  const topIssues = detector.issues.slice(0, 5);
  const worstSetup = extra.lossGroupsBySetup[0];
  const worstSession = extra.lossGroupsBySession[0];
  const mainProblem = main ? translateDetectorText(main.title) : "No clear mistake yet";
  const rootCause = translateDetectorText(selectedRoot?.title || main?.type || "Not enough data");
  const hasEnoughData = detector.losses.length >= 3;
  const nextRule = selectedFocusPlan[0] || "Log more losing trades with mistake, emotion, timing and notes.";

  return (
    <section className="mistake-detector-clean mt-8 space-y-6">
      <div className="mistake-coach-hero">
        <div className="relative z-10 grid grid-cols-1 gap-6 xl:grid-cols-[1.15fr_.85fr] xl:items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black uppercase tracking-widest text-fuchsia-300">
              <span className="h-2 w-2 rounded-full bg-fuchsia-400 shadow-[0_0_12px_rgba(217,70,239,.85)]" /> AI Trading Coach
            </div>
            <h2 className="mt-4 text-3xl font-black text-white xl:text-5xl">Your mistake report, simplified.</h2>
            <p className="mt-3 max-w-3xl text-sm font-semibold leading-6 text-zinc-400">
              This page explains what is going wrong, why it is happening, how much it costs, and exactly what to do before the next trade.
            </p>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <CoachFlowStep number="1" title="Find" text="Your biggest losing pattern" />
              <CoachFlowStep number="2" title="Understand" text="The root cause and cost" />
              <CoachFlowStep number="3" title="Fix" text="Clear rules for the next trade" />
            </div>
          </div>
          <div className="coach-summary-card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Coach Summary</div>
                <div className="mt-2 text-2xl font-black text-white">{mainProblem}</div>
              </div>
              <span className={extra.severity >= 75 ? "coach-risk-badge coach-risk-high" : extra.severity >= 45 ? "coach-risk-badge coach-risk-medium" : "coach-risk-badge coach-risk-low"}>{extra.severityLabel}</span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <MiniCoachMetric label="Root Cause" value={rootCause} />
              <MiniCoachMetric label="Lost P&L" value={formatMoney(selectedAffectedPnl)} danger />
              <MiniCoachMetric label="Confidence" value={`${detector.confidence}%`} />
              <MiniCoachMetric label="Data Quality" value={`${extra.dataQuality}%`} />
            </div>
            <div className="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4">
              <div className="text-xs font-black uppercase tracking-widest text-emerald-300">Next Trade Rule</div>
              <div className="mt-2 text-sm font-semibold leading-6 text-zinc-300">{nextRule}</div>
            </div>
          </div>
        </div>
      </div>

      {!hasEnoughData && (
        <div className="mistake-help-banner">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-amber-500/30 bg-amber-500/10 text-xl text-amber-300">!</div>
          <div>
            <div className="font-black text-white">Detector will become stronger with more losing trades.</div>
            <div className="mt-1 text-sm font-semibold leading-6 text-zinc-400">For best accuracy, add at least 3 losing trades and fill these fields: Mistake, Emotion, Entry Timing, Rule Broken, Setup Quality, Notes, and Screenshot.</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <ReasonCard label="Main Problem" value={mainProblem} detail={main ? `${main.count} losing trade${main.count === 1 ? "" : "s"} affected` : "Add losing trades to detect patterns"} tone="red" />
        <ReasonCard label="Root Cause" value={rootCause} detail="The main category behind the mistake" tone="amber" />
        <ReasonCard label="Lost P&L" value={formatMoney(selectedAffectedPnl)} detail="Money connected to the selected pattern" tone="red" />
        <ReasonCard label="Most Expensive" value={extra.mostExpensive ? translateDetectorText(extra.mostExpensive.title) : "No data yet"} detail={extra.mostExpensive ? formatMoney(extra.mostExpensive.pnl) : "Needs more history"} tone="fuchsia" />
      </div>

      <div className="mistake-page-divider-pro"><span>Start here</span></div>

      <div className="mistake-guide-panel">
        <div className="mistake-guide-head">
          <div>
            <div className="mistake-eyebrow text-fuchsia-300">How to use this page</div>
            <h3 className="mt-1 text-xl font-black text-white">Read it from left to right: diagnose the problem, then follow the fix plan.</h3>
          </div>
          <span className="mistake-badge-cyan">Simple Guide</span>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
          <GuideMiniCard title="Confidence" text="Shows how often this mistake appears inside your losing trades." />
          <GuideMiniCard title="Risk Level" text="Combines frequency, lost P&L, and how dangerous the mistake is." />
          <GuideMiniCard title="Data Quality" text="Shows how complete your journal data is. More detail means better analysis." />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[.95fr_1.05fr]">
        <div className="mistake-panel-clean">
          <div className="mistake-panel-head">
            <div>
              <div className="mistake-eyebrow text-red-300">Step 1 · Diagnosis</div>
              <h3 className="mt-1 text-2xl font-black text-white">What went wrong?</h3>
              <p className="mt-1 text-sm font-semibold text-zinc-500">Click a mistake below to update the coach plan on the right.</p>
            </div>
            <span className="mistake-badge-red">Problem Map</span>
          </div>

          <div className="mt-5 space-y-3">
            {topIssues.length ? topIssues.map((issue, index) => (
              <IssueSelectorCard
                key={issue.key}
                index={index + 1}
                issue={issue}
                active={main?.key === issue.key}
                losses={detector.losses.length}
                onClick={() => setSelectedIssueKey(issue.key)}
              />
            )) : <EmptyDetectorText text="No losing pattern yet. Add losing trades with mistake, emotion, timing, rule broken and notes." />}
          </div>
        </div>

        <div className="mistake-panel-clean mistake-fix-panel">
          <div className="mistake-panel-head">
            <div>
              <div className="mistake-eyebrow text-emerald-300">Step 2 · Correction</div>
              <h3 className="mt-1 text-2xl font-black text-white">How to fix it?</h3>
              <p className="mt-1 text-sm font-semibold text-zinc-500">Use these as rules before, during and after your next trade.</p>
            </div>
            <span className="mistake-badge-green">Action Plan</span>
          </div>

          <div className="mt-5 rounded-[1.4rem] border border-emerald-500/25 bg-gradient-to-br from-emerald-500/10 via-black/25 to-fuchsia-500/5 p-5">
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Active focus</div>
                <div className="mt-1 text-xl font-black text-white">{mainProblem}</div>
              </div>
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm font-black text-emerald-300">{extra.severityLabel}</div>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <FixStepCard index="Before" text={selectedFocusPlan[0] || "Wait for a complete setup before entry."} />
              <FixStepCard index="During" text={selectedFocusPlan[1] || "Do not change risk after entry."} />
              <FixStepCard index="After" text={selectedFocusPlan[2] || "Review the trade before taking the next setup."} />
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
            <FormulaBox title="Best Conditions" text={extra.winningFormula} tone="emerald" />
            <FormulaBox title="Worst Conditions" text={extra.losingFormula} tone="red" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="mistake-panel-clean">
          <div className="mistake-panel-head">
            <div>
              <div className="mistake-eyebrow text-amber-300">Step 3 · Location</div>
              <h3 className="mt-1 text-lg font-black text-white">Where you lose most</h3>
              <p className="mt-1 text-xs font-semibold text-zinc-500">Shows the setup and session with the highest loss impact.</p>
            </div>
            <span className="mistake-badge-amber">Map</span>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4">
            <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 p-4">
              <div className="text-xs font-black uppercase tracking-widest text-amber-300">Worst Setup</div>
              <div className="mt-3 flex items-center justify-between gap-3">
                <span className="font-black text-white">{worstSetup ? translateDetectorText(worstSetup.name) : "No setup pattern"}</span>
                <span className="font-black text-amber-300">{worstSetup ? formatMoney(worstSetup.pnl) : formatMoney(0)}</span>
              </div>
              <div className="mt-2 text-xs font-bold text-zinc-500">{worstSetup ? `${worstSetup.count} losing trade${worstSetup.count === 1 ? "" : "s"}` : "Needs more data"}</div>
            </div>
            <div className="rounded-2xl border border-cyan-500/25 bg-cyan-500/10 p-4">
              <div className="text-xs font-black uppercase tracking-widest text-cyan-300">Worst Session</div>
              <div className="mt-3 flex items-center justify-between gap-3">
                <span className="font-black text-white">{worstSession ? translateDetectorText(worstSession.name) : "No session pattern"}</span>
                <span className="font-black text-cyan-300">{worstSession ? formatMoney(worstSession.pnl) : formatMoney(0)}</span>
              </div>
              <div className="mt-2 text-xs font-bold text-zinc-500">{worstSession ? `${worstSession.count} losing trade${worstSession.count === 1 ? "" : "s"}` : "Needs more data"}</div>
            </div>
          </div>
        </div>

        <div className="mistake-panel-clean">
          <div className="mistake-panel-head">
            <div>
              <div className="mistake-eyebrow text-red-300">Step 4 · Behavior</div>
              <h3 className="mt-1 text-lg font-black text-white">Danger Habits</h3>
              <p className="mt-1 text-xs font-semibold text-zinc-500">Warns you about revenge trading, overtrading and loss streaks.</p>
            </div>
            <span className="mistake-badge-red">Risk</span>
          </div>
          <div className="mt-4 space-y-3">
            {extra.antiPatterns.length ? extra.antiPatterns.slice(0, 3).map((warning) => <WarningCleanCard key={warning.title} warning={warning} />) : <EmptyDetectorText text="No dangerous habit detected yet. Keep logging trades to monitor behavior." />}
          </div>
        </div>

        <div className="mistake-panel-clean">
          <div className="mistake-panel-head">
            <div>
              <div className="mistake-eyebrow text-cyan-300">Step 5 · Accuracy</div>
              <h3 className="mt-1 text-lg font-black text-white">Detector Accuracy</h3>
              <p className="mt-1 text-xs font-semibold text-zinc-500">Shows whether your trade data is complete enough for a reliable report.</p>
            </div>
            <span className="mistake-badge-cyan">Quality</span>
          </div>
          <div className="mt-4 rounded-2xl border border-cyan-500/25 bg-cyan-500/10 p-4">
            <div className="flex items-center justify-between"><span className="text-xs font-black uppercase tracking-widest text-cyan-300">Data Quality</span><span className="text-2xl font-black text-cyan-300">{extra.dataQuality}%</span></div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-zinc-900"><div className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-emerald-400 to-emerald-300" style={{ width: `${extra.dataQuality}%` }} /></div>
          </div>
          <div className="mt-3 rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm font-semibold leading-6 text-zinc-300">{extra.timelineText}</div>
          <div className="mt-3 flex flex-wrap gap-2">
            {extra.missingTop.length ? extra.missingTop.slice(0, 3).map((item) => <span key={item.key} className="rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1 text-[11px] font-black text-cyan-200">{item.label}: missing {item.count}</span>) : <span className="text-sm font-bold text-emerald-300">All important fields are filled.</span>}
          </div>
        </div>
      </div>
    </section>
  );
}

function CoachFlowStep({ number, title, text }) {
  return (
    <div className="coach-flow-step">
      <div className="coach-flow-number">{number}</div>
      <div>
        <div className="font-black text-white">{title}</div>
        <div className="mt-1 text-xs font-semibold leading-5 text-zinc-400">{text}</div>
      </div>
    </div>
  );
}

function MiniCoachMetric({ label, value, danger }) {
  return (
    <div className={danger ? "mini-coach-metric mini-coach-danger" : "mini-coach-metric"}>
      <div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{label}</div>
      <div className="mt-1 truncate text-sm font-black text-white">{value}</div>
    </div>
  );
}

function GuideMiniCard({ title, text }) {
  return <div className="guide-mini-card"><div className="font-black text-white">{title}</div><div className="mt-1 text-xs font-semibold leading-5 text-zinc-400">{text}</div></div>;
}

function DetectorCleanStat({ label, value, tone }) {
  const color = tone === "red" ? "text-red-300 border-red-500/25 bg-red-500/10" : tone === "amber" ? "text-amber-300 border-amber-500/25 bg-amber-500/10" : tone === "cyan" ? "text-cyan-300 border-cyan-500/25 bg-cyan-500/10" : "text-fuchsia-300 border-fuchsia-500/25 bg-fuchsia-500/10";
  return <div className={`rounded-2xl border px-4 py-3 text-center ${color}`}><div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{label}</div><div className="mt-1 text-xl font-black">{value}</div></div>;
}

function ReasonCard({ label, value, detail, tone }) {
  const color = tone === "red" ? "border-red-500/25 bg-red-500/10 text-red-300" : tone === "amber" ? "border-amber-500/25 bg-amber-500/10 text-amber-300" : "border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300";
  return <div className={`rounded-2xl border p-4 ${color}`}><div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{label}</div><div className="mt-2 line-clamp-2 text-xl font-black text-white">{value}</div><div className="mt-2 text-xs font-bold text-zinc-400">{detail}</div></div>;
}

function IssueSelectorCard({ index, issue, active, losses, onClick }) {
  const percent = losses ? Math.round((issue.count / losses) * 100) : 0;
  return (
    <button type="button" onClick={onClick} className={active ? "issue-clean-card issue-clean-card-active" : "issue-clean-card"}>
      <div className="flex items-start gap-3">
        <div className="issue-clean-number">{index}</div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-base font-black text-white">{translateDetectorText(issue.title)}</div>
              <div className="mt-1 text-xs font-bold text-zinc-400">{translateDetectorText(issue.type)} · {issue.count} loss · {formatMoney(issue.pnl)}</div>
            </div>
            <span className="rounded-full border border-red-400/25 bg-red-500/10 px-2.5 py-1 text-[11px] font-black text-red-300">{percent}%</span>
          </div>
          <div className="mt-3 rounded-xl border border-white/10 bg-black/20 p-3 text-xs font-semibold leading-5 text-zinc-300"><b className="text-emerald-300">Fix:</b> {translateDetectorFix(issue.fix)}</div>
        </div>
      </div>
    </button>
  );
}

function FixStepCard({ index, text }) {
  return <div className="fix-step-card"><div className="fix-step-number">{index}</div><div className="text-sm font-semibold leading-6 text-zinc-300">{text}</div></div>;
}

function WarningCleanCard({ warning }) {
  return <div className="rounded-2xl border border-red-500/25 bg-red-500/10 p-4"><div className="font-black text-red-300">{warning.title}</div><div className="mt-1 text-sm font-semibold leading-6 text-zinc-300">{warning.text}</div></div>;
}

function getDetectorPillExplanation(label) {
  const map = {
    Losses: "How many losing trades the detector analyzed.",
    Confidence: "How often the main mistake appears in your losing trades. A higher percentage means the pattern is more obvious.",
    Severity: "How dangerous the mistake is from 0 to 100. It considers frequency, lost P&L, and risk/discipline/psychology impact.",
    Data: "How complete your trade journal data is. Higher data quality means more reliable analysis.",
  };
  return map[label] || "Detector metric.";
}

function DetectorPill({ label, value, tone }) {
  const styles = {
    red: "border-red-500/25 bg-red-500/10 text-red-300",
    amber: "border-amber-500/25 bg-amber-500/10 text-amber-300",
    fuchsia: "border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300",
    cyan: "border-cyan-500/25 bg-cyan-500/10 text-cyan-300",
  };
  const labelMap = { Losses: "Losses", Confidence: "Confidence", Severity: "Severity", Data: "Data" };
  return (
    <div className={`group relative rounded-2xl border px-4 py-3 ${styles[tone] || styles.fuchsia}`}>
      <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-500">
        {labelMap[label] || label}
        {label !== "Losses" && <span className="flex h-4 w-4 items-center justify-center rounded-full border border-white/15 bg-black/35 text-[10px] text-zinc-300">?</span>}
      </div>
      <div className="mt-1 text-lg font-black">{value}</div>
      <div className="pointer-events-none absolute right-0 top-full z-50 mt-2 hidden w-72 rounded-xl border border-white/15 bg-[#050005] p-3 text-left text-xs font-semibold leading-5 text-zinc-300 shadow-[0_18px_45px_rgba(0,0,0,0.9)] group-hover:block">
        <div className="mb-1 font-black text-white">{labelMap[label] || label} რას ნიშნავს?</div>
        {getDetectorPillExplanation(label)}
      </div>
    </div>
  );
}

function DetectorMetricGuide() {
  return (
    <details className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-4 text-sm">
      <summary className="cursor-pointer select-none text-xs font-black uppercase tracking-widest text-fuchsia-300">Metric guide · click to learn what each metric means</summary>
      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
        <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-3"><b className="text-amber-300">Confidence</b><p className="mt-1 text-xs font-semibold leading-5 text-zinc-400">How often the main mistake appears in losing trades.</p></div>
        <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-3"><b className="text-red-300">Severity</b><p className="mt-1 text-xs font-semibold leading-5 text-zinc-400">Mistake danger based on frequency, lost P&L, risk, discipline and psychology.</p></div>
        <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/10 p-3"><b className="text-cyan-300">Data</b><p className="mt-1 text-xs font-semibold leading-5 text-zinc-400">How complete your trade journal fields are.</p></div>
      </div>
    </details>
  );
}

function DetectorStepCard({ number, title, value, detail, explanation, tone }) {
  const color = tone === "red" ? "border-red-400/25 bg-gradient-to-br from-red-500/14 to-black/35 text-red-300" : tone === "amber" ? "border-amber-400/25 bg-gradient-to-br from-amber-500/14 to-black/35 text-amber-300" : "border-fuchsia-400/25 bg-gradient-to-br from-fuchsia-500/14 to-black/35 text-fuchsia-300";
  return (
    <div className={`group relative overflow-hidden rounded-2xl border p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] transition hover:-translate-y-0.5 hover:border-red-300/55 ${color}`}>
      <div className="pointer-events-none absolute right-0 top-0 h-16 w-16 rounded-bl-3xl bg-white/5" />
      <div className="relative z-10 flex items-center justify-between gap-3">
        <div className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{number} · {title}</div>
        {explanation && <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-white/15 bg-black/35 text-[11px] font-black text-zinc-300">?</span>}
      </div>
      <div className="relative z-10 mt-2 line-clamp-2 text-xl font-black text-white">{value}</div>
      <div className="relative z-10 mt-2 line-clamp-2 text-xs font-bold text-zinc-400">{detail}</div>
      {explanation && <div className="relative z-10 mt-3 rounded-xl border border-white/10 bg-black/30 p-3 text-xs font-semibold leading-5 text-zinc-300"><span className="font-black text-red-200">Meaning: </span>{explanation}</div>}
    </div>
  );
}

function CompactPanel({ title, badge, children }) {
  const toneMap = {
    "Top შეცდომები": "red",
    "Anti-Pattern Warning": "red",
    "Winning vs Losing Formula": "mixed",
    "Setup / Session Map": "amber",
    "Data Quality & Timeline": "cyan",
  };
  const tone = toneMap[title] || "fuchsia";
  const styles = {
    red: {
      panel: "relative overflow-hidden rounded-[2rem] border border-red-500/45 bg-gradient-to-br from-[#1a0505] via-black to-[#160202] p-5 shadow-[0_0_42px_rgba(239,68,68,0.20),0_20px_65px_rgba(239,68,68,0.12)]",
      glow: "bg-red-500/18",
      line: "via-red-300/80",
      badge: "rounded-full border border-red-400/45 bg-red-500/14 px-3 py-1 text-[11px] font-black text-red-100 shadow-[0_0_18px_rgba(239,68,68,0.18)]",
    },
    mixed: {
      panel: "relative overflow-hidden rounded-[2rem] border border-emerald-500/30 bg-gradient-to-br from-[#06150d] via-black to-[#180505] p-5 shadow-[0_0_34px_rgba(16,185,129,0.10),0_20px_55px_rgba(239,68,68,0.08)]",
      glow: "bg-emerald-500/14",
      line: "via-emerald-300/70",
      badge: "rounded-full border border-emerald-400/35 bg-emerald-500/12 px-3 py-1 text-[11px] font-black text-emerald-200 shadow-[0_0_14px_rgba(16,185,129,0.12)]",
    },
    amber: {
      panel: "relative overflow-hidden rounded-[2rem] border border-amber-500/35 bg-gradient-to-br from-[#180f04] via-black to-[#041015] p-5 shadow-[0_0_34px_rgba(245,158,11,0.12),0_20px_55px_rgba(6,182,212,0.08)]",
      glow: "bg-amber-500/14",
      line: "via-amber-300/70",
      badge: "rounded-full border border-amber-400/35 bg-amber-500/12 px-3 py-1 text-[11px] font-black text-amber-200 shadow-[0_0_14px_rgba(245,158,11,0.12)]",
    },
    cyan: {
      panel: "relative overflow-hidden rounded-[2rem] border border-cyan-500/35 bg-gradient-to-br from-[#041015] via-black to-[#04150d] p-5 shadow-[0_0_34px_rgba(6,182,212,0.12),0_20px_55px_rgba(16,185,129,0.08)]",
      glow: "bg-cyan-500/14",
      line: "via-cyan-300/70",
      badge: "rounded-full border border-cyan-400/35 bg-cyan-500/12 px-3 py-1 text-[11px] font-black text-cyan-200 shadow-[0_0_14px_rgba(6,182,212,0.12)]",
    },
    fuchsia: {
      panel: "relative overflow-hidden rounded-[2rem] border border-fuchsia-500/25 bg-gradient-to-br from-[#0a0310] via-black to-[#180723] p-5 shadow-[0_20px_65px_rgba(217,70,239,0.10)]",
      glow: "bg-fuchsia-500/14",
      line: "via-fuchsia-300/70",
      badge: "rounded-full border border-fuchsia-400/30 bg-fuchsia-500/12 px-3 py-1 text-[11px] font-black text-fuchsia-200 shadow-[0_0_14px_rgba(217,70,239,0.12)]",
    },
  };
  const s = styles[tone] || styles.fuchsia;
  return <div className={s.panel}><div className={`pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full ${s.glow} blur-3xl`} /><div className={`pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent ${s.line} to-transparent`} /><div className="relative z-10 mb-4 flex items-center justify-between gap-3"><h3 className="text-lg font-black text-white">{title}</h3><span className={s.badge}>{badge}</span></div><div className="relative z-10 space-y-3">{children}</div></div>;
}

function CompactIssueRow({ index, title, meta, fix, percent, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={active ? "group relative w-full overflow-hidden rounded-[1.4rem] border border-red-300/80 bg-gradient-to-br from-red-500/28 via-red-950/35 to-black p-4 text-left shadow-[0_0_36px_rgba(239,68,68,0.28)] transition hover:-translate-y-0.5 hover:border-red-200" : "group relative w-full overflow-hidden rounded-[1.4rem] border border-red-500/25 bg-gradient-to-br from-red-950/22 via-black/70 to-red-950/10 p-4 text-left transition hover:-translate-y-0.5 hover:border-red-400/70 hover:bg-red-500/10 hover:shadow-[0_0_28px_rgba(239,68,68,0.18)]"}
    >
      <div className="pointer-events-none absolute right-0 top-0 h-20 w-20 rounded-bl-[2rem] bg-red-500/10" />
      <div className="pointer-events-none absolute -left-10 -top-10 h-24 w-24 rounded-full bg-red-500/10 blur-2xl" />
      {active && <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-red-200 to-transparent" />}
      <div className="relative z-10 flex items-start gap-3">
        <div className={active ? "flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-red-200/70 bg-gradient-to-br from-red-400 to-red-700 text-sm font-black text-white shadow-[0_0_24px_rgba(239,68,68,0.42)]" : "flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-red-400/35 bg-red-500/12 text-sm font-black text-red-200 transition group-hover:border-red-300/80 group-hover:bg-red-500/22"}>{index}</div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-lg font-black text-white">{title}</div>
              <div className="mt-1 text-xs font-bold text-red-200/60">{meta}</div>
            </div>
            <span className={active ? "rounded-full border border-red-200/45 bg-red-500/25 px-2.5 py-1 text-[11px] font-black text-red-50" : "rounded-full border border-red-400/30 bg-red-500/12 px-2.5 py-1 text-[11px] font-black text-red-200"}>{percent}%</span>
          </div>
          <div className="mt-3 rounded-xl border border-red-400/20 bg-red-500/[0.08] p-3 text-xs font-semibold leading-5 text-zinc-300"><span className="font-black text-red-300">Fix: </span>{fix}</div>
          <div className={active ? "mt-3 rounded-xl border border-red-300/45 bg-gradient-to-r from-red-500/22 to-red-950/20 px-3 py-2 text-center text-[11px] font-black uppercase tracking-wider text-red-50" : "mt-3 rounded-xl border border-red-400/25 bg-red-500/10 px-3 py-2 text-center text-[11px] font-black uppercase tracking-wider text-red-200 transition group-hover:bg-red-500/18"}>
            {active ? "✓ Selected — analysis is focused on this mistake" : "Click to focus this mistake →"}
          </div>
        </div>
      </div>
    </button>
  );
}

function FormulaBox({ title, text, tone }) {
  const isWinning = tone === "emerald";
  const cls = isWinning
    ? "border-emerald-400/35 bg-gradient-to-br from-emerald-500/16 via-black/35 to-emerald-950/25 text-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.14)]"
    : "border-red-500/35 bg-gradient-to-br from-red-500/16 via-black/35 to-red-950/25 text-red-300 shadow-[0_0_20px_rgba(239,68,68,0.14)]";
  const dotClass = isWinning ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.8)]" : "bg-red-400 shadow-[0_0_12px_rgba(248,113,113,0.8)]";
  return <div className={`w-full rounded-xl border p-4 ${cls}`}><div className="flex items-center gap-2 font-black"><span className={`h-2 w-2 rounded-full ${dotClass}`} />{title}</div><div className="mt-2 text-sm font-semibold leading-6 text-zinc-300">{text}</div></div>;
}

function MiniGroupList({ title, rows }) {
  const isSetup = title === "Setup";
  const panelClass = isSetup
    ? "rounded-xl border border-amber-400/30 bg-gradient-to-br from-amber-500/12 via-black/35 to-red-950/15 p-4 shadow-[0_0_18px_rgba(245,158,11,0.10)]"
    : "rounded-xl border border-cyan-400/30 bg-gradient-to-br from-cyan-500/12 via-black/35 to-red-950/15 p-4 shadow-[0_0_18px_rgba(6,182,212,0.10)]";
  const titleClass = isSetup ? "text-amber-300" : "text-cyan-300";
  const valueClass = isSetup ? "text-amber-300" : "text-cyan-300";
  const rowBorder = isSetup ? "border-amber-400/20" : "border-cyan-400/20";
  return <div className={panelClass}><div className={`mb-3 text-xs font-black uppercase tracking-widest ${titleClass}`}>{title}</div>{rows.length ? rows.map((row) => <div key={`${title}-${row.name}`} className={`mb-2 flex w-full items-center justify-between gap-3 rounded-lg border ${rowBorder} bg-black/25 px-3 py-2 text-left text-sm`}><span className="font-bold text-white">{translateDetectorText(row.name)}</span><span className={`font-black ${valueClass}`}>{formatMoney(row.pnl)}</span></div>) : <div className="text-sm text-zinc-500">No pattern yet.</div>}</div>;
}

function EmptyDetectorText({ text }) {
  return <div className="rounded-xl border border-dashed border-white/10 bg-black/25 p-5 text-center text-sm font-semibold text-zinc-500">{text}</div>;
}

function DetectorProfile({ title, profile, tone }) {
  const cls = tone === "emerald" ? "border-emerald-500/25 bg-emerald-500/10" : "border-red-500/25 bg-red-500/10";
  return <div className={`rounded-xl border p-4 ${cls}`}><div className="font-black text-white">{title}</div><div className="mt-3 space-y-2 text-sm text-zinc-300"><div>Emotion: <b>{translateDetectorText(profile.emotion)}</b></div><div>Timing: <b>{translateDetectorText(profile.timing)}</b></div><div>Setup: <b>{translateDetectorText(profile.setup)}</b></div><div>Session: <b>{translateDetectorText(profile.session)}</b></div></div></div>;
}

function getDetectorEnhancements(trades = [], detector = {}) {
  const safe = Array.isArray(trades) ? trades : [];
  const losses = safe.filter((trade) => Number(trade.pnl || 0) < 0);
  const ordered = [...safe].sort((a, b) => String(getTradeDateKey(a)).localeCompare(String(getTradeDateKey(b))) || Number(a.createdAt || a.id || 0) - Number(b.createdAt || b.id || 0));
  const requiredFields = ["mistake", "emotion", "entryTiming", "confirmation", "ruleBroken", "marketCondition", "setupQuality", "ruleFollowed", "entryQuality", "exitQuality"];
  const totalChecks = Math.max(1, safe.length * requiredFields.length);
  let filledChecks = 0;
  const missingMap = {};

  safe.forEach((trade) => {
    requiredFields.forEach((field) => {
      const value = trade?.[field];
      const missing = value === undefined || value === null || value === "" || String(value).startsWith("Select");
      if (missing) missingMap[field] = (missingMap[field] || 0) + 1;
      else filledChecks += 1;
    });
    if (!normalizeScreenshots(trade).length) missingMap.screenshots = (missingMap.screenshots || 0) + 1;
    if (!String(trade.notes || "").trim()) missingMap.notes = (missingMap.notes || 0) + 1;
  });

  const dataQuality = Math.round((filledChecks / totalChecks) * 100);
  const mostExpensive = [...(detector.issues || [])].sort((a, b) => Number(a.pnl || 0) - Number(b.pnl || 0))[0] || null;
  const totalLossAbs = Math.max(1, Math.abs(losses.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0)));
  const severity = detector.mainIssue ? Math.min(100, Math.round((detector.confidence || 0) * 0.45 + (Math.abs(detector.affectedPnl || 0) / totalLossAbs) * 35 + (["Risk", "Discipline", "Psychology"].includes(detector.mainRoot?.key) ? 20 : 8))) : 0;
  const severityLabel = severity >= 75 ? "High Risk" : severity >= 45 ? "Medium Risk" : "Low Risk";

  const winningFormula = `Session: ${translateDetectorText(detector.winProfile?.session)} • Timing: ${translateDetectorText(detector.winProfile?.timing)} • Emotion: ${translateDetectorText(detector.winProfile?.emotion)} • Setup: ${translateDetectorText(detector.winProfile?.setup)}`;
  const losingFormula = `Session: ${translateDetectorText(detector.lossProfile?.session)} • Timing: ${translateDetectorText(detector.lossProfile?.timing)} • Emotion: ${translateDetectorText(detector.lossProfile?.emotion)} • Setup: ${translateDetectorText(detector.lossProfile?.setup)}`;

  const lossGroupsBySetup = groupLossesByKey(losses, "setup").slice(0, 4);
  const lossGroupsBySession = groupLossesByKey(losses, "session").slice(0, 4);
  const last10 = ordered.slice(-10);
  const previous10 = ordered.slice(-20, -10);
  const lastLossRate = last10.length ? (last10.filter((trade) => Number(trade.pnl || 0) < 0).length / last10.length) * 100 : 0;
  const previousLossRate = previous10.length ? (previous10.filter((trade) => Number(trade.pnl || 0) < 0).length / previous10.length) * 100 : 0;
  const timelineChange = previous10.length ? Math.round(previousLossRate - lastLossRate) : 0;
  const timelineText = previous10.length ? (timelineChange > 0 ? `Loss rate improved by ${timelineChange}% in the last 10 trades.` : timelineChange < 0 ? `Loss rate worsened by ${Math.abs(timelineChange)}% in the last 10 trades.` : "Loss rate is unchanged in the last 10 trades.") : "At least 20 trades are needed to calculate a trend.";

  const antiPatterns = detectAntiPatterns(ordered);
  const missingTop = Object.entries(missingMap).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([key, count]) => ({ key, label: translateDataField(key), count }));

  return { dataQuality, missingTop, mostExpensive, severity, severityLabel, winningFormula, losingFormula, lossGroupsBySetup, lossGroupsBySession, timelineText, timelineChange, antiPatterns };
}

function groupLossesByKey(losses = [], key) {
  const groups = losses.reduce((output, trade) => {
    const name = trade?.[key] || "Unknown";
    if (!output[name]) output[name] = [];
    output[name].push(trade);
    return output;
  }, {});
  return Object.entries(groups).map(([name, rows]) => {
    const stats = getMistakeDetectorStats(rows);
    return { name, count: rows.length, pnl: rows.reduce((sum, trade) => sum + Number(trade.pnl || 0), 0), top: stats.mainIssue?.title || "No issue detected" };
  }).sort((a, b) => Math.abs(b.pnl) - Math.abs(a.pnl));
}

function detectAntiPatterns(ordered = []) {
  const warnings = [];
  let currentLossStreak = 0;
  let maxLossStreak = 0;
  ordered.forEach((trade) => {
    const pnl = Number(trade.pnl || 0);
    if (pnl < 0) currentLossStreak += 1;
    else if (pnl > 0) currentLossStreak = 0;
    maxLossStreak = Math.max(maxLossStreak, currentLossStreak);
  });
  if (maxLossStreak >= 2) warnings.push({ title: "Loss streak pattern", text: `Detected ${maxLossStreak} losses in a row. Use a pause rule after 2 losses.` });

  const grouped = groupTradesByDate(ordered);
  Object.entries(grouped).forEach(([date, rows]) => {
    const dayLosses = rows.filter((trade) => Number(trade.pnl || 0) < 0).length;
    if (rows.length >= 4 && dayLosses >= 2) warnings.push({ title: "Overtrading risk", text: `${date} had ${rows.length} trades and ${dayLosses} losses. Execution quality may be dropping later in the day.` });
  });

  ordered.forEach((trade, index) => {
    const previous = ordered[index - 1];
    if (!previous) return;
    const previousLoss = Number(previous.pnl || 0) < 0;
    const sameDay = getTradeDateKey(previous) === getTradeDateKey(trade);
    const riskIncreased = Number(trade.risk || 0) > Number(previous.risk || 0);
    if (previousLoss && sameDay && riskIncreased) warnings.push({ title: "Possible revenge risk", text: "Risk increased on the same day after a loss. This looks like a revenge/overrisk pattern." });
  });

  const emotional = ordered.filter((trade) => ["FOMO", "Revenge", "Greedy"].includes(trade.emotion) && Number(trade.pnl || 0) < 0).length;
  if (emotional >= 2) warnings.push({ title: "Emotional loss pattern", text: `${emotional} losses are connected to FOMO/Revenge/Greedy emotions.` });
  return warnings.slice(0, 4);
}

function translateDataField(key) {
  const map = { mistake: "Mistake", emotion: "Emotion", entryTiming: "Entry Timing", confirmation: "Confirmation", ruleBroken: "Rule Broken", marketCondition: "Market Condition", setupQuality: "Setup Quality", ruleFollowed: "Rule Followed", entryQuality: "Entry Quality", exitQuality: "Exit Quality", screenshots: "Screenshots", notes: "Notes" };
  return map[key] || key;
}

function DetectorEnhancementPanel({ trades, detector }) {
  const extra = getDetectorEnhancements(trades, detector);
  return (
    <div className="mt-6 grid grid-cols-1 gap-5 xl:grid-cols-2">
      <div className="rounded-2xl border border-fuchsia-500/25 bg-fuchsia-500/10 p-5">
        <SectionTitle title="Weekly Focus / Next Trade Rules" icon={<Target size={18} />} />
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
          {detector.focusPlan.map((rule, index) => (
            <div key={rule} className="rounded-xl border border-white/10 bg-black/35 p-4">
              <div className="text-xs font-black text-fuchsia-300">Rule {index + 1}</div>
              <div className="mt-2 text-sm font-semibold text-zinc-300">{rule}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-red-500/25 bg-red-500/10 p-5">
        <SectionTitle title="Severity & Most Expensive Mistake" icon={<span className="text-lg">!</span>} />
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-white/10 bg-black/35 p-4">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Severity</div>
            <div className="mt-2 text-3xl font-black text-red-300">{extra.severity}/100</div>
            <div className="mt-1 text-sm font-bold text-zinc-400">{extra.severityLabel}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/35 p-4">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Most expensive mistake</div>
            <div className="mt-2 text-xl font-black text-white">{extra.mostExpensive ? translateDetectorText(extra.mostExpensive.title) : "ჯერ არ ჩანს"}</div>
            <div className="mt-1 text-sm font-bold text-red-300">{extra.mostExpensive ? formatMoney(extra.mostExpensive.pnl) : formatMoney(0)}</div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-5">
        <SectionTitle title="Winning Formula vs Losing Formula" icon={<BarChart3 size={18} />} />
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="rounded-xl border border-emerald-500/20 bg-black/35 p-4"><div className="font-black text-emerald-300">Winning Formula</div><div className="mt-2 text-sm font-semibold text-zinc-300">{extra.winningFormula}</div></div>
          <div className="rounded-xl border border-red-500/20 bg-black/35 p-4"><div className="font-black text-red-300">Losing Formula</div><div className="mt-2 text-sm font-semibold text-zinc-300">{extra.losingFormula}</div></div>
        </div>
      </div>

      <div className="rounded-2xl border border-cyan-500/25 bg-cyan-500/10 p-5">
        <SectionTitle title="Data Quality Score" icon={<ListChecks size={18} />} />
        <div className="mt-4 flex items-center gap-5">
          <div className="text-5xl font-black text-cyan-300">{extra.dataQuality}%</div>
          <div className="flex-1"><div className="h-4 overflow-hidden rounded-full bg-zinc-900"><div className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-fuchsia-400 to-emerald-400" style={{ width: `${extra.dataQuality}%` }} /></div><div className="mt-2 text-xs font-bold text-zinc-400">Detector accuracy depends on how completely trade fields are filled.</div></div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">{extra.missingTop.length ? extra.missingTop.map((item) => <span key={item.key} className="rounded-full border border-white/10 bg-black/35 px-3 py-1 text-xs font-black text-zinc-300">{item.label}: missing {item.count}</span>) : <span className="text-sm font-bold text-emerald-300">All important fields are filled.</span>}</div>
      </div>

      <DetectorGroupPanel title="Setup-Specific Mistakes" rows={extra.lossGroupsBySetup} empty="No setup loss pattern yet." />
      <DetectorGroupPanel title="Session Mistake Map" rows={extra.lossGroupsBySession} empty="No session loss pattern yet." />

      <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 p-5">
        <SectionTitle title="Mistake Timeline" icon={<TrendingUp size={18} />} />
        <div className="mt-4 rounded-xl border border-white/10 bg-black/35 p-4 text-sm font-semibold text-zinc-300">{extra.timelineText}</div>
      </div>

      <div className="rounded-2xl border border-orange-500/25 bg-orange-500/10 p-5">
        <SectionTitle title="Anti-Pattern Warning" icon={<span className="text-lg">⚠</span>} />
        <div className="mt-4 space-y-3">
          {extra.antiPatterns.length ? extra.antiPatterns.map((warning) => <div key={warning.title} className="rounded-xl border border-white/10 bg-black/35 p-4"><div className="font-black text-orange-300">{warning.title}</div><div className="mt-1 text-sm font-semibold text-zinc-300">{warning.text}</div></div>) : <div className="rounded-xl border border-white/10 bg-black/35 p-4 text-sm font-semibold text-zinc-400">No dangerous anti-pattern detected yet.</div>}
        </div>
      </div>
    </div>
  );
}

function DetectorGroupPanel({ title, rows, empty }) {
  return (
    <div className="rounded-2xl border border-fuchsia-500/20 bg-black/35 p-5">
      <SectionTitle title={title} icon={<ListChecks size={18} />} />
      <div className="mt-4 space-y-3">
        {rows.length ? rows.map((row) => (
          <div key={row.name} className="rounded-xl border border-white/10 bg-black/35 p-4">
            <div className="flex items-center justify-between gap-4"><div className="font-black text-white">{translateDetectorText(row.name)}</div><div className="font-black text-red-300">{formatMoney(row.pnl)}</div></div>
            <div className="mt-1 text-xs font-bold text-zinc-400">{row.count} loss · Main issue: {translateDetectorText(row.top)}</div>
          </div>
        )) : <div className="rounded-xl border border-dashed border-white/10 bg-black/25 p-5 text-center text-zinc-500">{empty}</div>}
      </div>
    </div>
  );
}

function StatisticsMetricCard({ title, value, sub, icon, tone = "white", active }) {
  const upperTitle = String(title || "").toUpperCase();
  const finalTone = upperTitle.includes("WIN") ? "green" : upperTitle.includes("LOSS") || upperTitle.includes("DRAWDOWN") ? "red" : tone;

  const cardToneClass = {
    green: "border-emerald-500/30 bg-gradient-to-br from-emerald-950/40 via-emerald-950/10 to-black hover:border-emerald-400/80 hover:shadow-emerald-500/20",
    red: "border-red-500/30 bg-gradient-to-br from-red-950/40 via-red-950/10 to-black hover:border-red-400/80 hover:shadow-red-500/20",
    amber: "border-amber-500/30 bg-gradient-to-br from-amber-950/35 via-amber-950/10 to-black hover:border-amber-400/80 hover:shadow-amber-500/20",
    white: active ? "border-fuchsia-500/35 bg-gradient-to-br from-fuchsia-950/35 via-black to-black hover:border-fuchsia-400/80 hover:shadow-fuchsia-500/20" : "border-fuchsia-500/20 bg-gradient-to-br from-zinc-950 via-black to-black hover:border-fuchsia-400/70 hover:shadow-fuchsia-500/15",
  }[finalTone] || "border-fuchsia-500/20 bg-gradient-to-br from-zinc-950 via-black to-black";

  const iconClass = {
    green: "bg-emerald-500/10 text-emerald-300",
    red: "bg-red-500/10 text-red-300",
    amber: "bg-amber-500/10 text-amber-300",
    white: "bg-fuchsia-500/10 text-fuchsia-300",
  }[finalTone] || "bg-fuchsia-500/10 text-fuchsia-300";

  const valueColor = {
    green: "text-emerald-400",
    red: "text-red-400",
    amber: "text-amber-400",
    white: "text-white",
  }[finalTone] || "text-white";

  const subClass = finalTone === "green" ? "border-emerald-500/25 bg-emerald-500/15 text-emerald-300" : finalTone === "red" ? "border-red-500/25 bg-red-500/15 text-red-300" : finalTone === "amber" ? "border-amber-500/25 bg-amber-500/15 text-amber-300" : "border-fuchsia-500/25 bg-fuchsia-500/15 text-fuchsia-200";

  return (
    <button className={`statistics-metric-card statistics-core-card group relative min-h-[180px] overflow-hidden rounded-xl border p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:shadow-2xl ${cardToneClass}`}>
      <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-white/5 blur-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/35 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <div className="relative z-10 mx-auto flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider text-zinc-400">
        <span className={`flex h-7 w-7 items-center justify-center rounded-md ${iconClass}`}>{icon}</span>
        {title}
      </div>
      <div className={`relative z-10 mt-5 text-3xl font-black ${valueColor}`}><AnimatedValue value={value} /></div>
      {sub && <div className={`relative z-10 mx-auto mt-4 w-fit rounded-md border px-3 py-1 text-[10px] font-bold ${subClass}`}>{sub}</div>}
    </button>
  );
}

function AdvancedStatCard({ title, value, sub, tone, muted }) {
  const styles = {
    fuchsia: {
      card: "border-fuchsia-500/35 bg-gradient-to-br from-fuchsia-950/35 via-black to-black hover:border-fuchsia-400/90 hover:shadow-fuchsia-500/25",
      glow: "bg-fuchsia-500/20",
      value: muted ? "text-fuchsia-300" : "text-fuchsia-400",
      sub: "bg-fuchsia-500/15 text-fuchsia-200 border-fuchsia-500/25",
    },
    green: {
      card: "border-emerald-500/30 bg-gradient-to-br from-emerald-950/50 via-emerald-950/10 to-black hover:border-emerald-400/90 hover:shadow-emerald-500/25",
      glow: "bg-emerald-500/18",
      value: "text-emerald-500",
      sub: "bg-emerald-500/15 text-emerald-300 border-emerald-500/25",
    },
    red: {
      card: "border-red-500/30 bg-gradient-to-br from-red-950/50 via-red-950/10 to-black hover:border-red-400/90 hover:shadow-red-500/25",
      glow: "bg-red-500/18",
      value: "text-red-400",
      sub: "bg-red-500/15 text-red-300 border-red-500/25",
    },
  };
  const s = styles[tone] || styles.fuchsia;
  return (
    <button className={`group relative overflow-hidden rounded-xl border p-7 text-center transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:shadow-2xl ${s.card}`}>
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className={`absolute -right-12 -top-12 h-32 w-32 rounded-full blur-2xl ${s.glow}`} />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
      </div>
      <div className="relative z-10 text-xs font-black uppercase tracking-wider text-zinc-400">{title}</div>
      <div className={`relative z-10 mt-5 text-3xl font-black ${s.value}`}>{value}</div>
      {sub && <div className={`relative z-10 mx-auto mt-4 w-fit rounded-md border px-3 py-1 text-[10px] font-bold ${s.sub}`}>{sub}</div>}
    </button>
  );
}

function BestPerformanceCard({ title, value, detail, badge, icon, accent }) {
  const accentMap = {
    amber: "text-amber-400 bg-amber-500/10",
    fuchsia: "text-fuchsia-400 bg-fuchsia-500/10",
    blue: "text-blue-400 bg-blue-500/10",
    green: "text-emerald-400 bg-emerald-500/10",
    cyan: "text-cyan-400 bg-cyan-500/10",
  };
  return (
    <button className="best-performance-card group relative overflow-hidden rounded-xl border border-fuchsia-500/18 bg-gradient-to-br from-[#160b1f] via-[#09060d] to-black p-5 text-left shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:border-fuchsia-400/80 hover:shadow-[0_0_30px_rgba(217,70,239,0.28)]">
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-500/18 via-transparent to-fuchsia-900/20" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400 to-transparent" />
        <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-fuchsia-500/20 blur-2xl" />
      </div>
      <div className="relative z-10 flex items-start justify-between">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-zinc-400">▣</div>
        <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm ${accentMap[accent] || accentMap.fuchsia}`}>{icon}</div>
      </div>
      <div className="relative z-10 mt-4 text-xs font-black uppercase tracking-wider text-zinc-400">{title}</div>
      <div className="relative z-10 mt-4 text-3xl font-black text-emerald-500">{value}</div>
      <div className="relative z-10 mt-2 text-sm font-bold text-white">{detail}</div>
      <div className="relative z-10 mt-5 w-fit rounded-full bg-zinc-800 px-3 py-1 text-[10px] font-black text-white">{badge}</div>
    </button>
  );
}

function StatisticsPerformanceTimeline({ curve, stats }) {
  const chartData = curve.length ? curve : [{ date: "No data", pnl: 0 }];
  const lastPoint = chartData[chartData.length - 1];
  const firstPoint = chartData[0];
  const change = Number(lastPoint?.pnl || 0) - Number(firstPoint?.pnl || 0);
  return (
    <div className="statistics-chart-panel statistics-timeline-card group relative overflow-hidden rounded-xl border border-fuchsia-500/20 bg-gradient-to-br from-[#13081d] via-black to-[#030104] p-6 transition-all duration-300 hover:border-fuchsia-400/70 hover:shadow-[0_0_36px_rgba(217,70,239,0.20)]">
      <div className="pointer-events-none absolute right-0 top-0 h-40 w-40 rounded-bl-[4rem] bg-fuchsia-500/10 blur-xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400/70 to-transparent" />
      <div className="relative z-10 flex items-start justify-between">
        <SectionTitle title="Performance Timeline" icon={<TrendingUp size={18} />} />
        <div className="rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-2 text-right">
          <div className="text-[10px] font-black uppercase tracking-widest text-fuchsia-300">Net P&L</div>
          <div className={stats.totalPnl >= 0 ? "text-lg font-black text-emerald-400" : "text-lg font-black text-red-400"}>{formatMoney(stats.totalPnl)}</div>
        </div>
      </div>
      <div className="relative z-10 mt-5 grid grid-cols-3 gap-3">
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
          <div className="text-[10px] font-black uppercase text-zinc-400">Wins</div>
          <div className="mt-1 text-xl font-black text-emerald-400">{stats.wins}</div>
        </div>
        <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-3">
          <div className="text-[10px] font-black uppercase text-zinc-400">Losses</div>
          <div className="mt-1 text-xl font-black text-red-400">{stats.losses}</div>
        </div>
        <div className="rounded-xl border border-fuchsia-500/20 bg-fuchsia-500/10 p-3">
          <div className="text-[10px] font-black uppercase text-zinc-400">Change</div>
          <div className={change >= 0 ? "mt-1 text-xl font-black text-emerald-400" : "mt-1 text-xl font-black text-red-400"}>{formatMoney(change)}</div>
        </div>
      </div>
      <div className="relative z-10 mt-6 h-72 rounded-xl border border-white/10 bg-black/30 p-3">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 18, right: 20, left: 8, bottom: 6 }}>
            <CartesianGrid strokeDasharray="4 6" stroke="rgba(168,85,247,0.24)" vertical={false} />
            <XAxis dataKey="date" stroke="#94a3b8" tickLine={false} axisLine={{ stroke: "rgba(168,85,247,0.28)" }} />
            <YAxis stroke="#94a3b8" tickLine={false} axisLine={{ stroke: "rgba(168,85,247,0.28)" }} tickFormatter={(value) => `$${value}`} />
            <Tooltip contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }} formatter={(value) => [formatMoney(value), "Equity"]} />
            <Line type="monotone" dataKey="pnl" stroke="#d946ef" strokeWidth={4} dot={{ r: 5, fill: "#22c55e", stroke: "#ffffff", strokeWidth: 2 }} activeDot={{ r: 8, fill: "#d946ef", stroke: "#ffffff", strokeWidth: 3 }} />
            <Line type="monotone" dataKey="pnl" stroke="#22c55e" strokeWidth={2} dot={false} opacity={0.45} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function StatisticsWinLossPanel({ stats }) {
  const total = Math.max(1, Number(stats.wins || 0) + Number(stats.losses || 0));
  const winPercent = Math.max(0, Math.min(100, Number(stats.winRate || 0)));
  const lossPercent = Math.max(0, 100 - winPercent);
  return (
    <div className="statistics-chart-panel statistics-winloss-card group relative overflow-hidden rounded-xl border border-emerald-500/20 bg-gradient-to-br from-[#06150d] via-black to-[#110313] p-6 transition-all duration-300 hover:border-emerald-400/65 hover:shadow-[0_0_36px_rgba(16,185,129,0.18)]">
      <div className="pointer-events-none absolute -right-14 -top-14 h-44 w-44 rounded-full bg-emerald-500/12 blur-3xl" />
      <div className="pointer-events-none absolute -left-16 bottom-0 h-40 w-40 rounded-full bg-fuchsia-500/10 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/70 to-transparent" />

      <div className="relative z-10 flex items-start justify-between">
        <SectionTitle title="Win/Loss Analysis" icon={<Target size={18} />} />
        <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-3 py-2 text-right">
          <div className="text-[10px] font-black uppercase tracking-widest text-emerald-300">Accuracy</div>
          <div className="text-lg font-black text-emerald-400">{winPercent.toFixed(1)}%</div>
        </div>
      </div>

      <div className="relative z-10 mt-6 grid grid-cols-[1fr_220px] items-center gap-6">
        <div className="space-y-4">
          <WinLossMiniCard label="Wins" value={stats.wins} percent={winPercent} tone="green" />
          <WinLossMiniCard label="Losses" value={stats.losses} percent={lossPercent} tone="red" />
          <WinLossMiniCard label="Break Even" value={stats.breakEvens || 0} percent={stats.trades ? ((stats.breakEvens || 0) / stats.trades) * 100 : 0} tone="amber" />
          <div className="rounded-xl border border-fuchsia-500/20 bg-fuchsia-500/10 p-4">
            <div className="mb-3 flex items-center justify-between text-xs font-black uppercase tracking-wider text-zinc-400">
              <span>Win/Loss/BE Balance</span>
              <span className="text-fuchsia-300">{stats.wins}:{stats.losses}:{stats.breakEvens || 0}</span>
            </div>
            <div className="flex h-3 overflow-hidden rounded-full bg-zinc-900">
              <div className="bg-gradient-to-r from-emerald-500 to-emerald-300" style={{ width: `${stats.trades ? (stats.wins / stats.trades) * 100 : 0}%` }} />
              <div className="bg-gradient-to-r from-red-500 to-red-400" style={{ width: `${stats.trades ? (stats.losses / stats.trades) * 100 : 0}%` }} />
              <div className="bg-gradient-to-r from-amber-500 to-amber-300" style={{ width: `${stats.trades ? ((stats.breakEvens || 0) / stats.trades) * 100 : 0}%` }} />
            </div>
          </div>
        </div>

        <StatisticsWinLossCircle stats={stats} />
      </div>
    </div>
  );
}

function WinLossMiniCard({ label, value, percent, tone }) {
  const isGreen = tone === "green";
  const isAmber = tone === "amber";
  return (
    <div className={isGreen ? "rounded-xl border border-emerald-500/25 bg-emerald-500/10 p-4" : isAmber ? "rounded-xl border border-amber-500/25 bg-amber-500/10 p-4" : "rounded-xl border border-red-500/25 bg-red-500/10 p-4"}>
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs font-black uppercase tracking-wider text-zinc-400">{label}</div>
          <div className={isGreen ? "mt-1 text-3xl font-black text-emerald-400" : isAmber ? "mt-1 text-3xl font-black text-amber-400" : "mt-1 text-3xl font-black text-red-400"}>{value}</div>
        </div>
        <div className={isGreen ? "rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-black text-emerald-300" : isAmber ? "rounded-full bg-amber-500/15 px-3 py-1 text-xs font-black text-amber-300" : "rounded-full bg-red-500/15 px-3 py-1 text-xs font-black text-red-300"}>{percent.toFixed(1)}%</div>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-zinc-900">
        <div className={isGreen ? "h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-300" : isAmber ? "h-full rounded-full bg-gradient-to-r from-amber-500 to-amber-300" : "h-full rounded-full bg-gradient-to-r from-red-500 to-red-400"} style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

function StatisticsWinLossCircle({ stats }) {
  const winRate = Math.max(0, Math.min(100, Number(stats.winRate || 0)));
  const lossRate = Math.max(0, Math.min(100, 100 - winRate));
  const radius = 82;
  const circumference = 2 * Math.PI * radius;
  const winOffset = circumference - (winRate / 100) * circumference;
  const lossOffset = circumference - (lossRate / 100) * circumference;
  const hasWins = Number(stats.wins || 0) > 0;
  const hasLosses = Number(stats.losses || 0) > 0;

  return (
    <div className="flex h-72 items-center justify-center">
      <div className="statistics-winloss-circle group relative flex h-60 w-60 items-center justify-center rounded-[2rem] border border-fuchsia-500/25 bg-gradient-to-br from-[#050005] via-black to-[#08020b] shadow-[0_0_45px_rgba(217,70,239,0.12)] transition-all duration-300 hover:border-fuchsia-400/65 hover:shadow-[0_0_55px_rgba(217,70,239,0.22)]">
        <div className="pointer-events-none absolute -inset-4 rounded-[2.4rem] bg-gradient-to-br from-emerald-500/12 via-transparent to-red-500/12 blur-2xl opacity-80" />
        <div className="pointer-events-none absolute inset-4 rounded-[1.6rem] border border-white/10 bg-black/35" />
        <div className="pointer-events-none absolute inset-x-8 top-6 h-px bg-gradient-to-r from-transparent via-fuchsia-400/70 to-transparent" />

        <svg className="absolute inset-0 h-full w-full -rotate-90 p-4" viewBox="0 0 220 220">
          <defs>
            <linearGradient id="winNeonGradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="55%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#22c55e" />
            </linearGradient>
            <linearGradient id="lossNeonGradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#fb7185" />
              <stop offset="55%" stopColor="#ef4444" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
            <filter id="softGlow">
              <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <circle cx="110" cy="110" r={radius} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="14" />
          <circle cx="110" cy="110" r={radius} fill="none" stroke="rgba(239,68,68,0.22)" strokeWidth="14" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={lossOffset} filter="url(#softGlow)" />
          <circle cx="110" cy="110" r={radius} fill="none" stroke="url(#winNeonGradient)" strokeWidth="14" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={winOffset} filter="url(#softGlow)" />
          {!hasWins && hasLosses && <circle cx="110" cy="110" r={radius} fill="none" stroke="url(#lossNeonGradient)" strokeWidth="14" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset="0" filter="url(#softGlow)" />}
        </svg>

        <div className="relative z-10 flex h-36 w-36 flex-col items-center justify-center rounded-full border border-white/10 bg-black shadow-[inset_0_0_28px_rgba(217,70,239,0.08),0_0_24px_rgba(0,0,0,0.7)]">
          <div className="text-[10px] font-black uppercase tracking-[0.22em] text-zinc-500">Win Rate</div>
          <div className={hasWins ? "mt-2 text-5xl font-black leading-none text-emerald-400 drop-shadow-[0_0_16px_rgba(16,185,129,0.75)]" : hasLosses ? "mt-2 text-5xl font-black leading-none text-red-400 drop-shadow-[0_0_16px_rgba(239,68,68,0.75)]" : "mt-2 text-5xl font-black leading-none text-fuchsia-200 drop-shadow-[0_0_14px_rgba(217,70,239,0.55)]"}>
            {winRate.toFixed(1)}<span className="text-xl">%</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs font-black text-zinc-400">
            <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.95)]" /> {stats.wins}W
            <span className="h-2 w-2 rounded-full bg-red-400 shadow-[0_0_10px_rgba(248,113,113,0.95)]" /> {stats.losses}L
          </div>
        </div>

        <div className="absolute -bottom-3 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/10 bg-black px-3 py-2 text-[11px] font-black text-zinc-300 shadow-[0_12px_30px_rgba(0,0,0,0.55)]">
          <span className="text-emerald-300">{stats.wins} wins</span>
          <span className="text-zinc-600">/</span>
          <span className="text-red-300">{stats.losses} losses</span>
          <span className="text-zinc-600">/</span>
          <span className="text-amber-300">{stats.breakEvens || 0} BE</span>
        </div>
      </div>
    </div>
  );
}

function StatisticsPatternsView({ stats, trades = [] }) {
  const weekdays = [
    { short: "Mon", full: "Monday", tone: "fuchsia", index: 1 },
    { short: "Tue", full: "Tuesday", tone: "blue", index: 2 },
    { short: "Wed", full: "Wednesday", tone: "violet", index: 3 },
    { short: "Thu", full: "Thursday", tone: "cyan", index: 4 },
    { short: "Fri", full: "Friday", tone: "emerald", index: 5 },
  ];
  const weekdayStats = weekdays.reduce((output, day) => {
    const dayTrades = trades.filter((trade) => {
      const date = new Date(`${getTradeDateKey(trade)}T00:00:00`);
      return !Number.isNaN(date.getTime()) && date.getDay() === day.index;
    });
    const summary = summarizeTrades(dayTrades);
    const riskTrades = dayTrades.filter((trade) => Number(trade.risk || 0) > 0);
    output[day.short] = {
      ...summary,
      avgRR: riskTrades.length ? riskTrades.reduce((sum, trade) => sum + getTradeRR(trade), 0) / riskTrades.length : 0,
    };
    return output;
  }, {});
  const totalTrades = stats.trades || 0;
  const avgRR = stats.avgRR || 0;
  const totalPnl = stats.totalPnl || 0;
  const activeDay = weekdays.map((day) => ({ ...day, summary: weekdayStats[day.short] })).filter((day) => day.summary.count > 0).sort((a, b) => Number(b.summary.pnl || 0) - Number(a.summary.pnl || 0))[0]?.short || "Mon";
  return (
    <section className="mt-10">
      <div className="flex items-end justify-between">
        <SectionTitle title="Weekday Performance" icon={<Calendar size={18} />} />
        <div className="rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-4 py-2 text-xs font-black uppercase tracking-widest text-fuchsia-300">
          Monday - Friday
        </div>
      </div>

      <div className="statistics-pattern-panel statistics-pattern-pro mt-7 rounded-2xl border border-fuchsia-500/20 bg-gradient-to-br from-black via-[#050307] to-[#12091b] p-6">
        <div className="pointer-events-none absolute right-0 top-0 h-56 w-56 rounded-bl-[5rem] bg-fuchsia-500/10 blur-3xl" />
        <div className="pointer-events-none absolute left-0 bottom-0 h-52 w-52 rounded-tr-[5rem] bg-emerald-500/5 blur-3xl" />

        <div className="relative z-10 mb-6 grid grid-cols-4 gap-4">
          <PatternSummaryCard title="Total Trades" value={totalTrades} subtitle="Monday - Friday" tone="fuchsia" />
          <PatternSummaryCard title="Best Day" value={activeDay} subtitle={totalTrades ? formatMoney(weekdayStats[activeDay]?.pnl || 0) : "No trades"} tone="emerald" />
          <PatternSummaryCard title="Win Rate" value={`${stats.winRate.toFixed(1)}%`} subtitle="Overall" tone="green" />
          <PatternSummaryCard title="Avg RR" value={avgRR.toFixed(2)} subtitle="Risk reward" tone="amber" />
        </div>

        <div className="relative z-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5">
          {weekdays.map((day) => {
            const isActive = day.short === activeDay && totalTrades > 0;
            return (
              <PatternDayCard
                key={day.short}
                day={day}
                isActive={isActive}
                dayStats={weekdayStats[day.short]}
              />
            );
          })}
        </div>

        <div className="relative z-10 mt-7 overflow-hidden rounded-2xl border border-white/10 bg-black/35 p-5">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400/70 to-transparent" />
          <div className="grid grid-cols-1 gap-6 text-center sm:grid-cols-2 xl:grid-cols-4">
            <PatternBottomMetric label="Total Trades" value={totalTrades} tone="fuchsia" />
            <PatternBottomMetric label="Overall Win Rate" value={`${stats.winRate.toFixed(1)}%`} tone="emerald" />
            <PatternBottomMetric label="Overall Avg RR" value={avgRR.toFixed(2)} tone="amber" />
            <PatternBottomMetric label="Total P&L" value={formatMoney(totalPnl)} tone="emerald" />
          </div>
        </div>
      </div>
    </section>
  );
}

function PatternSummaryCard({ title, value, subtitle, tone }) {
  const styles = {
    fuchsia: "border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300",
    emerald: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
    green: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
    amber: "border-amber-500/25 bg-amber-500/10 text-amber-300",
  };
  return (
    <div className={`rounded-xl border p-4 ${styles[tone] || styles.fuchsia}`}>
      <div className="text-[10px] font-black uppercase tracking-widest text-zinc-400">{title}</div>
      <div className="mt-2 text-2xl font-black">{value}</div>
      <div className="mt-1 text-xs font-bold text-zinc-400">{subtitle}</div>
    </div>
  );
}

function PatternDayCard({ day, isActive, dayStats }) {
  const totalTrades = dayStats?.count || 0;
  const wins = dayStats?.wins || 0;
  const losses = dayStats?.losses || 0;
  const breakEvens = dayStats?.breakEvens || 0;
  const winRate = dayStats?.winRate || 0;
  const avgRR = dayStats?.avgRR || 0;
  const totalPnl = dayStats?.pnl || 0;
  const avgPnl = totalTrades ? totalPnl / totalTrades : 0;
  const dayScore = totalTrades ? Math.round((Math.max(0, Math.min(100, winRate)) * 0.45) + (Math.max(0, Math.min(100, avgRR * 25)) * 0.30) + (totalPnl > 0 ? 25 : 0)) : 0;
  const hasTrades = totalTrades > 0;
  const toneClass = {
    fuchsia: "from-fuchsia-950/30 to-fuchsia-950/10 border-fuchsia-500/25",
    blue: "from-blue-950/25 to-blue-950/10 border-blue-500/20",
    violet: "from-violet-950/25 to-violet-950/10 border-violet-500/20",
    cyan: "from-cyan-950/25 to-cyan-950/10 border-cyan-500/20",
    emerald: "from-emerald-950/40 to-emerald-950/10 border-emerald-500/35",
  };
  return (
    <button className={`weekday-card weekday-card-pro group relative min-h-[245px] overflow-hidden rounded-2xl border bg-gradient-to-br via-black p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:border-fuchsia-400/80 hover:shadow-[0_0_30px_rgba(217,70,239,0.20)] ${toneClass[day.tone]} ${isActive ? "weekday-card-active" : ""}`}>
      <div className="pointer-events-none absolute right-0 top-0 h-20 w-20 rounded-bl-[2rem] bg-white/5" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400/50 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="relative z-10 flex items-start justify-between">
        <div>
          <div className="text-2xl font-black text-white">{day.short}</div>
          <div className="mt-1 text-xs font-bold text-zinc-400">{day.full}</div>
        </div>
        <div className={isActive ? "rounded-full border border-emerald-500/35 bg-emerald-500/15 px-3 py-1 text-xs font-black text-emerald-300" : hasTrades ? "rounded-full border border-fuchsia-500/35 bg-fuchsia-500/15 px-3 py-1 text-xs font-black text-fuchsia-300" : "rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-black text-zinc-500"}>
          {isActive ? "Best" : hasTrades ? "Active" : "No trades"}
        </div>
      </div>

      <div className="relative z-10 mt-6 flex items-center justify-between rounded-xl border border-white/10 bg-black/25 p-3 text-sm">
        <span className="font-bold text-zinc-300"><span className="mr-2 text-fuchsia-400">▥</span>Trades</span>
        <span className="font-black text-white">{totalTrades}</span>
      </div>

      {hasTrades ? (
        <div className="relative z-10 mt-4 space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/10 p-2"><div className="text-[10px] font-black uppercase text-zinc-500">Wins</div><div className="text-lg font-black text-emerald-400">{wins}</div></div>
            <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-2"><div className="text-[10px] font-black uppercase text-zinc-500">Losses</div><div className="text-lg font-black text-red-400">{losses}</div></div>
            <div className="rounded-lg border border-amber-500/20 bg-amber-500/10 p-2"><div className="text-[10px] font-black uppercase text-zinc-500">BE</div><div className="text-lg font-black text-amber-400">{breakEvens}</div></div>
          </div>
          <div className="flex justify-between text-sm"><span className="text-emerald-400">◎ Win Rate</span><span className="font-black text-emerald-400">{winRate.toFixed(1)}%</span></div>
          <div className="flex justify-between text-sm"><span className="text-amber-400">⌁ Avg RR</span><span className="font-black text-amber-400">{avgRR.toFixed(2)}</span></div>
          <div className="flex justify-between text-sm"><span className="text-fuchsia-300">Avg P&L</span><span className={avgPnl >= 0 ? "font-black text-emerald-400" : "font-black text-red-400"}>{formatMoney(avgPnl)}</span></div>
          <div className={totalPnl >= 0 ? "rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3 text-center text-xs text-zinc-400" : "rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-center text-xs text-zinc-400"}>Total P&L<div className={totalPnl >= 0 ? "mt-1 text-xl font-black text-emerald-400" : "mt-1 text-xl font-black text-red-400"}>{formatMoney(totalPnl)}</div></div>
          <div className="rounded-xl border border-fuchsia-500/20 bg-fuchsia-500/10 p-3">
            <div className="mb-2 flex justify-between text-[10px] font-black uppercase tracking-wider text-zinc-500"><span>Day Score</span><span className="text-fuchsia-300">{dayScore}/100</span></div>
            <div className="h-2 overflow-hidden rounded-full bg-zinc-900"><div className="h-full rounded-full bg-gradient-to-r from-fuchsia-500 via-emerald-400 to-emerald-300" style={{ width: `${dayScore}%` }} /></div>
          </div>
        </div>
      ) : (
        <div className="relative z-10 mt-7 flex flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-black/20 p-5 text-sm text-zinc-500">
          <span className="text-2xl text-fuchsia-400/40">—</span>
          <span className="mt-2">No trades recorded</span>
        </div>
      )}
    </button>
  );
}

function PatternBottomMetric({ label, value, tone }) {
  const color = tone === "amber" ? "text-amber-400" : tone === "fuchsia" ? "text-fuchsia-400" : "text-emerald-400";
  return <div><div className={`text-3xl font-black ${color}`}>{value}</div><div className="mt-1 text-sm text-zinc-400">{label}</div></div>;
}

function StatisticsStrategiesView({ stats }) {
  const rows = Object.entries(stats.strategyStats || {});
  const fallback = [["Liquidity Sweep", { count: stats.trades, wins: stats.wins, losses: stats.losses, breakEvens: stats.breakEvens || 0, pnl: stats.totalPnl }]];
  const strategyRows = rows.length ? rows : fallback;
  const best = [...strategyRows].sort((a, b) => Number(b[1].pnl || 0) - Number(a[1].pnl || 0))[0];
  const bestName = best?.[0] || "Liquidity Sweep";
  const bestStats = best?.[1] || { count: stats.trades, wins: stats.wins, losses: stats.losses, pnl: stats.totalPnl };
  const winRate = bestStats.count ? ((bestStats.wins || 0) / bestStats.count) * 100 : 0;
  const avgPnl = bestStats.count ? bestStats.pnl / bestStats.count : 0;
  const bestAvgRR = bestStats.riskTrades ? bestStats.rrSum / bestStats.riskTrades : 0;
  return (
    <section className="mt-10">
      <div className="flex items-end justify-between">
        <SectionTitle title="Strategy Performance" icon={<span className="text-xl">ϟ</span>} />
        <div className="rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-4 py-2 text-xs font-black uppercase tracking-widest text-fuchsia-300">
          {strategyRows.length} active strategies
        </div>
      </div>

      <div className="statistics-strategy-panel mt-7 overflow-hidden rounded-2xl border border-fuchsia-500/20 bg-gradient-to-br from-black via-[#05030a] to-[#13091c] p-6">
        <div className="pointer-events-none absolute right-0 top-0 h-56 w-56 rounded-bl-[5rem] bg-fuchsia-500/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 left-0 h-52 w-52 rounded-tr-[5rem] bg-emerald-500/5 blur-3xl" />

        <div className="relative z-10 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StrategySummaryCard label="Best Strategy" value={bestName} subtitle="Highest P&L" tone="fuchsia" />
          <StrategySummaryCard label="Win Rate" value={`${winRate.toFixed(1)}%`} subtitle={`${bestStats.wins || 0}W / ${bestStats.losses || 0}L / ${bestStats.breakEvens || 0}BE`} tone="emerald" />
          <StrategySummaryCard label="Total P&L" value={formatMoney(bestStats.pnl)} subtitle="Net result" tone={bestStats.pnl >= 0 ? "emerald" : "red"} />
          <StrategySummaryCard label="Avg RR" value={bestAvgRR.toFixed(2)} subtitle="Risk reward" tone="amber" />
        </div>

        <div className="relative z-10 mt-7 grid grid-cols-1 gap-6 xl:grid-cols-[1.15fr_.85fr]">
          <div className="rounded-2xl border border-fuchsia-500/20 bg-black/35 p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-black text-white">Strategy Leaderboard</h3>
              <span className="rounded-full border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-1 text-xs font-black text-fuchsia-300">Ranked by P&L</span>
            </div>
            <div className="space-y-3">
              {strategyRows.map(([name, item], index) => {
                const itemWinRate = item.count ? ((item.wins || 0) / item.count) * 100 : 0;
                const width = Math.max(8, Math.min(100, Math.abs(item.pnl || 0) / Math.max(1, Math.abs(bestStats.pnl || 1)) * 100));
                return (
                  <button key={name} className="strategy-rank-row group relative w-full overflow-hidden rounded-xl border border-white/10 bg-black/40 p-4 text-left transition-all duration-300 hover:-translate-y-1 hover:border-fuchsia-400/70 hover:shadow-[0_0_24px_rgba(217,70,239,.18)]">
                    <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-fuchsia-500/18 to-transparent" style={{ width: `${width}%` }} />
                    <div className="relative z-10 grid grid-cols-[44px_1fr_100px_120px_80px] items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-fuchsia-500/15 text-sm font-black text-fuchsia-300">#{index + 1}</div>
                      <div><div className="font-black text-white">{name}</div><div className="text-xs text-zinc-400">{item.count} trades · {item.wins || 0} wins · {item.losses || 0} losses · {item.breakEvens || 0} BE</div></div>
                      <div className="text-right text-sm font-black text-emerald-400">{itemWinRate.toFixed(1)}%</div>
                      <div className={item.pnl >= 0 ? "text-right font-black text-emerald-400" : "text-right font-black text-red-400"}>{formatMoney(item.pnl)}</div>
                      <div className="text-right text-sm font-black text-amber-400">{(item.riskTrades ? item.rrSum / item.riskTrades : 0).toFixed(2)}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="strategy-detail-card strategy-detail-pro rounded-2xl border border-fuchsia-500/20 bg-gradient-to-br from-black via-[#07030b] to-[#13091c] p-6">
            <div className="flex items-start justify-between">
              <div><div className="text-xs font-black uppercase tracking-widest text-zinc-500">Selected Strategy</div><h3 className="mt-2 text-2xl font-black text-white">{bestName}</h3></div>
              <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300">ϟ</span>
            </div>
            <div className="mt-6 space-y-4 text-sm">
              <StrategyLine label="Trades" value={bestStats.count} icon="▥" />
              <StrategyLine label="Closed" value={`${bestStats.count} closed`} muted />
              <StrategyLine label="Win Rate" value={`${winRate.toFixed(1)}%`} green icon="◎" />
              <StrategyLine label="Avg RR" value={bestAvgRR.toFixed(2)} amber icon="⌁" />
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-4">
                <div className="flex justify-between"><span className="text-zinc-400">Total P&L</span><span className="font-black text-emerald-400">{formatMoney(bestStats.pnl)}</span></div>
                <div className="mt-2 flex justify-between"><span className="text-zinc-400">Avg P&L / Trade</span><span className="font-black text-emerald-400">{formatMoney(avgPnl)}</span></div>
              </div>
              <div className="rounded-xl border border-white/10 bg-black/30 p-4">
                <div className="mb-3 flex justify-between text-xs font-black uppercase tracking-wider text-zinc-400"><span>W/L/BE Breakdown</span><span>{bestStats.wins || 0}:{bestStats.losses || 0}:{bestStats.breakEvens || 0}</span></div>
                <div className="flex h-3 overflow-hidden rounded-full bg-zinc-900"><div className="bg-emerald-500" style={{ width: `${bestStats.count ? ((bestStats.wins || 0) / bestStats.count) * 100 : 0}%` }} /><div className="bg-red-500" style={{ width: `${bestStats.count ? ((bestStats.losses || 0) / bestStats.count) * 100 : 0}%` }} /><div className="bg-amber-500" style={{ width: `${bestStats.count ? ((bestStats.breakEvens || 0) / bestStats.count) * 100 : 0}%` }} /></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function StrategySummaryCard({ label, value, subtitle, tone }) {
  const styles = {
    fuchsia: "border-fuchsia-500/25 bg-fuchsia-500/10 text-fuchsia-300",
    emerald: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
    red: "border-red-500/25 bg-red-500/10 text-red-300",
    amber: "border-amber-500/25 bg-amber-500/10 text-amber-300",
  };
  return <div className={`rounded-xl border p-4 ${styles[tone] || styles.fuchsia}`}><div className="text-[10px] font-black uppercase tracking-widest text-zinc-400">{label}</div><div className="mt-2 truncate text-xl font-black">{value}</div><div className="mt-1 text-xs font-bold text-zinc-400">{subtitle}</div></div>;
}

function StrategyLine({ label, value, icon, green, amber, muted }) {
  const color = green ? "text-emerald-400" : amber ? "text-amber-400" : muted ? "text-zinc-500" : "text-white";
  return <div className="flex items-center justify-between"><span className="text-zinc-400">{icon && <span className="mr-2 text-fuchsia-400">{icon}</span>}{label}</span><span className={`font-black ${color}`}>{value}</span></div>;
}

function StatisticsRiskView({ stats, trades = [] }) {
  const risk = getRiskDashboardStats(trades);
  const dailyGroups = groupTradesByDate(trades);
  const dailyRiskRows = Object.entries(dailyGroups)
    .map(([date, dayTrades]) => ({
      date,
      risk: dayTrades.reduce((sum, trade) => sum + Number(trade.risk || 0), 0),
      pnl: summarizeTrades(dayTrades).pnl,
      trades: dayTrades.length,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
  const chartRows = dailyRiskRows.length ? dailyRiskRows : [{ date: "No data", risk: 0, pnl: 0 }];
  const maxDailyLoss = dailyRiskRows.length ? Math.min(...dailyRiskRows.map((row) => row.pnl)) : 0;
  const riskTone = risk.maxRiskPercent > 2 ? "red" : risk.maxRiskPercent > 1 ? "fuchsia" : "green";

  return (
    <section className="mt-10">
      <SectionTitle title="Risk Management" icon={<Target size={18} />} />

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <AdvancedStatCard title="AVG RISK" value={formatMoney(risk.avgRisk)} sub={`${risk.avgRiskPercent.toFixed(2)}% account`} tone="fuchsia" />
        <AdvancedStatCard title="MAX RISK" value={formatMoney(risk.maxRisk)} sub={`${risk.maxRiskPercent.toFixed(2)}% account`} tone={riskTone} />
        <AdvancedStatCard title="MAX DAILY LOSS" value={formatMoney(maxDailyLoss)} sub="Worst day" tone="red" />
        <AdvancedStatCard title="RISK CONSISTENCY" value={`${risk.consistencyScore.toFixed(0)}%`} sub="Stable sizing" tone="green" />
      </div>

      <div className="mt-7 grid grid-cols-1 gap-6 xl:grid-cols-[1.1fr_.9fr]">
        <div className="charts-pro-card rounded-2xl border border-fuchsia-500/20 bg-gradient-to-br from-black via-[#05030a] to-[#13091c] p-6">
          <div className="flex items-start justify-between">
            <SectionTitle title="Daily Risk / P&L" icon={<BarChart3 size={18} />} />
            <span className="rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-2 text-xs font-black text-fuchsia-300">Risk control</span>
          </div>
          <div className="mt-5 h-80 rounded-xl border border-white/10 bg-black/25 p-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartRows} margin={{ top: 20, right: 24, left: 8, bottom: 8 }}>
                <CartesianGrid strokeDasharray="4 6" stroke="rgba(217,70,239,.20)" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" tickLine={false} />
                <YAxis stroke="#64748b" tickLine={false} tickFormatter={(value) => `$${value}`} />
                <Tooltip
                  contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }}
                  formatter={(value, name) => [formatMoney(value), name]}
                />
                <Bar dataKey="risk" fill="#d946ef" radius={[8, 8, 0, 0]} />
                <Bar dataKey="pnl" fill="#22c55e" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl border border-amber-500/20 bg-gradient-to-br from-black via-[#090605] to-[#120b05] p-6">
          <SectionTitle title="Risk Rules" icon={<ListChecks size={18} />} />
          <div className="mt-5 space-y-3">
            <RiskRule passed={risk.maxRiskPercent <= 1} title="Keep single-trade risk near 1%" detail={`Max used: ${risk.maxRiskPercent.toFixed(2)}%`} />
            <RiskRule passed={risk.lossStreak < 2} title="Pause after 2 loss streak" detail={`Current loss streak: ${risk.lossStreak}`} />
            <RiskRule passed={risk.consistencyScore >= 65 || risk.riskTrades < 3} title="Consistent position sizing" detail={`Consistency: ${risk.consistencyScore.toFixed(0)}%`} />
            <RiskRule passed={stats.maxDrawdownPercent <= 5} title="Control drawdown" detail={`Max DD: ${stats.maxDrawdownPercent.toFixed(2)}%`} />
          </div>
        </div>
      </div>
    </section>
  );
}

function RiskRule({ passed, title, detail }) {
  return <div className={passed ? "rounded-xl border border-emerald-500/25 bg-emerald-500/10 p-4" : "rounded-xl border border-red-500/25 bg-red-500/10 p-4"}><div className="flex items-center justify-between"><div className="font-black text-white">{title}</div><span className={passed ? "text-emerald-400" : "text-red-400"}>{passed ? "✓" : "!"}</span></div><div className="mt-1 text-sm text-zinc-400">{detail}</div></div>;
}

function StatisticsChartsView({ stats, curve, trades = [] }) {
  const pnl = stats.totalPnl || 0;
  const monthlyGroups = summarizeGroupedTrades(trades, getMonthGroupKey);
  const monthlyData = Object.entries(monthlyGroups).sort((a, b) => a[0].localeCompare(b[0])).map(([, group]) => ({ month: group.label, pnl: summarizeTrades(group.trades).pnl }));
  const strategyData = Object.entries(stats.strategyStats || {}).map(([name, item]) => ({ name, value: item.count, pnl: item.pnl }));
  const fallbackStrategies = strategyData.length ? strategyData : [{ name: "No strategy", value: stats.trades || 1, pnl }];
  const safeMonthlyData = monthlyData.length ? monthlyData : [{ month: "No data", pnl: 0 }];
  return (
    <section className="mt-10 grid grid-cols-1 gap-8 xl:grid-cols-2">
      <div className="statistics-chart-panel charts-pro-card rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-black via-[#020605] to-[#050b13] p-6">
        <div className="flex items-start justify-between"><SectionTitle title="Performance Timeline" icon={<TrendingUp size={18} />} /><span className="rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-3 py-2 text-xs font-black text-emerald-300">Equity</span></div>
        <div className="mt-5 h-80 rounded-xl border border-white/10 bg-black/25 p-3"><ResponsiveContainer width="100%" height="100%"><LineChart data={curve} margin={{ top: 18, right: 20, left: 8, bottom: 6 }}><CartesianGrid strokeDasharray="4 6" stroke="rgba(16,185,129,.20)" vertical={false} /><XAxis dataKey="date" stroke="#64748b" tickLine={false} /><YAxis stroke="#64748b" tickLine={false} tickFormatter={(v) => `$${v}`} /><Tooltip contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }} formatter={(value) => [formatMoney(value), "Cumulative P&L"]} /><Line type="monotone" dataKey="pnl" stroke="#10b981" strokeWidth={4} dot={{ r: 5, fill: "#6366f1", stroke: "#ffffff", strokeWidth: 2 }} activeDot={{ r: 8, fill: "#d946ef", stroke: "#ffffff", strokeWidth: 3 }} /></LineChart></ResponsiveContainer></div>
      </div>

      <div className="statistics-chart-panel charts-pro-card rounded-2xl border border-blue-500/20 bg-gradient-to-br from-black via-[#020605] to-[#050b13] p-6">
        <div className="flex items-start justify-between"><SectionTitle title="Monthly P&L" icon={<BarChart3 size={18} />} /><span className="rounded-xl border border-blue-500/25 bg-blue-500/10 px-3 py-2 text-xs font-black text-blue-300">2026</span></div>
        <div className="mt-5 h-80 rounded-xl border border-white/10 bg-black/25 p-3"><ResponsiveContainer width="100%" height="100%"><BarChart data={safeMonthlyData} margin={{ top: 20, right: 24, left: 8, bottom: 8 }}><CartesianGrid strokeDasharray="4 6" stroke="rgba(59,130,246,.20)" vertical={false} /><XAxis dataKey="month" stroke="#64748b" tickLine={false} /><YAxis stroke="#64748b" tickLine={false} tickFormatter={(v) => `$${v}`} /><Tooltip contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }} formatter={(value) => [formatMoney(value), "P&L"]} /><Bar dataKey="pnl" fill="#22c55e" radius={[8, 8, 0, 0]} /></BarChart></ResponsiveContainer></div>
      </div>

      <div className="statistics-chart-panel charts-pro-card rounded-2xl border border-amber-500/20 bg-gradient-to-br from-black via-[#020605] to-[#120b05] p-6">
        <div className="flex items-start justify-between"><SectionTitle title="Win/Loss Analysis" icon={<Target size={18} />} /><span className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-3 py-2 text-xs font-black text-amber-300">Ratio</span></div>
        <StatisticsWinLossCircle stats={stats} />
      </div>

      <div className="statistics-chart-panel charts-pro-card rounded-2xl border border-fuchsia-500/20 bg-gradient-to-br from-black via-[#05030a] to-[#080413] p-6">
        <div className="flex items-start justify-between"><SectionTitle title="Strategy Breakdown" icon={<span className="text-xl">ϟ</span>} /><span className="rounded-xl border border-fuchsia-500/25 bg-fuchsia-500/10 px-3 py-2 text-xs font-black text-fuchsia-300">Mix</span></div>
        <StrategyBreakdownDonut data={fallbackStrategies} total={stats.trades || 0} />
      </div>
    </section>
  );
}

function BarChart3Visual({ data }) {
  const max = Math.max(1, ...data.map((item) => Math.abs(item.pnl || 0)));
  return (
    <div className="flex h-full items-end justify-center gap-12 px-10 pb-10 pt-6">
      {data.map((item) => (
        <div key={item.month} className="flex h-full flex-1 max-w-md flex-col justify-end">
          <div className="relative flex flex-1 items-end border-b border-dashed border-zinc-700">
            <div className="w-full rounded-t-xl bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-[0_0_30px_rgba(34,197,94,.25)] transition-all duration-300 hover:scale-[1.02]" style={{ height: `${Math.max(18, Math.abs(item.pnl || 0) / max * 92)}%` }}>
              <div className="pt-3 text-center text-sm font-black text-white">{formatMoney(item.pnl)}</div>
            </div>
          </div>
          <div className="mt-3 text-center text-sm font-black text-zinc-400">{item.month}</div>
        </div>
      ))}
    </div>
  );
}

function StrategyBreakdownDonut({ data, total }) {
  const safeTotal = Math.max(1, data.reduce((sum, item) => sum + Number(item.value || 0), 0));
  let offset = 25;
  const segments = data.map((item, index) => {
    const percent = (Number(item.value || 0) / safeTotal) * 100;
    const segment = `${percent} ${100 - percent}`;
    const current = { ...item, percent, offset, color: index % 3 === 0 ? "#94a3b8" : index % 3 === 1 ? "#d946ef" : "#10b981", segment };
    offset -= percent;
    return current;
  });
  return (
    <div className="flex h-80 items-center justify-center gap-8">
      <div className="relative flex h-60 w-60 items-center justify-center">
        <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="42" fill="none" stroke="rgba(148,163,184,.16)" strokeWidth="18" />
          {segments.map((segment) => <circle key={segment.name} cx="60" cy="60" r="42" fill="none" stroke={segment.color} strokeWidth="18" strokeLinecap="round" strokeDasharray={segment.segment} strokeDashoffset={segment.offset} pathLength="100" />)}
        </svg>
        <div className="relative z-10 text-center"><div className="text-5xl font-light text-white">{total}</div><div className="mt-2 text-sm text-zinc-500">Total Trades</div></div>
      </div>
      <div className="space-y-3">
        {segments.map((item) => <div key={item.name} className="flex items-center gap-3 text-sm"><span className="h-3 w-3 rounded-full" style={{ background: item.color }} /><span className="font-bold text-zinc-300">{item.name}</span><span className="text-zinc-500">{item.percent.toFixed(0)}%</span></div>)}
      </div>
    </div>
  );
}

function AnalyticsTable({ title, icon, data, isMistake }) {
  return <section className="mt-8 rounded-xl border border-white/10 bg-zinc-950 p-6"><SectionTitle title={title} icon={icon} /><div className="mt-5 grid gap-3">{Object.entries(data).map(([name, item]) => { const winRate = item.count ? ((item.wins || 0) / item.count) * 100 : 0; return <div key={name} className="grid grid-cols-4 items-center rounded-xl border border-white/10 bg-black p-4"><div className="font-black">{name}</div><div className="text-sm text-zinc-400">Count: <span className="font-bold text-white">{item.count}</span></div><div className="text-sm text-zinc-400">{isMistake ? "Losses" : "Win Rate"}: <span className={isMistake ? "font-bold text-red-400" : "font-bold text-emerald-400"}>{isMistake ? item.losses : `${winRate.toFixed(1)}%`}</span></div><div className={item.pnl >= 0 ? "text-right font-black text-emerald-400" : "text-right font-black text-red-400"}>{formatMoney(item.pnl)}</div></div>; })}</div></section>;
}

function MiniTradeRow({ trade }) {
  return <div className="rounded-xl border border-white/10 bg-black p-4"><div className="flex items-center justify-between"><span className="font-bold">{trade.pair}</span><span className={`font-black ${getPnlToneClass(trade.pnl)}`}>{getPnlArrow(trade.pnl)} {formatMoney(trade.pnl)}</span></div><div className="mt-2 text-sm text-zinc-400">{trade.direction} · {trade.setup}</div></div>;
}
function Meta({ label, value, green, gold, danger }) { return <div><div className="text-xs text-zinc-500">{label}</div><div className={`mt-2 text-lg font-black ${green ? "text-emerald-400" : gold ? "text-amber-400" : danger ? "text-orange-400" : "text-white"}`}>{value}</div></div>; }
function MiniInfo({ label, value, badge, tone }) { const badgeClass = tone === "red" ? "bg-red-600/90 border border-red-500/70 text-white shadow-[0_0_14px_rgba(239,68,68,0.35)]" : tone === "green" ? "bg-emerald-600/90 border border-emerald-500/70 text-white shadow-[0_0_14px_rgba(16,185,129,0.35)]" : "bg-fuchsia-500 text-black"; return <div className="mb-6"><div className="text-sm font-bold text-zinc-300">{label}</div><div className={badge ? `mt-2 w-fit rounded-full px-3 py-1 text-xs font-black ${badgeClass}` : "mt-2 text-sm text-zinc-400"}>{value}</div></div>; }
function SideBox({ title, children }) { return <div className="rounded-xl border border-white/10 bg-zinc-950 p-6"><h3 className="mb-5 text-lg font-black">{title}</h3>{children}</div>; }
function DashCard({ title, value, tone, icon, badge }) {
  const styles = { emerald: { card: "from-emerald-950/45 via-emerald-950/10 to-black border-emerald-500/45 hover:border-emerald-400/80 hover:shadow-emerald-500/20", icon: "bg-emerald-500/10 text-emerald-400", value: "text-white", line: "text-emerald-400", badge: "bg-emerald-500/20 text-emerald-300", glow: "bg-emerald-500/10" }, fuchsia: { card: "from-fuchsia-950/45 via-fuchsia-950/10 to-black border-fuchsia-500/45 hover:border-fuchsia-400/80 hover:shadow-fuchsia-500/20", icon: "bg-fuchsia-500/10 text-fuchsia-400", value: "text-white", line: "text-violet-400", badge: "bg-emerald-500/20 text-emerald-300", glow: "bg-fuchsia-500/10" }, cyan: { card: "from-cyan-950/45 via-cyan-950/10 to-black border-cyan-500/45 hover:border-cyan-400/80 hover:shadow-cyan-500/20", icon: "bg-cyan-500/10 text-cyan-400", value: "text-white", line: "text-cyan-400", badge: "bg-zinc-700/70 text-zinc-300", glow: "bg-cyan-500/10" }, amber: { card: "from-orange-950/45 via-orange-950/10 to-black border-orange-500/45 hover:border-orange-400/80 hover:shadow-orange-500/20", icon: "bg-amber-500/10 text-amber-400", value: "text-white", line: "text-amber-400", badge: "bg-emerald-500/20 text-emerald-300", glow: "bg-amber-500/10" } };
  const s = styles[tone] || styles.emerald;
  const isCustomValue = React.isValidElement(value);
  return <button className={`group relative overflow-hidden rounded-xl border bg-gradient-to-br p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:scale-[1.025] hover:shadow-2xl ${s.card}`}><div className={`absolute right-0 top-0 h-24 w-24 rounded-bl-3xl ${s.glow}`} /><div className="relative z-10 flex items-start justify-between"><div><div className="text-xs font-black uppercase tracking-wider text-zinc-400">{title}</div><div className={`mt-4 text-3xl font-black ${s.value}`}>{isCustomValue ? value : <AnimatedValue value={value} />}</div></div><div className={`flex h-10 w-10 items-center justify-center rounded-xl text-lg font-black ${s.icon}`}>{icon}</div></div><div className="relative z-10 mt-3 flex items-end justify-between"><span className={`rounded-md px-2 py-1 text-xs font-black ${s.badge}`}>{badge}</span><svg width="86" height="34" viewBox="0 0 86 34" fill="none" className={`${s.line} opacity-90 transition-transform duration-300 group-hover:scale-110`}><path d="M2 26 C8 28, 11 12, 17 18 S27 27, 33 16 S45 13, 51 18 S61 8, 68 10 S76 5, 84 2" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" /><path d="M2 31 C11 28, 15 20, 22 22 S32 27, 38 19 S49 15, 55 20 S65 11, 72 13 S78 8, 84 7" stroke="currentColor" strokeWidth="1" opacity="0.35" fill="none" strokeLinecap="round" /></svg></div></button>;
}
function Chart({ curve, tall }) { return <div className={tall ? "mt-5 h-96" : "mt-5 h-72"}><ResponsiveContainer width="100%" height="100%"><LineChart data={curve}><CartesianGrid strokeDasharray="3 3" opacity={0.12} /><XAxis dataKey="date" stroke="#777" /><YAxis stroke="#777" /><Tooltip contentStyle={{ background: "var(--tooltip-bg, #09090b)", border: "1px solid var(--tooltip-border, #333)", borderRadius: 12, color: "var(--tooltip-text, #ffffff)" }} /><Line type="monotone" dataKey="pnl" stroke="#a855f7" strokeWidth={3} dot={{ r: 5 }} /></LineChart></ResponsiveContainer></div>; }
function SectionTitle({ title, icon, gold }) { return <div className="flex items-center gap-3 text-xl font-black"><div className={`rounded-lg p-2 ${gold ? "bg-amber-500/20 text-amber-400" : "bg-fuchsia-500/20 text-fuchsia-400"}`}>{icon}</div>{title}</div>; }
function TopPill({ label, value, green, red }) {
  return <div className={`calendar-top-pill rounded-xl border px-4 py-3 text-sm font-black ${green ? "calendar-top-pill-green border-emerald-500/40 bg-emerald-500/20 text-emerald-300" : red ? "calendar-top-pill-red border-red-500/40 bg-red-500/20 text-red-300" : "calendar-top-pill-neutral border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300"}`}><span className="calendar-top-pill-label mr-2 text-zinc-400">{label}</span>{value}</div>;
}
function Section({ title, icon, children }) { return <div className="mt-6 rounded-xl border border-fuchsia-500/45 bg-gradient-to-br from-zinc-950 via-black to-black p-6"><div className="pointer-events-none absolute" /><h3 className="mb-5 flex items-center gap-3 text-lg font-bold text-white"><span className="flex h-9 w-9 items-center justify-center rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300">{icon}</span>{title}</h3>{children}</div>; }
function Field({ label, children }) { return <label className="block text-sm font-semibold text-white"><span className="mb-2 block">{label}</span>{children}</label>; }
function inputPurpleClass(extra = "") {
  return `border-white/15 bg-black text-white outline-none transition-all focus-visible:border-fuchsia-400 focus-visible:ring-2 focus-visible:ring-fuchsia-500/45 focus-visible:ring-offset-0 focus-visible:shadow-[0_0_16px_rgba(217,70,239,0.30)] ${extra}`;
}

function MoneyInput({ value, onChange, placeholder = "0" }) {
  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black text-emerald-400">$</span>
      <Input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={inputPurpleClass("pl-8")}
      />
    </div>
  );
}
function getSelectOptionStyle(label) {
  const key = String(label || "").toLowerCase();
  const base = { icon: "", active: "bg-fuchsia-500 text-black shadow-[0_0_14px_rgba(217,70,239,0.35)]", normal: "text-zinc-200 hover:bg-fuchsia-500/15 hover:text-fuchsia-200" };
  const styles = {
    buy: { icon: "↗", active: "bg-emerald-500 text-black shadow-[0_0_14px_rgba(16,185,129,0.35)]", normal: "text-emerald-300 hover:bg-emerald-500/15 hover:text-emerald-200" },
    sell: { icon: "↘", active: "bg-red-500 text-black shadow-[0_0_14px_rgba(239,68,68,0.35)]", normal: "text-red-300 hover:bg-red-500/15 hover:text-red-200" },
    win: { icon: "●", active: "bg-emerald-500 text-black shadow-[0_0_14px_rgba(16,185,129,0.35)]", normal: "text-emerald-300 hover:bg-emerald-500/15 hover:text-emerald-200" },
    loss: { icon: "●", active: "bg-red-500 text-black shadow-[0_0_14px_rgba(239,68,68,0.35)]", normal: "text-red-300 hover:bg-red-500/15 hover:text-red-200" },
    "break even": { icon: "—", active: "bg-amber-500 text-black shadow-[0_0_14px_rgba(245,158,11,0.35)]", normal: "text-amber-300 hover:bg-amber-500/15 hover:text-amber-200" },
    a: { icon: "A", active: "bg-emerald-500 text-black shadow-[0_0_14px_rgba(16,185,129,0.35)]", normal: "text-emerald-300 hover:bg-emerald-500/15 hover:text-emerald-200" },
    b: { icon: "B", active: "bg-blue-500 text-black shadow-[0_0_14px_rgba(59,130,246,0.35)]", normal: "text-blue-300 hover:bg-blue-500/15 hover:text-blue-200" },
    c: { icon: "C", active: "bg-amber-500 text-black shadow-[0_0_14px_rgba(245,158,11,0.35)]", normal: "text-amber-300 hover:bg-amber-500/15 hover:text-amber-200" },
    d: { icon: "D", active: "bg-red-500 text-black shadow-[0_0_14px_rgba(239,68,68,0.35)]", normal: "text-red-300 hover:bg-red-500/15 hover:text-red-200" },
    calm: { icon: "◌", active: "bg-cyan-500 text-black shadow-[0_0_14px_rgba(6,182,212,0.35)]", normal: "text-cyan-300 hover:bg-cyan-500/15 hover:text-cyan-200" },
    confident: { icon: "◆", active: "bg-emerald-500 text-black shadow-[0_0_14px_rgba(16,185,129,0.35)]", normal: "text-emerald-300 hover:bg-emerald-500/15 hover:text-emerald-200" },
    fearful: { icon: "!", active: "bg-amber-500 text-black shadow-[0_0_14px_rgba(245,158,11,0.35)]", normal: "text-amber-300 hover:bg-amber-500/15 hover:text-amber-200" },
    greedy: { icon: "$", active: "bg-orange-500 text-black shadow-[0_0_14px_rgba(249,115,22,0.35)]", normal: "text-orange-300 hover:bg-orange-500/15 hover:text-orange-200" },
    asia: { icon: "", active: "session-active-asia text-blue-100", normal: "session-neon session-neon-asia" },
    london: { icon: "", active: "session-active-london text-red-100", normal: "session-neon session-neon-london" },
    "ny-am": { icon: "", active: "session-active-nyam text-emerald-100", normal: "session-neon session-neon-nyam" },
    lunch: { icon: "", active: "session-active-lunch text-amber-100", normal: "session-neon session-neon-lunch" },
    "ny-pm": { icon: "", active: "session-active-nypm text-fuchsia-100", normal: "session-neon session-neon-nypm" },
    "pre-market": { icon: "", active: "session-active-premarket text-cyan-100", normal: "session-neon session-neon-premarket" },
    "select trading session": { icon: "⌁", active: "bg-fuchsia-500 text-black shadow-[0_0_14px_rgba(217,70,239,0.35)]", normal: "text-zinc-400 hover:bg-fuchsia-500/15 hover:text-fuchsia-200" },
    all: { icon: "✦", active: "bg-fuchsia-500 text-black shadow-[0_0_14px_rgba(217,70,239,0.35)]", normal: "text-fuchsia-200 hover:bg-fuchsia-500/15 hover:text-fuchsia-100" },
  };
  return styles[key] || base;
}

function flattenSelectChildren(children) {
  const output = [];
  React.Children.forEach(children, (child) => {
    if (!child) return;
    if (Array.isArray(child)) {
      child.forEach((nestedChild) => {
        if (!nestedChild) return;
        const label = String(nestedChild.props?.children ?? "");
        output.push({ label, value: nestedChild.props?.value ?? label });
      });
      return;
    }
    if (child.type === React.Fragment) {
      output.push(...flattenSelectChildren(child.props.children));
      return;
    }
    const label = String(child.props?.children ?? "");
    output.push({ label, value: child.props?.value ?? label });
  });
  return output;
}

function getSelectOptionKey(label) {
  return String(label || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function Select({ value, onChange, children }) {
  const [open, setOpen] = useState(false);
  const options = flattenSelectChildren(children);
  const selected = options.find((option) => String(option.value) === String(value)) || options[0];
  const selectedStyle = getSelectOptionStyle(selected?.label);
  const selectedKey = getSelectOptionKey(selected?.label);

  function choose(option) {
    onChange?.({ target: { value: option.value } });
    setOpen(false);
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="custom-select-trigger flex h-10 w-full items-center justify-between rounded-md border border-white/15 bg-black px-3 text-left text-sm text-white outline-none transition-all hover:border-fuchsia-400 focus:border-fuchsia-400 focus:shadow-[0_0_14px_rgba(217,70,239,0.16)]"
      >
        <span className={`custom-select-selected custom-select-option-${selectedKey} flex items-center gap-2`}>
          {selectedStyle.icon && <span className="w-4 text-center font-black">{selectedStyle.icon}</span>}
          <span className="font-black">{selected?.label || "Select"}</span>
        </span>
        <span className={open ? "text-fuchsia-300 transition-transform rotate-180" : "text-fuchsia-300 transition-transform"}>⌄</span>
      </button>
      {open && (
        <div className="custom-select-menu absolute left-0 top-11 z-[80] max-h-64 w-full overflow-y-auto rounded-xl border border-fuchsia-500/40 bg-[#050005] p-1 shadow-[0_18px_55px_rgba(0,0,0,0.95)] ring-1 ring-fuchsia-500/20">
          {options.map((option) => {
            const active = String(option.value) === String(value);
            const style = getSelectOptionStyle(option.label);
            const optionKey = getSelectOptionKey(option.label);
            return (
              <button
                key={option.value}
                type="button"
                onMouseDown={(event) => {
                  event.preventDefault();
                  choose(option);
                }}
                className={`custom-select-option custom-select-option-${optionKey} flex min-h-9 w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-black leading-5 transition-all ${active ? `custom-select-active ${style.active}` : style.normal}`}
              >
                {style.icon && <span className="w-4 text-center font-black">{style.icon}</span>}
                <span>{option.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
function StatCard({ title, value, green, gold }) {
  const iconMap = { "Total Trades": "⌁", "Win Rate": "🏆", "Avg P&L": "$", "Avg R:R": "↗", "Total P&L": "$", "TOTAL P&L": "$", "WIN RATE": "🏆", "TRADES": "⌁", "AVG WIN": "↗", "AVG LOSS": "↘", "PROFIT FACTOR": "✦" };
  const icon = iconMap[title] || "✦";
  const iconTone = green ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300 shadow-[0_0_14px_rgba(16,185,129,0.18)]" : gold ? "border-amber-500/30 bg-amber-500/10 text-amber-300 shadow-[0_0_14px_rgba(245,158,11,0.18)]" : "border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300 shadow-[0_0_14px_rgba(217,70,239,0.18)]";
  return <Card className="group relative overflow-hidden border-fuchsia-500/35 bg-gradient-to-br from-zinc-950 via-black to-black text-white shadow-[0_0_22px_rgba(217,70,239,0.12)] transition-all duration-300 hover:-translate-y-1 hover:scale-[1.015] hover:border-fuchsia-400/80 hover:shadow-2xl hover:shadow-fuchsia-500/25"><div className="absolute right-0 top-0 h-20 w-20 rounded-bl-[2rem] bg-fuchsia-500/10" /><div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-500/50 to-transparent" /><CardContent className="relative z-10 p-5"><div className="flex items-start justify-between gap-3"><div><div className="text-xs font-black uppercase tracking-wider text-zinc-400">{title}</div><div className={`mt-4 text-2xl font-black ${green ? "text-emerald-400" : gold ? "text-amber-400" : "text-white"}`}><AnimatedValue value={value} /></div></div><div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-black ${iconTone}`}>{icon}</div></div></CardContent></Card>;
}

function AuthPage({ authPage, setAuthPage, onSubmitAuth, authLoading, authMessage, isSupabaseReady, passwordRecoverySession, theme, setTheme }) {
  const isLogin = authPage === "login";
  const isRegister = authPage === "register";
  const isForgot = authPage === "forgot";
  const isUpdatePassword = authPage === "updatePassword";
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "", accountType: "Trader" });
  const [error, setError] = useState("");

  function update(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
  }

  async function submitAuth(event) {
    event.preventDefault();
    if (!String(form.email || "").includes("@")) {
      setError("Please enter a valid email address.");
      return;
    }
    if (!isForgot && String(form.password || "").length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if ((isRegister || isUpdatePassword) && form.password !== form.confirm) {
      setError("Passwords do not match.");
      return;
    }
    setError("");
    const mode = isLogin ? "login" : isRegister ? "register" : isUpdatePassword ? "updatePassword" : "forgot";
    const result = await onSubmitAuth?.(mode, form);
    if (result && !result.ok) setError(result.error?.message || "Authentication failed. Try again.");
  }

  const title = isLogin ? "Welcome back" : isRegister ? "Create your account" : isUpdatePassword ? "Create new password" : "Reset password";
  const subtitle = isLogin ? "Sign in to continue your trading journey" : isRegister ? "Start tracking your trades with clarity" : isUpdatePassword ? "Choose a new secure password for your account" : "Enter your email and we will send a reset link";

  return (
    <div className="relative min-h-screen overflow-hidden bg-black text-white">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_72%_18%,rgba(217,70,239,0.18),transparent_34%),radial-gradient(circle_at_84%_80%,rgba(16,185,129,0.10),transparent_28%),linear-gradient(135deg,#000_0%,#060206_45%,#12051b_100%)]" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-full w-px bg-gradient-to-b from-transparent via-fuchsia-500/15 to-transparent" />

      <div className="relative z-10 flex min-h-screen flex-col lg:grid lg:grid-cols-[520px_1fr]">
        <div className="flex min-h-screen items-center justify-center p-6 lg:p-10">
          <motion.div initial={{ opacity: 0, y: 16, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} className="w-full max-w-[430px] rounded-[2rem] border border-white/10 bg-black/75 p-8 shadow-[0_28px_90px_rgba(0,0,0,0.75),0_0_40px_rgba(217,70,239,0.10)] backdrop-blur-xl">
            <div className="mb-8 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-4xl text-fuchsia-400 drop-shadow-[0_0_18px_rgba(217,70,239,0.95)]">{BRAND_MARK}</span>
                <span className="text-2xl font-black tracking-tight">{BRAND_NAME}</span>
              </div>
              <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm font-black text-zinc-300 hover:border-fuchsia-500/50 hover:text-white">{theme === "dark" ? "☀" : "🌙"}</button>
            </div>

            <div className="text-center">
              <h1 className="text-3xl font-black tracking-tight text-white">{title}</h1>
              <p className="mt-3 text-sm font-semibold leading-6 text-zinc-400">{subtitle}</p>
            </div>

            {!isSupabaseReady && (
              <div className="mt-6 rounded-2xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-sm font-bold leading-6 text-amber-300">
                Supabase is not connected. Make sure .env is inside the project root and restart npm run dev after saving it.
              </div>
            )}
            {authMessage && (
              <div className="mt-6 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 px-4 py-3 text-sm font-bold leading-6 text-emerald-300">
                {authMessage}
              </div>
            )}

            <form onSubmit={submitAuth} className="mt-8 space-y-5">
              {isUpdatePassword && !passwordRecoverySession && (
                <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-sm font-bold leading-6 text-amber-300">
                  Open the reset link from your email to create a new password.
                </div>
              )}

              {isRegister && (
                <AuthField label="Full name" icon="👤">
                  <Input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Enter your name" className="border-white/10 bg-black/45 pl-11 text-white placeholder:text-zinc-500 focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
                </AuthField>
              )}

              <AuthField label="Email address" icon="✉">
                <Input value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="Enter your email" className="border-white/10 bg-black/45 pl-11 text-white placeholder:text-zinc-500 focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
              </AuthField>

              {!isForgot && (
                <AuthField label={isUpdatePassword ? "New password" : "Password"} icon="🔒">
                  <Input type={showPassword ? "text" : "password"} value={form.password} onChange={(e) => update("password", e.target.value)} placeholder="Enter your password" className="border-white/10 bg-black/45 pl-11 pr-11 text-white placeholder:text-zinc-500 focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
                  <button type="button" onClick={() => setShowPassword((current) => !current)} className="absolute right-3 top-[35px] text-zinc-500 hover:text-white">{showPassword ? "🙈" : "👁"}</button>
                </AuthField>
              )}

              {(isRegister || isUpdatePassword) && (
                <AuthField label="Confirm password" icon="🔐">
                  <Input type={showPassword ? "text" : "password"} value={form.confirm} onChange={(e) => update("confirm", e.target.value)} placeholder="Repeat your password" className="border-white/10 bg-black/45 pl-11 text-white placeholder:text-zinc-500 focus-visible:border-fuchsia-400 focus-visible:ring-fuchsia-500/20" />
                </AuthField>
              )}

              {isRegister && (
                <AuthField label="Account type" icon="🎯">
                  <Select value={form.accountType} onChange={(e) => update("accountType", e.target.value)}><option>Trader</option><option>Prop Firm</option><option>Demo</option><option>Funded Account</option></Select>
                </AuthField>
              )}

              {isLogin && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 font-semibold text-zinc-400"><input type="checkbox" className="h-4 w-4 accent-fuchsia-500" /> Remember me</label>
                  <button type="button" onClick={() => setAuthPage("forgot")} className="font-black text-fuchsia-300 hover:text-fuchsia-200">Forgot password?</button>
                </div>
              )}

              {error && <div className={isForgot ? "rounded-xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-sm font-bold text-amber-300" : "rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-300"}>{error}</div>}

              <button type="submit" disabled={authLoading} className="group flex h-12 w-full items-center justify-center gap-3 rounded-xl bg-gradient-to-r from-fuchsia-500 to-purple-600 text-sm font-black text-white shadow-[0_18px_36px_rgba(217,70,239,0.24)] transition hover:scale-[1.01] hover:shadow-[0_20px_44px_rgba(217,70,239,0.34)] disabled:cursor-not-allowed disabled:opacity-60">
                {authLoading ? "Please wait..." : isLogin ? "Sign in" : isRegister ? "Create account" : isUpdatePassword ? "Update password" : "Send reset link"}
                <span className="transition group-hover:translate-x-1">→</span>
              </button>
            </form>

            <div className="mt-7 text-center text-sm font-semibold text-zinc-500">
              {isLogin && <>Don&apos;t have an account? <button onClick={() => setAuthPage("register")} className="font-black text-fuchsia-300 hover:text-fuchsia-200">Sign up for free</button></>}
              {isRegister && <>Already have an account? <button onClick={() => setAuthPage("login")} className="font-black text-fuchsia-300 hover:text-fuchsia-200">Sign in</button></>}
              {(isForgot || isUpdatePassword) && <button onClick={() => setAuthPage("login")} className="font-black text-fuchsia-300 hover:text-fuchsia-200">← Back to sign in</button>}
            </div>
          </motion.div>
        </div>

        <div className="relative hidden min-h-screen items-center justify-center overflow-hidden p-10 lg:flex">
          <div className="absolute left-12 top-28 rounded-2xl border border-emerald-500/20 bg-black/40 p-5 opacity-80 shadow-[0_0_35px_rgba(16,185,129,0.10)] backdrop-blur-xl">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Win Rate</div>
            <div className="mt-3 text-3xl font-black text-emerald-400">87.3%</div>
            <div className="mt-1 text-xs font-bold text-emerald-300">+12.4% this month</div>
          </div>
          <div className="absolute right-16 top-40 rounded-2xl border border-fuchsia-500/20 bg-black/40 p-5 opacity-80 shadow-[0_0_35px_rgba(217,70,239,0.10)] backdrop-blur-xl">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Mistake Detector</div>
            <div className="mt-3 text-xl font-black text-fuchsia-300">Active Coach</div>
            <div className="mt-1 text-xs font-bold text-zinc-400">Find → Understand → Fix</div>
          </div>
          <div className="absolute bottom-28 right-24 rounded-2xl border border-emerald-500/20 bg-black/40 p-5 opacity-80 shadow-[0_0_35px_rgba(16,185,129,0.10)] backdrop-blur-xl">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-500">Total P&L</div>
            <div className="mt-3 text-3xl font-black text-emerald-400">+$2,450</div>
            <div className="mt-1 text-xs font-bold text-zinc-400">Tracked from journal</div>
          </div>

          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="relative z-10 max-w-2xl text-center">
            <div className="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-[1.5rem] border border-fuchsia-500/30 bg-fuchsia-500/10 text-5xl text-fuchsia-300 shadow-[0_0_40px_rgba(217,70,239,0.25)]">{BRAND_MARK}</div>
            <h2 className="text-6xl font-black leading-[0.95] tracking-tight text-white">Transform Your<br />Trading Journey</h2>
            <p className="mx-auto mt-8 max-w-xl text-xl font-semibold leading-8 text-zinc-400">Turn every trade into clear feedback, discipline, and measurable growth. Build consistency with data-driven insights and better psychology.</p>
            <div className="mt-10 grid grid-cols-3 gap-4">
              <AuthHeroMetric value="1" label="journal" />
              <AuthHeroMetric value="5" label="analytics pages" />
              <AuthHeroMetric value="24/7" label="trade review" />
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function AuthField({ label, icon, children }) {
  return (
    <label className="relative block text-sm font-black text-white">
      <span className="mb-2 block">{label}</span>
      <span className="pointer-events-none absolute left-3 top-[34px] z-10 flex h-6 w-6 items-center justify-center text-zinc-500">{icon}</span>
      {children}
    </label>
  );
}

function AuthHeroMetric({ value, label }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/35 p-4 backdrop-blur-xl">
      <div className="text-2xl font-black text-white">{value}</div>
      <div className="mt-1 text-xs font-black uppercase tracking-widest text-zinc-500">{label}</div>
    </div>
  );
}
